"""
enrich.py — Arricchimento derivato dai dati MIM/Axios:
comune, tipo scuola e classi di concorso a partire da nome/grado/testo.
"""

from __future__ import annotations

import re

from .config import TIPO_NORM
from .axios import CLASSE_RE

_CITY_TOKENS = {"IC", "IS", "IIS", "IT", "ISTITUTO", "COMPRENSIVO", "SCUOLA",
                "STATALE", "SUPERIORE", "IPSIA", "IPSEOA", "CPIA", "MI",
                "LICEO", "TECNICO", "PROFESSIONALE", "DI", "VIA", "DEI", "DELLE",
                "S.PELLICO", "MIIC", "MIIS", "MIMM", "E", "DON", "PADRE",
                "AI", "NOSTRI", "CADUTI"}


def comune_from_name(school: str) -> str:
    """Estrae il comune dal nome MIM: '- SEGRATE', '- MILANO', '- SAN DONATO
    MILANESE', oppure da codici 'MIIC860003 - S.PELLICO-ARLUNO' etc."""
    s = school.strip()
    m = re.search(r"\s-\s+([^\-]+)$", s)
    if m:
        tok = m.group(1).strip()
        # parti in maiuscolo iniziali (evita "IC Schweitzer - SEGRATE" ok,
        # ma anche "CPIA2 Nord Est Milano - CINISELLO BALSAMO")
        words = [w for w in tok.split() if w.isupper() or w[0].isupper()]
        if words:
            return " ".join(words).strip()
    # pattern "ISTITUTO COMPRENSIVO DI VILLA CORTESE" (no dash)
    m = re.search(r"\bVILLA\s+CORTESE\b", s, re.I) or re.search(r"\bTRUCCAZZANO\b", s, re.I)
    if m:
        return m.group(0).upper()
    # ultimo token dopo il codice
    m = re.match(r"^[A-Z]{2}[A-Z0-9]{6,8}\s*[-–]\s*(.+)$", s.strip())
    if m:
        tail = m.group(1).strip()
        words = tail.split()
        if words and words[-1].isupper():
            return words[-1]
    return ""


def tipo_from_grade(grade: str, extras: str = "") -> str:
    """Normalizza il tipo scuola da grado MIM / testo Axios."""
    blob = f"{grade} {extras}".lower()
    for key, val in TIPO_NORM.items():
        if key in blob:
            return val
    # euristiche
    if re.search(r"\bprimaria\b|\belementare\b", blob):
        return "primaria"
    if re.search(r"\bsecondaria di [i1]|i grado|secondaria i", blob):
        return "secondaria_i"
    if re.search(r"\bsecondaria di [i2]|ii grado|secondaria [i2]", blob):
        return "secondaria_ii"
    return ""


def classi_from_text(text: str) -> list[str]:
    seen: list[str] = []
    for m in CLASSE_RE.finditer(text):
        c = m.group(1).upper()
        if c not in seen:
            seen.append(c)
    return seen


def subject_from_classi(classi: list[str]) -> str | None:
    """Se le classi di concorso dichiarano il soggetto, usalo (più preciso
    del testo libero)."""
    from .config import CLASSE_MAP
    for c in classi:
        subj = CLASSE_MAP.get(c)
        if subj in ("francese", "sostegno"):
            return subj
    return None