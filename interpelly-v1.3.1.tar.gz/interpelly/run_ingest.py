"""
run_ingest.py — Ingest: crawler UST/MIM → dettagli → Axios (home) o albo scuola
(VPS) → arricchimento → SQLite → notifiche.

Modalità:
  * HOME (default): Axios raggiungibile (IP residenziale) → soggetto
    strutturato: classi di concorso, ore, periodo, scadenza, link candidatura.
  * VPS: Axios bloccato da Cloudflare → soggetto dal titolo MIM e dall'albo
    online della scuola; i casi dubbi restano "da verificare".

Uso:
  python3 run_ingest.py [--since-days 21] [--probe-limit 40] [--refresh|--reclassify]
                        [--notify] [--digest-email] [--capture-sample]
                        [--provinces MILANO,BERGAMO] [--verbose]
"""

from __future__ import annotations

import argparse
import os
import re
import sys
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

import requests

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from ingest.mim import MIMSession, fetch_list, fetch_detail  # noqa: E402
from ingest.store import Store  # noqa: E402
from ingest.subjects import classify_interpello, classify  # noqa: E402
from ingest.schools import school_site, extract_subject_from_school  # noqa: E402
from ingest.axios import parse_axios_html, save_sample  # noqa: E402
from ingest.enrich import (comune_from_name, tipo_from_grade,  # noqa: E402
                           classi_from_text, subject_from_classi, extract_fields)
from ingest.match import match_score  # noqa: E402
from ingest.config import provinces, home_mode, TARGETS, UST_LIST  # noqa: E402
from ingest import notify  # noqa: E402

DB = Path(os.environ.get("INTERPELLY_DB", str(ROOT / "data" / "interpelli.db")))


def process_province(prov: str, url: str, store: Store, sess: MIMSession,
                     args, rq: requests.Session, domain_cache: dict,
                     probe_state: dict, new_targets: list[dict],
                     ai_settings: dict) -> int:
    """Crawla una provincia. Ritorna il numero di dettagli letti.
    probe_state = {"used": int} per rispettare il limite globale di probe."""
    items = fetch_list(sess, url)
    print(f"  {prov}: {len(items)} interpelli in lista")
    n_details = 0

    for idx, it in enumerate(items, 1):
        existed = store.conn.execute(
            "SELECT 1 FROM interpelli WHERE detail_url=?", (it.key(),)).fetchone() is not None
        if existed and not args.refresh:
            continue

        n_details += 1
        try:
            fetch_detail(sess, it)
        except RuntimeError as e:
            if args.verbose:
                print(f"    ! {it.school}: {e}")
            continue

        subj = classify_interpello(it)
        conf = 1.0 if subj in TARGETS else 0.0
        extra: dict = {"provincia": prov, "fonte": "MIM"}
        extra["comune"] = comune_from_name(it.school)
        extra["tipo_scuola"] = tipo_from_grade(it.grade, it.raw_text)
        extra["classi"] = classi_from_text(it.raw_text)
        # scadenze/ore/periodo: regex locali SEMPRE come fallback (i dati Axios,
        # se arrivano, fanno override sotto); in VPS è l'unica fonte strutturata.
        fields = extract_fields(f"{it.raw_text} {it.grade}")
        for key in ("scadenza", "ore", "periodo", "comune"):
            if not extra.get(key):
                extra[key] = fields[key]

        # --- Axios (solo da IP residenziale) -------------------------------
        if home_mode() and it.axios_url:
            try:
                html = sess.get(it.axios_url)
                ax = parse_axios_html(html)
                if ax.ok:
                    extra.update(
                        fonte="Axios",
                        classi=ax.classi or extra["classi"],
                        # mai sovrascrivere con stringhe vuote: il fallback locale
                        # (extract_fields) resta se Axios non ha il campo
                        ore=ax.ore or extra.get("ore", ""),
                        periodo=ax.periodo or extra.get("periodo", ""),
                        scadenza=ax.scadenza or extra.get("scadenza", ""),
                        comune=ax.comune or extra["comune"],
                        tipo_scuola=ax.tipo_scuola or extra["tipo_scuola"],
                        link_candidatura=ax.link_candidatura)
                    cls_subj = subject_from_classi(ax.classi)
                    if cls_subj:
                        subj, conf = cls_subj, 1.0
                    elif ax.raw_text:
                        s2, c2 = classify(ax.raw_text)
                        if c2 >= 1.0:
                            subj, conf = s2, 1.0
                    if args.capture_sample:
                        save_sample(html, it.axios_url, ROOT)
                    if args.verbose:
                        print(f"    ↳ axios {it.school[:36]}: {subj} | "
                              f"classi={ax.classi} scad={ax.scadenza}")
                    time.sleep(0.4)
            except RuntimeError:
                pass  # 403/errore -> degrada senza crash

        # --- albo online della scuola (fallback VPS) ------------------------
        if subj == "da_verificare" and args.school_probe \
                and probe_state["used"] < args.probe_limit:
            domain = store.school_domain(it.school)
            if not domain:
                domain = school_site(rq, it.school, domain_cache)
            if domain:
                probe_state["used"] += 1
                subj2 = extract_subject_from_school(rq, domain)
                if subj2 in TARGETS:
                    subj, conf = subj2, 1.0
                store.upsert_school(it.school, domain=domain,
                                    subject=subj2 if subj2 in TARGETS else None)
                if args.verbose:
                    print(f"    ↳ probe {it.school[:36]}: {subj2}")

        # --- AI/LLM opzionale (impostazioni dalla dashboard / env) -----------
        if subj == "da_verificare":
            from ingest.ai import extract as ai_extract, _configured as ai_ok
            if ai_ok(ai_settings) and it.raw_text:
                data = ai_extract(it.raw_text, settings=ai_settings)
                if data:
                    ai_subj = data.get("subject")
                    if ai_subj in TARGETS:
                        subj, conf = ai_subj, 1.0
                        extra["fonte"] = extra.get("fonte", "MIM") + "+AI"
                    extra["classi"] = data.get("classi") or extra["classi"]
                    extra["ore"] = data.get("ore") or extra.get("ore", "")
                    extra["periodo"] = data.get("periodo") or extra.get("periodo", "")
                    extra["scadenza"] = data.get("scadenza") or extra.get("scadenza", "")
                    extra["comune"] = data.get("comune") or extra.get("comune", "")
                    extra["tipo_scuola"] = data.get("tipo_scuola") or extra.get("tipo_scuola", "")
                    if args.verbose:
                        print(f"    ↳ AI {it.school[:36]}: {ai_subj}")

        it.subject, it.confidence = subj, conf
        store.upsert_interpello(it, extra)
        store.upsert_school(it.school)

        if not existed and subj in TARGETS:
            rec = it.to_dict()
            rec.update(extra)
            # normalizza il record per notify.py: si aspetta classi_concorso e
            # scadenza_iso (il record appena estratto usa chiavi "classi"/"scadenza")
            rec["classi_concorso"] = rec.get("classi_concorso") or rec.get("classi") or []
            rec["scadenza_iso"] = rec.get("scadenza_iso") or rec.get("scadenza") or ""
            new_targets.append(rec)
        if args.verbose:
            print(f"  {idx:>3}. [{subj:<14}] {it.school[:50]}")
        time.sleep(0.12)
    return n_details


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--since-days", type=int, default=21)
    ap.add_argument("--school-probe", action="store_true")
    ap.add_argument("--probe-limit", type=int, default=40)
    ap.add_argument("--refresh", action="store_true")
    ap.add_argument("--reclassify", action="store_true")
    ap.add_argument("--notify", action="store_true")
    ap.add_argument("--digest-email", action="store_true")
    ap.add_argument("--capture-sample", action="store_true")
    ap.add_argument("--provinces", default="")
    ap.add_argument("--verbose", action="store_true")
    args = ap.parse_args()

    store = Store(DB)
    if args.reclassify:
        reclassify(store)
        store.close()
        return 0

    provs = [p.strip().upper() for p in args.provinces.split(",") if p.strip()] or provinces()
    sess = MIMSession()
    rq = requests.Session()
    rq.headers.update({"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/124"})
    domain_cache: dict[str, str] = {}
    probes_used = {"used": 0}
    new_targets: list[dict] = []
    tot_details = 0

    ai_settings = store.ai_effective()
    print(f"[{datetime.now():%H:%M}] Modalità: {'HOME (Axios attivo)' if home_mode() else 'VPS'}"
          f" | AI: {'attiva' if ai_settings.get('AI_API_KEY') else 'disattivata (impostabile nella dashboard)'}")
    for prov, url in UST_LIST.items():
        if prov not in provs:
            continue
        tot_details += process_province(prov, url, store, sess, args, rq,
                                        domain_cache, probes_used, new_targets,
                                        ai_settings)

    watch = store.watched_schools()
    for t in new_targets:
        t["_watch"] = any(w in t["school"].lower() for w in watch)
    merged = store.merge_duplicates()
    store.mark_ingest_ok()
    _maybe_refresh_datasets(store)
    print(f"  → dettagli letti: {tot_details} | target nuovi: {len(new_targets)} "
          f"| probe: {probes_used['used']} | unificati: {merged}")

    if args.notify and new_targets:
        profile = store.get_profile()
        has_criteria = any(profile.get(k) for k in ("soggetti", "classi", "comuni", "grado"))
        if has_criteria:
            matched_targets = []
            for target in new_targets:
                match = match_score(target, profile)
                if match["score"] >= 50:
                    target["match"] = match
                    matched_targets.append(target)
            new_targets = matched_targets
        sent = notify.notify_interpelli(new_targets)
        print(f"  → Telegram: {sent} messaggi inviati")
        remind = notify.notify_deadline_reminder(store)
        if remind:
            print(f"  → Telegram: promemoria scadenze inviato")

    if args.digest_email:
        _send_daily_digest(store)

    store.close()
    return 0


def reclassify(store: Store) -> int:
    """Riclassifica offline solo le righe ancora da verificare."""
    before = store.stats()["by_subject"]
    rows = store.conn.execute(
        "SELECT detail_url, school, grade, raw_text FROM interpelli "
        "WHERE subject='da_verificare'"
    ).fetchall()
    updated = 0
    for row in rows:
        subject, confidence = classify(
            f"{row['school']} {row['grade']} {row['raw_text']}"
        )
        if subject in TARGETS and confidence >= 0.5:
            store.mark_subject(row["detail_url"], subject, confidence)
            updated += 1
    after = store.stats()["by_subject"]
    print(f"Reclassify: prima={before} dopo={after} aggiornati={updated}")
    return updated


def _send_daily_digest(store: Store) -> None:
    since = (datetime.now(timezone.utc) - timedelta(days=1)).isoformat()
    rows = store.conn.execute(
        "SELECT * FROM interpelli WHERE created_ts >= ?", (since,)).fetchall()
    items = [dict(r) for r in rows if r["subject"] in TARGETS]
    expiring = store.interpelli(urgent_days=2)
    body = notify.daily_digest(items, expiring)
    ok = notify.email_digest(body)
    print(f"  → digest email: {'inviato' if ok else 'non configurato (SMTP_*)'}")


def _maybe_refresh_datasets(store: Store) -> None:
    """A settembre (quando il MIM pubblica l'anagrafe aggiornata) rigenera la
    directory scuole, al più una volta l'anno."""
    from datetime import date as _date
    if _date.today().month != 9:
        return
    last = store.get_meta("datasets_refreshed", "")
    last_d = _date.fromisoformat(last) if last else _date(2000, 1, 1)
    if (_date.today() - last_d).days <= 280:
        return
    import subprocess
    r = subprocess.run(
        [sys.executable, str(ROOT / "scripts" / "build_school_directory.py")],
        capture_output=True)
    if r.returncode == 0:
        store.set_meta("datasets_refreshed", _date.today().isoformat())
        print("  → directory scuole rigenerata (a.s. nuovo)")


if __name__ == "__main__":
    try:
        code = main()
    except Exception:
        from ingest.store import Store as _S
        _s = _S(DB)
        _s.mark_ingest_fail()
        _s.close()
        raise
    raise SystemExit(code)
