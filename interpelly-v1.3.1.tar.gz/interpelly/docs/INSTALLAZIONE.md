# Guida all'installazione di Interpelly ✻

Interpelly è la *bacheca del supplente*: raccoglie in un'unica dashboard gli
**interpelli per supplenze** (francese e sostegno) pubblicati dall'UST di
Milano e provincia, con classi di concorso, ore, scadenza e link di
candidatura. Include monitoraggio continuo, notifiche Telegram e un'app
desktop.

> ⭐ **Il modo più semplice è l'app desktop (Electron)**: un'icona, un doppio
> clic, e Interpelly avvia da sola il backend, apre la dashboard in una
> finestra e resta in tray come monitor sempre acceso.

Questa guida copre tutti i modi per installarla e metterla in funzione.

---

## Sommario

1. [Cosa serve](#cosa-serve)
2. [Scegli la modalità: casa o VPS](#scegli-la-modalità-casa-o-vps)
3. [Metodo A — App desktop (Electron) — consigliato](#metodo-a--app-desktop-electron--consigliato)
4. [Metodo B — macOS con Homebrew](#metodo-b--macos-con-homebrew)
5. [Metodo C — One-liner (macOS / Linux, senza brew)](#metodo-c--one-liner-macos--linux-senza-brew)
6. [Metodo D — Da sorgente (sviluppo)](#metodo-d--da-sorgente-sviluppo)
7. [Metodo E — Docker / VPS](#metodo-e--docker--vps)
8. [Primo avvio e verifica](#primo-avvio-e-verifica)
9. [Configurazione (.env)](#configurazione-env)
10. [Avvio automatico al login](#avvio-automatico-al-login)
11. [Notifiche Telegram](#notifiche-telegram)
12. [Dashboard remota e sicurezza](#dashboard-remota-e-sicurezza)
13. [Problemi comuni](#problemi-comuni)

---

## Cosa serve

| Componente | Richiesto per |
|---|---|
| **Python 3.11+** | sempre (backend, ingest, scan) |
| **Node.js 18+** o **Bun** | solo l'app desktop (Electron) |
| **Homebrew** | solo il metodo B (macOS) |
| **Docker** | solo il metodo E (VPS/servere) |

Sul macOS di sistema il `python3` della riga di comando (CLT) spesso **non
include `pip`/`venv` completi** → installa Python con Homebrew:

```bash
brew install python@3.11
```

---

## Scegli la modalità: casa o VPS

Questa scelta è la più importante perché cambia la qualità dei dati.

- **`INTERPELLI_HOME=1` — PC di casa** (consigliato): il soggetto degli
  avvisi (classi, ore, scadenza, link di candidatura) viene letto dalla
  piattaforma **Axios**, che funziona solo da indirizzi **residenziali**.
  È la modalità di default.
- **`INTERPELLI_HOME=0` — VPS/datacenter**: da un IP datacenter Axios è
  bloccato (Cloudflare 403), quindi il soggetto è *best-effort* e gli avvisi
  senza dettaglio affidabile sono marcati **"da verificare"** (con link a
  1 tocco per controllare in 10 secondi). Resta comunque un indice completo.

> 💡 **Consiglio**: se puoi, fai girare Interpelly a casa (anche su un vecchio
> Mac sempre acceso). La qualità del soggetto è nettamente migliore.

---

## Metodo A — App desktop (Electron) — consigliato

Il modo più semplice per l'utente finale: **un'icona → tutto acceso**. Il
wrapper Electron **avvia da solo il backend FastAPI** come processo figlio,
apre la dashboard in una finestra nativa e resta in **tray** come monitor
sempre acceso (chiudere la finestra **non** esce: si esce dal menu di tray).

### A1. Installer pronto (macOS / Windows / Linux)

L'installer includerà il progetto con il venv accanto. Una volta installata,
avvia **Interpelly.app** (`.exe` su Windows, AppImage su Linux): si apre la
bacheca e tutto il resto (backend, tray, monitor) parte da solo.

- **macOS — Gatekeeper** (app non firmata): tasto destro sull'app → *Apri*;
  oppure `codesign --deep --force --sign - dist/*.app`.
- **Avvio al login (GUI)**: aggiungi l'app a *Elementi di login* — resta in
  tray.

Per generare gli installer dal codice:

```bash
cd desktop
npm install
npm run dist:win          # .exe (NSIS + portable)
npm run dist:mac          # .dmg + .zip
npm run dist:linux        # AppImage
```

(Con **Bun**, più veloce: `bun install` e `bun run dist:mac` ecc.)

### A2. In sviluppo (prova rapida)

```bash
cd desktop
npm install
npm start                 # avvia l'app (backend incluso)
```

### Comportamento dell'app

- `INTERPELLI_LOOP=1` avvia anche il **loop orario** (ingest+scan+notifiche)
  insieme all'app.
- Menu tray: *Apri la bacheca* / *Esegui ingest ora* / *Esci*.
- Quando l'app è **impacchettata** (`.app`/`.exe`), usa il checkout reale del
  progetto con il venv accanto (`~/interpelly` o la cartella del repo) così
  database e dipendenze persistono — vedi `desktop/backend.js`.

---

## Metodo B — macOS con Homebrew

Esegui, in un terminale:

```bash
# 1. aggiungi il tap ufficiale e installa
brew tap eliobenigni7/interpelly
brew install interpelly

# 2. (consigliato) imposta le notifiche Telegram
cp "$(brew --prefix)/var/lib/interpelly/.env.example" ~/.interpelly.env
#    → apri ~/.interpelly.env e valorizza TG_TOKEN / TG_CHAT (vedi sezione Notifiche)

# 3. avvia il monitor come servizio (ingest + scan + notifiche, ogni ora,
#    avvio automatico al login)
brew services start interpelly
```

Dopo l'installazione hai a disposizione tre comandi:

```bash
interpelly            # avvia la dashboard web → http://localhost:8000
interpelly-ingest     # ingest singolo (scansione manuale ora)
interpelly-scan       # scan delle scuole secondarie II di Milano
```

- I **dati** (database SQLite) stanno in
  `$(brew --prefix)/var/lib/interpelly` e **persistono** agli aggiornamenti.
- Il servizio lancia `interpelly-loop --interval 1 --scan --notify` con
  `keep_alive`: si riavvia da solo se muore.
- Le **notifiche** sono lette da `~/.interpelly.env` sia dai comandi sia dal
  servizio.

**Aggiornare**

```bash
brew update && brew upgrade interpelly && brew services restart interpelly
```

---

## Metodo C — One-liner (macOS / Linux, senza brew)

Se non vuoi (o non puoi) usare Homebrew:

```bash
curl -fsSL https://raw.githubusercontent.com/eliobenigni7/homebrew-interpelly/main/install.sh | bash
```

Lo script scarica l'archivio pubblico in `~/interpelly`, crea il **venv** con
le dipendenze e stampa i comandi pronti da usare. In pratica:

```bash
# dashboard web
~/interpelly/.venv/bin/python -m uvicorn web.app:app --host 0.0.0.0 --port 8000
# → http://localhost:8000

# monitoraggio continuo (ingest + scan + notifiche, ogni ora)
~/interpelly/.venv/bin/python run_loop.py --interval 1 --scan --notify
```

Le notifiche si configurano creando `~/.interpelly.env` (copia di
`~/interpelly/.env.example`) con `TG_TOKEN` / `TG_CHAT`.

---

## Metodo D — Da sorgente (sviluppo)

```bash
git clone https://github.com/eliobenigni7/interpelly.git
cd interpelly

python3 -m venv .venv
source .venv/bin/activate            # Windows: .venv\Scripts\activate
pip install -r requirements.txt

python3 run_ingest.py --capture-sample   # primo ingest (vedi sotto)
python3 -m uvicorn web.app:app --host 0.0.0.0 --port 8000
```

---

## Metodo E — Docker / VPS

Per un server (VPS, Coolify, Dokploy):

```bash
docker compose up -d --build
```

- Il container `ingest` fa il primo ingest + il **loop orario** in modalità
  **VPS** (`INTERPELLI_HOME=0`, Axios degradato).
- Il container `web` serve la dashboard su **:8000** (basic auth opzionale
  con `DASHBOARD_USER` / `DASHBOARD_PASS`).
- Volume condiviso `interpelli_data` per il database.
- Su **Coolify/Dokploy**: importa la repo, porta 8000, env come da
  `docker-compose.yml`.

---

## Primo avvio e verifica

```bash
# 1. (consigliato) imposta le notifiche Telegram
export TG_TOKEN="123456:ABC..." TG_CHAT="123456789"

# 2. primo ingest completo — in modalità home legge anche Axios.
#    --capture-sample salva alcuni campioni (data/samples/) per calibrare
#    il parser: fallo al primo avvio, poi puoi toglierlo.
python3 run_ingest.py --capture-sample

# 3. dashboard web
python3 -m uvicorn web.app:app --host 0.0.0.0 --port 8000
#    → apri http://localhost:8000 nel browser

# 4. monitoraggio continuo (ingest + scan + notifiche, ogni ora)
python3 run_loop.py --interval 1 --scan --notify
```

**Con l'app desktop** tutti i passaggi 2–4 sono automatici: lanci l'app e il
backend + il loop orario (se `INTERPELLI_LOOP=1`) si avviano da soli.

**Verifica che tutto funzioni**

```bash
curl -s http://localhost:8000/api/health
# → {"ok":true, "last_ingest":"…", "failures":0, "age_hours":…}
```

Se `ok:true` e `failures:0`, l'installazione è sana. La dashboard mostra
anche i conteggi (avvisi / sostegno / francese) e un indicatore dell'ultima
scansione.

---

## Configurazione (.env)

Tutte le variabili sono **opzionali**; si passano come variabili d'ambiente o
in un file `.env` nella cartella del progetto (copia di esempio:
`.env.example`). In modalità Homebrew/one-liner le notifiche si leggono da
`~/.interpelly.env`.

| Variabile | Default | Descrizione |
|---|---|---|
| `INTERPELLI_HOME` | `1` | `1` = IP residenziale (Axios attivo) · `0` = VPS (Axios degradato) |
| `INTERPELLI_PROVINCES` | `MILANO` | province da monitorare: `MILANO,BERGAMO,BRESCIA,…` |
| `TG_TOKEN` / `TG_CHAT` | — | notifiche Telegram (token bot / chat id) |
| `SMTP_HOST` `SMTP_USER` `SMTP_PASS` `SMTP_TO` `SMTP_PORT` | — | digest email giornaliero (`--digest-email`) |
| `DASHBOARD_USER` / `DASHBOARD_PASS` | — | basic auth per la dashboard (accesso remoto) |
| `AI_API_KEY` `AI_BASE_URL` `AI_MODEL` | — | estrazione AI/LLM degli avvisi (OpenAI-compatible: OpenRouter, Gemini, Ollama…). L'on/off si gestisce dalla pagina *Impostazioni* della dashboard (non serve env) |
| `TESSERACT_CMD` `PDFTOTPM_CMD` | — | OCR per avvisi in scansione (opzionale; richiede poppler + tesseract) |
| `INTERPELLI_PORT` | `8000` | porta per l'app desktop |
| `INTERPELLI_LOOP` | — | con l'app desktop, avvia anche il loop orario (ingest+scan+notifiche) |
| `INTERPELLI_PYTHON` | — | percorso del python del venv, per l'app desktop |

---

## Avvio automatico al login

Se vuoi che il monitor parta da solo all'accensione del computer (senza
aprire la finestra), usa i file in `contrib/`:

**macOS — launchd (headless)**

```bash
mkdir -p ~/Library/LaunchAgents
sed 's/UTENTE/'"$USER"'/g' contrib/com.bacheca.interpelli.plist \
    > ~/Library/LaunchAgents/com.bacheca.interpelli.plist
launchctl load ~/Library/LaunchAgents/com.bacheca.interpelli.plist
```

In alternativa, con la GUI: aggiungi *Interpelly.app* a
*Impostazioni di sistema → Utenti e gruppi → Elementi di login* (resta in
tray).

**Windows**

```bash
# con la GUI: scorciatoia dell'exe Interpelly in shell:startup
#   (Win+R → shell:startup → incolla la scorciatoia)
# oppure headless: scorciatoia di contrib/avvio_bacheca_windows.bat
```

**Linux — systemd (user)**

```bash
mkdir -p ~/.config/systemd/user
cp contrib/interpelli.service ~/.config/systemd/user/
systemctl --user daemon-reload
systemctl --user enable --now interpelli.service
loginctl enable-linger $USER   # avvio al boot senza login
```

---

## Notifiche Telegram

1. Apri **BotFather** su Telegram, invia `/newbot`, scegli un nome e uno
   username per il bot → ricevi il **token** (`123456:ABC-…`).
2. Apri il bot, premi *Avvia* (crea la chat).
3. Ottieni il **chat id**: invia un messaggio al bot e poi apri
   `https://api.telegram.org/bot<TOKEN>/getUpdates` → nell'oggetto
   `chat.id` trovi l'id (es. `123456789`).
4. Inserisci i valori in `~/.interpelly.env` (o `.env`):
   ```
   TG_TOKEN=123456:ABC-…
   TG_CHAT=123456789
   ```
5. Riavvia il loop (`brew services restart interpelly` o
   `run_loop.py --interval 1 --scan --notify`).

Le notifiche arrivano per i nuovi avvisi pertinenti al profilo (con soglia di
match), con i pulsanti *Candidatura / Albo / Avviso*. C'è anche un reminder
24 h prima della scadenza.

---

## Dashboard remota e sicurezza

Per raggiungere la dashboard dal telefono (stessa rete o da internet),
proteggila con basic auth:

```
DASHBOARD_USER=interpelly
DASHBOARD_PASS=una-password-lunga
```

Con Docker la porta è già esposta su :8000; da casa puoi esporre la porta o
usare un tunnel. La dashboard è una **PWA**: da telefono, *Aggiungi a
schermata Home* per averla come app.

---

## Problemi comuni

**`No module named pip` / `venv` non funziona (macOS)**
Il `python3` del sistema manca dei moduli completi. Installa Python con
Homebrew: `brew install python@3.11` e riprova.

**Axios / soggetto "da verificare" ovunque (VPS o rete datacenter)**
Normale: da IP datacenter la piattaforma Axios risponde 403 (Cloudflare).
Imposta `INTERPELLI_HOME=0` e accetta il soggetto *best-effort*, oppure
sposta il monitor su un IP residenziale.

**La porta 8000 è già occupata**
Cambia porta con `INTERPELLI_PORT=8001` (desktop) o avvia uvicorn su un'altra
porta: `--port 8001`.

**Estate: non arriva quasi nessun avviso nuovo**
Non è un bug: gli interpelli si fermano a giugno e ripartono a settembre. A
luglio-agosto il volume è ~zero.

**La dashboard non carica gli avvisi**
Controlla che il loop/ingest sia in corso e che il database esista:
`curl -s http://localhost:8000/api/health`. Se `failures` cresce, guarda i
log (`data/ingest.log`).

---

Interpelly è un progetto open-source: segnalazioni e migliorie in
[github.com/eliobenigni7/interpelly](https://github.com/eliobenigni7/interpelly).