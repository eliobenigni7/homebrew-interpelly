/**
 * updater.js — Interpelly: controllo automatico degli aggiornamenti.
 *
 * La sorgente è la repo PUBBLICA del tap Homebrew (homebrew-interpelly):
 * le release di una repo privata non sono raggiungibili senza account
 * GitHub, questa sì — e lì pubblichiamo anche gli installer.
 *
 *   - al primo avvio (dopo 15s) e poi ogni 6 ore, in silenzio;
 *   - se esiste una versione più nuova → notifica di sistema + dialogo
 *     "Scarica ora" (apre il download dell'installer per la piattaforma);
 *   - voce di tray "Verifica aggiornamenti" per il check manuale;
 *   - disattivabile con INTERPELLY_NO_UPDATES=1.
 *
 * Eseguibile anche da CLI per test:  node updater.js --check
 */
"use strict";

const path = require("path");

const UPDATE_URL =
  "https://api.github.com/repos/eliobenigni7/homebrew-interpelly/releases/latest";
const CHECK_INTERVAL_MS = 6 * 60 * 60 * 1000; // ogni 6 ore
const FIRST_CHECK_DELAY_MS = 15 * 1000;       // 15s dopo l'avvio dell'app
const FETCH_TIMEOUT_MS = 12 * 1000;

const APP_VERSION = (() => {
  try { return require("electron").app.getVersion(); } catch (_) {
    try { return require(path.join(__dirname, "package.json")).version; } catch (__) { return "0.0.0"; }
  }
})();

let lastNotified = ""; // versione già segnalata: niente notifiche ripetute
let quitting = false;

/* ---------- semver ---------- */
function parseTag(tag) {
  return String(tag || "").replace(/^v/i, "").trim();
}
function semverCmp(a, b) {
  const pa = String(a || "0").split(".").map((n) => parseInt(n, 10) || 0);
  const pb = String(b || "0").split(".").map((n) => parseInt(n, 10) || 0);
  for (let i = 0; i < 3; i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d !== 0) return d;
  }
  return 0;
}

/* ---------- quale installer per questa piattaforma ---------- */
function platformAsset(assets) {
  const all = Array.isArray(assets) ? assets : [];
  const nm = (a) => String(a.name || "").toLowerCase();
  if (process.platform === "darwin") return all.find((a) => nm(a).endsWith(".dmg")) || null;
  if (process.platform === "win32") {
    return all.find((a) => nm(a).includes("setup")) || all.find((a) => nm(a).endsWith(".exe")) || null;
  }
  if (process.platform === "linux") return all.find((a) => nm(a).endsWith(".appimage")) || null;
  return null;
}

/* ---------- fetch con timeout ---------- */
async function fetchLatest() {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), FETCH_TIMEOUT_MS);
  try {
    const r = await fetch(UPDATE_URL, {
      headers: { "User-Agent": "Interpelly-Desktop", Accept: "application/vnd.github+json" },
      signal: ctrl.signal,
    });
    if (!r.ok) throw new Error("HTTP " + r.status);
    return await r.json();
  } finally {
    clearTimeout(t);
  }
}

/* ---------- check ---------- */
async function check() {
  const current = process.env.INTERPELLY_APP_VERSION || APP_VERSION;
  try {
    const rel = await fetchLatest();
    const latest = parseTag(rel.tag_name);
    if (!latest) return { current, error: "nessuna release trovata" };
    const asset = platformAsset(rel.assets || []);
    return {
      current,
      latest,
      newer: semverCmp(current, latest) < 0,
      asset_url: asset ? asset.browser_download_url : "",
      release_url: rel.html_url ||
        `https://github.com/eliobenigni7/homebrew-interpelly/releases/tag/${rel.tag_name}`,
    };
  } catch (e) {
    return { current, error: String((e && e.message) || e) };
  }
}

/* ---------- UI: notifica + dialogo ---------- */
function showDialog(update) {
  const { dialog, shell } = require("electron");
  const hasAsset = Boolean(update.asset_url);
  const r = dialog.showMessageBoxSync({
    type: "info",
    title: "Aggiornamento Interpelly",
    message: `Interpelly ${update.latest} è disponibile`,
    detail: `Stai usando la v${update.current}.` +
      (hasAsset
        ? "\nScarica l'installer per questa piattaforma e riavvia l'app."
        : "\nApri la pagina della release per scaricare l'installer."),
    buttons: ["Scarica ora", "Più tardi"],
    defaultId: 0,
    cancelId: 1,
    noLink: true,
  });
  if (r === 0) {
    const url = update.asset_url || update.release_url;
    if (url) shell.openExternal(url);
  }
}

function notify(update) {
  lastNotified = update.latest;
  const { Notification } = require("electron");
  if (!Notification.isSupported()) { showDialog(update); return; }
  const n = new Notification({
    title: "Aggiornamento Interpelly ✻",
    body: `La v${update.latest} è disponibile (hai la v${update.current}). Clicca per scaricare.`,
  });
  n.on("click", () => showDialog(update));
  n.show();
}

/* ---------- API per main.js ---------- */
async function checkAndMaybeNotify() {
  if (quitting || process.env.INTERPELLY_NO_UPDATES === "1") return;
  const u = await check();
  if (u.error) { console.log("[updater]", u.error); return; }
  console.log(`[updater] corrente=${u.current} latest=${u.latest} newer=${u.newer}`);
  if (u.newer && u.latest !== lastNotified) notify(u);
}

/** check manuale dalla tray: dialogo anche se aggiornato */
async function checkNow() {
  const { dialog } = require("electron");
  const u = await check();
  if (u.error) {
    dialog.showMessageBoxSync({
      type: "warning",
      title: "Verifica aggiornamenti",
      message: "Impossibile verificare gli aggiornamenti",
      detail: String(u.error),
      buttons: ["Ok"],
    });
    return u;
  }
  if (u.newer) { showDialog(u); }
  else {
    dialog.showMessageBoxSync({
      type: "info",
      title: "Verifica aggiornamenti",
      message: `Interpelly è aggiornato (v${u.current}).`,
      detail: "Ultima release controllata: " + (u.latest || "—"),
      buttons: ["Ok"],
    });
  }
  return u;
}

function start() {
  if (process.env.INTERPELLY_NO_UPDATES === "1") return;
  setTimeout(checkAndMaybeNotify, FIRST_CHECK_DELAY_MS);
  setInterval(checkAndMaybeNotify, CHECK_INTERVAL_MS);
}

function markQuitting() { quitting = true; }

module.exports = { check, checkNow, start, markQuitting, semverCmp, parseTag, APP_VERSION };

/* ---------- CLI: node updater.js --check ---------- */
if (require.main === module) {
  (async () => {
    const r = await check();
    console.log(JSON.stringify(r, null, 2));
    process.exit(r.error ? 1 : 0);
  })();
}