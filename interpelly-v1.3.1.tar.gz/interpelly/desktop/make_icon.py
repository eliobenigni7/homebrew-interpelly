"""Genera icona (numpy): carta crema, bordo carbone, asterisco vermiglio.
Nessun'altra dipendenza. Produce 16/256/512/1024 px in assets/."""
import os
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ASSETS = os.path.join(HERE, "assets")

CREAM = (241, 232, 212, 255)
VERM = (192, 57, 27, 255)
CARB = (26, 22, 17, 255)


def render(size):
    b = max(1, size // 40)
    ys, xs = np.mgrid[0:size, 0:size]
    xx = xs + 0.5
    yy = ys + 0.5
    c = size / 2.0
    img = np.zeros((size, size, 4), dtype=np.uint8)
    img[:] = CREAM
    # bordo
    img[:b, :] = CARB
    img[-b:, :] = CARB
    img[:, :b] = CARB
    img[:, -b:] = CARB
    # asterisco: distanza da 3 rette passanti per il centro
    r_half = size * 0.30
    w = max(2.0, size / 30.0)
    dist = np.full((size, size), np.inf)
    for ang in (0.0, np.pi / 3, 2 * np.pi / 3):
        co, si = np.cos(ang), np.sin(ang)
        d = np.abs(co * xx + si * yy)
        dist = np.minimum(dist, d)
    inside = np.hypot(xx - c, yy - c) <= r_half
    img[inside & (dist <= w / 2.0)] = VERM
    return img


def main():
    os.makedirs(ASSETS, exist_ok=True)
    for size, name in ((16, "icon_tray.png"), (256, "icon.png"),
                       (512, "icon_512.png"), (1024, "icon_1024.png")):
        # salva con stdlib (niente PIL): PNG grezzo + zlib
        data = render(size)
        raw = b""
        for y in range(size):
            raw += b"\x00" + data[y].tobytes()
        import struct, zlib

        def chunk(t, d):
            c = struct.pack(">I", len(d)) + t + d
            return c + struct.pack(">I", zlib.crc32(t + d))
        ihdr = struct.pack(">IIBBBBB", size, size, 8, 6, 0, 0, 0)
        png = (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", ihdr)
               + chunk(b"IDAT", zlib.compress(raw)) + chunk(b"IEND", b""))
        with open(os.path.join(ASSETS, name), "wb") as f:
            f.write(png)
        print(f"assets/{name} ok")


if __name__ == "__main__":
    main()