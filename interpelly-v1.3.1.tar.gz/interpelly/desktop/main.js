/**
 * main.js — Electron: "La bacheca del supplente" (desktop).
 *
 * Avvia il backend FastAPI (backend.js), apre la dashboard, resta in tray:
 * una icona, monitor sempre acceso. Chiudere la finestra NON esce dall'app
 * (il monitor continua); si esce dal menu di tray "Esci".
 *
 * Env utili:
 *   INTERPELLI_PORT    porta (default 8000)
 *   INTERPELLI_PYTHON  percorso esplicito del python (opzionale)
 *   INTERPELLI_LOOP=1  avvia anche run_loop.py (ingest+scan+notifiche orari)
 */
"use strict";

const { app, BrowserWindow, Tray, Menu, nativeImage, shell } = require("electron");
const path = require("path");
const { spawn } = require("child_process");
const backend = require("./backend.js");
const updater = require("./updater.js");

const ROOT = backend.ROOT;
let win = null;
let tray = null;
let loopChild = null;
let quitting = false;

app.setName("Interpelly");
app.setAppUserModelId("it.interpelly.app"); // notifiche su Windows

const ICON = path.join(__dirname, "assets", "icon.png");
const TRAY_ICON = path.join(__dirname, "assets", "icon_tray.png");

function createWindow(url) {
  win = new BrowserWindow({
    width: 1280,
    height: 860,
    minWidth: 960,
    minHeight: 620,
    title: "La bacheca del supplente",
    backgroundColor: "#1a1611",
    icon: ICON,
    autoHideMenuBar: true,
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  });
  win.loadURL(url);
  // i link esterni si aprono nel browser di sistema
  win.webContents.setWindowOpenHandler(({ url: u }) => {
    if (u.startsWith("http")) shell.openExternal(u);
    return { action: "deny" };
  });
  win.on("close", (e) => {
    if (!quitting) {
      e.preventDefault(); // chiudi la finestra, non lo scanner
      win.hide();
    }
  });
}

function createTray() {
  const img = nativeImage.createFromPath(TRAY_ICON);
  tray = new Tray(img);
  tray.setToolTip("La bacheca del supplente — Milano");
  const menu = Menu.buildFromTemplate([
    { label: "Apri la bacheca", click: () => { win.show(); win.focus(); } },
    {
      label: "Esegui ingest ora",
      click: () => runIngest(),
    },
    { type: "separator" },
    { label: `Verifica aggiornamenti (v${app.getVersion()})`, click: () => updater.checkNow() },
    { type: "separator" },
    { label: "Esci", click: () => { quitting = true; app.quit(); } },
  ]);
  tray.setContextMenu(menu);
  tray.on("click", () => { win.show(); win.focus(); });
}

function runIngest() {
  const python = process.env.INTERPELLI_PYTHON || "python3";
  const p = spawn(python, [path.join(ROOT, "run_ingest.py"), "--refresh", "--notify"],
                  { cwd: ROOT, windowsHide: true, stdio: "ignore" });
  p.on("exit", (code) => console.log(`[ingest manuale] uscito ${code}`));
}

function startLoop() {
  if (process.env.INTERPELLI_LOOP !== "1") return;
  const python = process.env.INTERPELLI_PYTHON || "python3";
  loopChild = spawn(python,
    [path.join(ROOT, "run_loop.py"), "--interval", "1", "--scan", "--watch", "--notify"],
    { cwd: ROOT, windowsHide: true, stdio: ["ignore", "pipe", "pipe"] });
  loopChild.stdout.on("data", (d) => process.stdout.write(`[loop] ${d}`));
  loopChild.stderr.on("data", (d) => process.stderr.write(`[loop] ${d}`));
}

app.whenReady().then(async () => {
  try {
    const url = await backend.start();
    createWindow(url);
    createTray();
    startLoop();
    updater.start(); // controllo aggiornamenti automatico (vedi updater.js)
  } catch (e) {
    console.error(e.message);
    const { dialog } = require("electron");
    dialog.showErrorBox(
      "Bacheca — backend non avviato",
      "Impossibile avviare il server locale.\n\n" + e.message +
      "\n\nVerifica l'installazione Python e le dipendenze (pip install -r requirements.txt).");
    app.quit();
  }

  app.on("activate", () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(backend.URL); });
});

app.on("window-all-closed", () => {
  // resta attivo in tray (monitor sempre acceso); niente quit automatico
});

app.on("before-quit", () => {
  quitting = true;
  updater.markQuitting();
  backend.stop();
  if (loopChild) { try { loopChild.kill(); } catch (_) {} }
});