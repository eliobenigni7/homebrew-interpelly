/**
 * backend.js — Avvia (o riusa) il backend FastAPI come processo figlio.
 *
 * Logica isolata da Electron per poterla testare con Node puro:
 *   node backend.js            # avvia e attende il backend, poi stampa lo stato
 *   node backend.js --kill     # termina il backend avviato
 *
 * Comportamento:
 *  - se su PORT c'è già un /api/stats che risponde, lo riusa (nessuno spawn);
 *  - altrimenti trova l'interprete Python (env INTERPELLI_PYTHON, poi .venv,
 *    poi python3/python) e avvia "python -m uvicorn web.app:app";
 *  - poll di salute fino a READY_TIMEOUT.
 */
"use strict";

const { spawn } = require("child_process");
const path = require("path");
const fs = require("fs");
const os = require("os");

/**
 * Radice del progetto: quando l'app è impacchettata (.app/.exe), le copie in
 * Resources/ sono statiche e SENZA venv: si preferisce il checkout reale con
 * il venv accanto (~/interpelli-milano o la cartella del repo), così DB e
 * dipendenze vivono dove l'utente li ha installati.
 */
function resolveRoot() {
  const here = path.resolve(__dirname, "..");
  if (fs.existsSync(path.join(here, "run_ingest.py"))) return here;
  const homeProject = path.join(os.homedir(), "interpelli-milano");
  if (fs.existsSync(path.join(homeProject, "run_ingest.py"))) return homeProject;
  return here;
}

const ROOT = resolveRoot();
const PORT = Number(process.env.INTERPELLI_PORT || 8000);
const URL = `http://127.0.0.1:${PORT}`;
const READY_TIMEOUT_MS = 90 * 1000;

let child = null;
const PID_FILE = path.join(__dirname, ".backend.pid");

function rememberPid(pid) {
  try { fs.writeFileSync(PID_FILE, String(pid)); } catch (_) {}
}

function forgetPid() {
  try { fs.rmSync(PID_FILE, { force: true }); } catch (_) {}
}

function candidatePythons() {
  const envPy = process.env.INTERPELLI_PYTHON;
  const venv =
    process.platform === "win32"
      ? path.join(ROOT, ".venv", "Scripts", "python.exe")
      : path.join(ROOT, ".venv", "bin", "python");
  const pool = [];
  if (envPy) pool.push(envPy);
  if (fs.existsSync(venv)) pool.push(venv);
  if (process.platform === "darwin") {
    // Homebrew (Apple Silicon / Intel) prima del python3 di sistema
    pool.push("/opt/homebrew/bin/python3", "/usr/local/bin/python3");
  }
  pool.push(process.platform === "win32" ? "python" : "python3", "python");
  return pool;
}

async function isHealthy(timeoutMs = 2500) {
  try {
    const ctl = new AbortController();
    const t = setTimeout(() => ctl.abort(), timeoutMs);
    const r = await fetch(`${URL}/api/stats`, { signal: ctl.signal });
    clearTimeout(t);
    return r.status === 200;
  } catch {
    return false;
  }
}

/** Avvia `python -m uvicorn` nel progetto, con log prefissati. */
function spawnBackend(python) {
  const args = ["-m", "uvicorn", "web.app:app", "--host", "127.0.0.1", "--port", String(PORT)];
  console.log(`[backend] avvio: ${python} ${args.join(" ")}`);
  child = spawn(python, args, {
    cwd: ROOT,
    env: { ...process.env, INTERPELLI_HOME: process.env.INTERPELLI_HOME || "1" },
    stdio: ["ignore", "pipe", "pipe"],
    windowsHide: true,
  });
  child.stdout.on("data", (d) => process.stdout.write(`[backend] ${d}`));
  child.stderr.on("data", (d) => process.stderr.write(`[backend] ${d}`));
  child.on("exit", (code, sig) => {
    console.log(`[backend] uscito (code=${code} sig=${sig})`);
    child = null;
    forgetPid();
  });
  rememberPid(child.pid);
}

/** Ritorna l'URL pronto; avvia il backend se serve. */
async function start() {
  if (await isHealthy()) {
    console.log(`[backend] già attivo su ${URL} — niente spawn`);
    return URL;
  }
  let lastErr = null;
  for (const py of candidatePythons()) {
    try {
      spawnBackend(py);
      const t0 = Date.now();
      while (Date.now() - t0 < READY_TIMEOUT_MS) {
        if (child === null) break; // il processo è uscito subito -> prova altro interpretre
        if (await isHealthy()) {
          console.log(`[backend] pronto su ${URL}`);
          return URL;
        }
        await new Promise((r) => setTimeout(r, 600));
      }
      if (child !== null) {
        child.kill();
        child = null;
      }
    } catch (e) {
      lastErr = e;
    }
  }
  throw new Error(`Backend non avviato (ultimo errore: ${lastErr || "timeout"})`);
}

function stop() {
  let pid = child ? child.pid : null;
  if (!pid) {
    try { pid = Number(fs.readFileSync(PID_FILE, "utf8")); } catch (_) { pid = null; }
  }
  if (pid) {
    console.log(`[backend] chiusura pid ${pid}…`);
    try {
      if (process.platform === "win32") {
        spawn("taskkill", ["/pid", String(pid), "/T", "/F"], { windowsHide: true });
      } else {
        process.kill(pid, "SIGTERM");
      }
    } catch (e) {
      console.log(`[backend] già terminato (${e.message})`);
    }
  }
  child = null;
  forgetPid();
}

if (require.main === module) {
  if (process.argv.includes("--kill")) {
    stop();
  } else {
    start()
      .then((u) => {
        console.log(`URL=${u}`);
        if (!process.env.KEEP_ALIVE) process.exit(0);
      })
      .catch((e) => {
        console.error(e.message);
        process.exit(1);
      });
  }
}

module.exports = { start, stop, URL, ROOT };