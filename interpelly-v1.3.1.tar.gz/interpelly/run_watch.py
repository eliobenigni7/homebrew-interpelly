"""
run_watch.py — Fast-poll delle scuole in watchlist (⭐).

Le scuole seguite vengono interrogate ogni N minuti (default 15) sui loro siti
istituzionali: se compare un nuovo interpello, arriva subito la notifica —
i posti scadono in 24-48h, la velocità sulle scuole preferite fa la differenza.

Uso:
  python3 run_watch.py [--interval 15] [--notify] [--once] [--verbose]
"""

from __future__ import annotations

import argparse
import sys
import time
from datetime import datetime
import os
from pathlib import Path

import requests

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from ingest.store import Store  # noqa: E402
from ingest.scuole_scan import scan_site  # noqa: E402
from ingest.schools import school_site  # noqa: E402
from ingest.config import TARGETS  # noqa: E402
from ingest import notify  # noqa: E402
from scan_scuole import _persist_found  # noqa: E402

DB = Path(os.environ.get("INTERPELLY_DB", str(ROOT / "data" / "interpelli.db")))


def poll_once(store: Store, verbose: bool = False) -> list:
    """Scannerizza i siti delle scuole in watchlist. Ritorna i nuovi target."""
    watched = store.watched_schools()
    if not watched:
        return []
    rq = requests.Session()
    rq.headers.update({"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/124"})
    found_new = []
    for name in sorted(watched):
        domain = store.school_domain(name)
        if not domain:
            domain = school_site(rq, name)
            if not domain:
                continue
            store.upsert_school(name, domain=domain)
        try:
            sc = scan_site(rq, domain, [name], max_sections=2, max_pdfs=2,
                           recent_days=14)
        except Exception:
            continue
        for f in sc.found:
            existed = store.conn.execute(
                "SELECT 1 FROM interpelli WHERE detail_url=?",
                (f.entry.url,)).fetchone() is not None
            _persist_found(store, sc, f)
            if not existed and f.subject in TARGETS:
                found_new.append({"school": name, "subject": f.subject,
                                  "title": f.entry.title, "url": f.entry.url,
                                  "_watch": True})
        if verbose and sc.found:
            print(f"  ⭐ {name[:40]}: {[f.subject for f in sc.found]}")
    store.merge_duplicates()
    return found_new


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--interval", type=int, default=15, help="minuti tra i poll")
    ap.add_argument("--notify", action="store_true")
    ap.add_argument("--once", action="store_true")
    ap.add_argument("--verbose", action="store_true")
    args = ap.parse_args()

    store = Store(DB)
    if not store.watched_schools():
        print("  nessuna scuola in watchlist — aggiungile con la ⭐ nella dashboard")
    cycle = 0
    while True:
        cycle += 1
        t0 = time.time()
        try:
            new = poll_once(store, args.verbose)
            if args.notify and new:
                n = notify.notify_interpelli(new)
                print(f"[{datetime.now():%H:%M}] poll #{cycle}: {len(new)} nuovi "
                      f"→ {n} notifiche")
        except KeyboardInterrupt:
            print("  interrotto.")
            return 0
        if args.once:
            store.close()
            return 0
        time.sleep(args.interval * 60 - min(time.time() - t0, args.interval * 60 - 5))


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        raise SystemExit(0)