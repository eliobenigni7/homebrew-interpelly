"""Test dello store SQLite (su file temporaneo)."""
import sys, os, tempfile
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from ingest.store import Store
from ingest.mim import Interpello


def _store():
    d = tempfile.mkdtemp()
    return Store(os.path.join(d, "t.db"))


def test_upsert_e_dedup():
    s = _store()
    i = Interpello(date=None, date_str="17 giugno 2026",
                   school="IC Test - MILANO", grade="",
                   detail_url="https://mim/1", subject="sostegno", confidence=1.0)
    s.upsert_interpello(i, {"provincia": "MILANO"})
    assert len(s.interpelli()) == 1
    # stesso URL -> aggiorna, non duplica
    i2 = Interpello(date=None, date_str="17 giugno 2026",
                    school="IC Test - MILANO", grade="",
                    detail_url="https://mim/1", subject="francese", confidence=1.0)
    s.upsert_interpello(i2, {"provincia": "MILANO"})
    rows = s.interpelli()
    assert len(rows) == 1 and rows[0]["subject"] == "francese"


def test_filtri():
    s = _store()
    for i, subj, prov in [(1, "sostegno", "MILANO"), (2, "francese", "BERGAMO")]:
        s.upsert_interpello(
            Interpello(date=None, date_str="1 giugno 2026",
                       school=f"IC {i} - MILANO", grade="", detail_url=f"https://mim/{i}",
                       subject=subj, confidence=1.0),
            {"provincia": prov})
    assert len(s.interpelli(subject="sostegno")) == 1
    assert len(s.interpelli(subject="francese")) == 1
    assert len(s.interpelli(subject="francese", school="IC 2")) == 1


def test_meta():
    s = _store()
    s.set_meta("k", "v")
    assert s.get_meta("k") == "v"
    assert s.get_meta("nope", "def") == "def"


def test_watchlist():
    s = _store()
    s.upsert_school("IC X - MILANO")
    s.set_watch("IC X - MILANO", True)
    assert "IC X - MILANO" in s.watched_schools()