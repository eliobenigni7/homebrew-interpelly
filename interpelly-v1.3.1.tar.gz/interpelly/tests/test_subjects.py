"""Test del classificatore soggetto (francese/sostegno)."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from ingest.subjects import classify


def test_sostegno_da_testo():
    assert classify("Interpello per supplenza docenti di sostegno")[0] == "sostegno"


def test_francese_da_classe():
    s, c = classify("Supplenza classe di concorso AA24")
    assert s == "francese" and c >= 1.0


def test_sostegno_da_codice():
    assert classify("Posto ADEE scuola primaria")[0] == "sostegno"


def test_altro_nessuna_materia():
    s, c = classify("Avviso ordinario di fine anno scolastico")
    assert s == "altro" and c < 1.0


def test_inglese_non_target():
    # AB25 è inglese: non deve mai dare francese/sostegno
    s, _ = classify("Classe AB25 lingua inglese")
    assert s != "sostegno"


def test_non_falso_negativo_sostegno_con_nome_scuola():
    blob = "IC Don Milani Interpello Infanzia Sostegno Categorie Interpelli ricerca supplenti"
    assert classify(blob)[0] == "sostegno"