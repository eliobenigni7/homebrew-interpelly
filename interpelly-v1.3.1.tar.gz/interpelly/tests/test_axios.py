"""Test del parser Axios (pagina ASPX sintetica)."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from ingest.axios import parse_axios_html

PAGE = """<html><body><form action="CandidaturaInterpello.aspx?id=123">
<div><h2>IC Schweitzer - SEGRATE</h2>
<p>Docente di Sostegno - Scuola Primaria</p>
<p>Classe di concorso: ADEE</p>
<p>Ore settimanali: 24 ore</p>
<p>Periodo: dal 01/09/2026 al 30/06/2027</p>
<p>Scadenza candidature: 20/08/2026</p>
<p>Comune di Segrate (MI)</p></div>
<a href="javascript:__doPostBack('CandidaturaInterpello.aspx?id=123')">CANDIDATI</a>
<a href="AvvisoInterpello.pdf">avviso</a>
</form></body></html>"""


def test_campi_strutturati():
    r = parse_axios_html(PAGE)
    assert r.ok and not r.blocked
    assert r.classi == ["ADEE"]
    assert r.ore == "24"
    assert r.scadenza == "2026-08-20"
    assert "01/09/2026" in r.periodo
    assert r.tipo_scuola == "primaria"


def test_link_candidatura_da_postback():
    r = parse_axios_html(PAGE)
    assert r.link_candidatura == "CandidaturaInterpello.aspx?id=123"


def test_allegati():
    r = parse_axios_html(PAGE)
    assert any("AvvisoInterpello.pdf" in u for u in r.allegati)


def test_comune():
    r = parse_axios_html(PAGE)
    assert r.comune.lower() == "segrate"


def test_cloudflare_block():
    r = parse_axios_html("<html><title>Attention Required! | Cloudflare</title></html>")
    assert r.blocked and not r.ok