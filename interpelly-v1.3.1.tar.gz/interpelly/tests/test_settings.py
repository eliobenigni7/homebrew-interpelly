"""Test delle impostazioni AI (store + API con chiave mascherata)."""
import os
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest


@pytest.fixture()
def store():
    from ingest.store import Store
    d = tempfile.mkdtemp()
    return Store(os.path.join(d, "t.db"))


def test_impostazioni_default(store):
    s = store.get_settings()
    assert s["AI_API_KEY"] == "" and s["AI_MODEL"] == ""


def test_salva_e_cancella(store):
    store.set_settings({"AI_API_KEY": "sk-prova-1234", "AI_MODEL": "modello-x"})
    assert store.get_settings()["AI_API_KEY"] == "sk-prova-1234"
    eff = store.ai_effective()
    assert eff["AI_MODEL"] == "modello-x"
    assert eff["AI_BASE_URL"] == "https://openrouter.ai/api/v1"  # default
    # chiave vuota la cancella
    store.set_settings({"AI_API_KEY": ""})
    assert store.get_settings()["AI_API_KEY"] == ""


def test_api_maschera_chiave():
    from unittest import mock
    d = tempfile.mkdtemp()
    os.environ["INTERPELLY_DB"] = os.path.join(d, "api.db")
    from web.app import app
    from fastapi.testclient import TestClient

    with TestClient(app) as c:
        r = c.post("/api/settings", json={"ai": {
            "AI_API_KEY": "sk-secret-1234", "AI_MODEL": "openrouter/auto"}})
        assert r.status_code == 200 and r.json()["ok"]
        r = c.get("/api/settings")
        body = r.json()["ai"]
        assert body["has_key"] and body["key_tail"] == "1234"
        assert "sk-secret-1234" not in r.text          # chiave mai esposta
        # test endpoint: chiave vuota -> usa la salvata; _call mockata
        with mock.patch("ingest.ai._call",
                        return_value={"subject": "francese", "classi": ["AA24"]}):
            r = c.post("/api/settings/test", json={"ai": {
                "AI_API_KEY": "", "AI_MODEL": "openrouter/auto"}})
            assert r.status_code == 200 and r.json()["ok"]