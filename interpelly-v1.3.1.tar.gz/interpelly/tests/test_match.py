"""Test di scadenze, matching profilo, crawler MIM e reclassificazione offline."""

import sys
import tempfile
from datetime import date, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from ingest.enrich import extract_fields, scadenza_from_text
from ingest.match import match_score, top_matches
from ingest.mim import Interpello, fetch_detail
from ingest.store import Store
from run_ingest import reclassify


def test_scadenze_estese():
    # scadenza esplicita: affidabile
    assert scadenza_from_text("scadenza candidature: 20/08/2026") == "2026-08-20"
    assert scadenza_from_text("termine candidature 20/08/2026") == "2026-08-20"
    assert scadenza_from_text("entro le ore 12:00 del 20/08/2026") == "2026-08-20"
    # "fino al X" senza contesto candidatura: NON è una scadenza (periodo lavorativo)
    assert scadenza_from_text("FINO AL 24.06.2026") == ""
    # "dal … al …" è un periodo lavorativo, mai una scadenza
    assert scadenza_from_text("dal 10/06/2026 al 19/06/2026") == ""
    # "fino al" con contesto di candidatura nelle vicinanze: scadenza
    assert scadenza_from_text("presentazione domande fino al 24.06.2026") == "2026-06-24"


def test_extract_fields_journal_content():
    fields = extract_fields(
        "Interpello Infanzia Sostegno, classe ADEE, 12 ore, "
        "candidature fino al 24.06.2026, comune di Milano"
    )
    assert fields["classi"] == ["ADEE"]
    assert fields["ore"] == "12"
    assert fields["scadenza"] == "2026-06-24"
    assert fields["comune"].lower() == "milano"


def test_fetch_detail_usa_corpo_mim_e_titolo():
    class Session:
        def get(self, _url):
            return (
                '<main>Home Chi siamo Comunicazioni</main>'
                '<div class="journal-content-article">'
                '<div class="post-content">'
                '<p>Interpello Infanzia Sostegno</p>'
                '<p>Classe ADEE fino al 24/06/2026</p>'
                '<a href="https://servizi.axioscloud.it/avviso">Link Interpello</a>'
                "</div></div>"
            )

    item = Interpello(date=None, date_str="", school="IC Test", detail_url="https://mim/test")
    fetch_detail(Session(), item)
    assert item.grade == "Interpello Infanzia Sostegno"
    assert "Home Chi siamo" not in item.raw_text
    assert "Classe ADEE" in item.raw_text
    assert item.axios_url.endswith("/avviso")


def test_match_perfect_subject_and_class():
    row = {"subject": "sostegno", "classi_concorso": ["ADEE"]}
    profile = {"soggetti": "sostegno", "classi": "ADEE"}
    assert match_score(row, profile)["score"] >= 80


def test_match_no_criteria_is_zero():
    result = match_score({"subject": "sostegno", "classi_concorso": ["ADEE"]}, {})
    assert result == {"score": 0, "label": "—", "reasons": []}


def test_match_comune_and_urgenza():
    row = {
        "subject": "altro",
        "school": "IC Test - SAN DONATO MILANESE",
        "comune": "San Donato Milanese",
        "scadenza_iso": (date.today() + timedelta(days=3)).isoformat(),
    }
    result = match_score(row, {"comuni": "san donato milanese"})
    assert result["score"] == 20
    assert any("Scuola a San Donato Milanese" in r for r in result["reasons"])
    assert any("Scade tra 3 giorni" in r for r in result["reasons"])


def test_top_matches_excludes_zero_and_sorts():
    rows = [
        {"subject": "altro", "date_iso": "2026-08-10"},
        {"subject": "sostegno", "date_iso": "2026-08-09"},
    ]
    result = top_matches(rows, {"soggetti": "sostegno"})
    assert len(result) == 1 and result[0]["match"]["score"] == 50


def test_profile_roundtrip():
    db = Path(tempfile.mkdtemp()) / "profile.db"
    store = Store(db)
    store.set_profile({
        "soggetti": "francese,sostegno",
        "classi": "AA24,ADEE",
        "comuni": "milano,san donato milanese",
        "grado": "infanzia",
    })
    profile = store.get_profile()
    assert profile["soggetti"] == "francese,sostegno"
    assert profile["classi"] == "AA24,ADEE"
    assert profile["comuni"] == "milano,san donato milanese"
    assert profile["grado"] == "infanzia"


def test_reclassify_updates_only_target():
    db = Path(tempfile.mkdtemp()) / "reclassify.db"
    store = Store(db)
    base = dict(date=None, date_str="", school="IC Test", grade="", confidence=0)
    store.upsert_interpello(Interpello(
        detail_url="https://mim/target", subject="da_verificare",
        raw_text="Interpello per supplenza docenti di sostegno", **base))
    store.upsert_interpello(Interpello(
        detail_url="https://mim/other", subject="da_verificare",
        raw_text="Avviso ordinario di fine anno scolastico", **base))
    assert reclassify(store) == 1
    rows = {r["detail_url"]: r for r in store.interpelli()}
    assert rows["https://mim/target"]["subject"] == "sostegno"
    assert rows["https://mim/other"]["subject"] == "da_verificare"
