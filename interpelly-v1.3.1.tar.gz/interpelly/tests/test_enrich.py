"""Test di enrich: comune, tipo, classi, extract_fields."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from ingest.enrich import (comune_from_name, tipo_from_grade,
                           classi_from_text, subject_from_classi,
                           extract_fields)


def test_comune_da_nome():
    assert comune_from_name("IC Schweitzer - SEGRATE") == "SEGRATE"
    assert comune_from_name("IC Arbe Zara - MILANO") == "MILANO"


def test_comune_da_codice():
    assert comune_from_name("MIIC860003 - S.PELLICO-ARLUNO") == "ARLUNO"


def test_tipo_da_grado():
    assert tipo_from_grade("Interpello Infanzia Sostegno") == "infanzia"
    assert tipo_from_grade("Posto comune", "scuola primaria") == "primaria"


def test_classi_da_testo():
    assert "AA24" in classi_from_text("Classe AA24 Francese")
    assert "ADEE" in classi_from_text("Posto ADEE")


def test_soggetto_da_classi():
    assert subject_from_classi(["AA24", "ADMM"]) == "francese"
    assert subject_from_classi(["A26"]) is None


def test_extract_fields_scadenza_ore():
    f = extract_fields("ore settimanali 12,5 - dal 01/09/2026 al 30/06/2027 "
                       "scadenza candidature 20/08/2026 - comune di Bresso")
    assert f["ore"] == "12.5"
    assert f["scadenza"] == "2026-08-20"
    assert "01/09/2026" in f["periodo"]
    assert f["comune"].lower() == "bresso"
    assert f["tipo_scuola"] == "secondaria_ii" or f["tipo_scuola"] == ""