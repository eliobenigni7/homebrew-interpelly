"""Test di norm, merge duplicati, health e bozza domanda."""
import os
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest


def test_canonical_nomi():
    from ingest.norm import canonical, norm_key
    assert canonical("MIIC860003 - S.PELLICO-ARLUNO") == "S.Pellico-Arluno"
    assert canonical('IC "Albert Schweitzer" - SEGRATE') == "IC Albert Schweitzer - Segrate"
    assert canonical("ISTITUTO COMPRENSIVO DI VILLA CORTESE") == "Istituto Comprensivo di Villa Cortese"
    assert canonical("IC Arbe Zara - MILANO") == "IC Arbe Zara - Milano"
    # chiave invariante tra varianti
    assert norm_key("IC SCHWEITZER - SEGRATE") == norm_key("ic schweitzer segrate")


def test_merge_duplicati():
    from datetime import datetime
    from ingest.store import Store
    from ingest.mim import Interpello
    d = tempfile.mkdtemp()
    s = Store(os.path.join(d, "t.db"))
    base = dict(date=datetime(2026, 6, 17), date_str="17 giugno 2026",
                school="X - MILANO", grade="", confidence=1.0)
    s.upsert_interpello(Interpello(detail_url="https://mim/1", subject="da_verificare", **base),
                        {"provincia": "MILANO"})
    s.upsert_interpello(Interpello(detail_url="https://scuola.it/avviso1", subject="sostegno", **base),
                        {"provincia": "MILANO", "fonte": "SCUOLA"})
    assert len(s.interpelli()) == 2
    merged = s.merge_duplicates()
    assert merged == 1
    rows = s.interpelli()
    assert len(rows) == 1
    assert rows[0]["subject"] == "sostegno"              # soggetto promosso
    assert rows[0]["scuola_url"] == "https://scuola.it/avviso1"


def test_set_candidato():
    from ingest.store import Store
    from ingest.mim import Interpello
    d = tempfile.mkdtemp()
    s = Store(os.path.join(d, "t.db"))
    s.upsert_interpello(Interpello(detail_url="https://mim/1", date=None,
                                   school="X - MILANO", date_str="1 giugno 2026",
                                   subject="sostegno"))
    s.set_candidato("https://mim/1", True)
    assert s.interpelli()[0]["candidato"] == "1"
    s.set_candidato("https://mim/1", False)
    assert s.interpelli()[0]["candidato"] == "0"


def test_health():
    from ingest.store import Store
    d = tempfile.mkdtemp()
    s = Store(os.path.join(d, "t.db"))
    st = s.health()
    assert st["ok"] is False and st["last_ingest"] == ""    # mai girato
    s.mark_ingest_ok()
    assert s.health()["ok"] is True
    s.mark_ingest_fail(); s.mark_ingest_fail(); s.mark_ingest_fail()
    assert s.health()["ok"] is False                        # troppi fallimenti


def test_draft_bozza():
    from ingest.store import Store
    from ingest.mim import Interpello
    from ingest.draft import build_text, build_html
    d = tempfile.mkdtemp()
    s = Store(os.path.join(d, "t.db"))
    s.upsert_interpello(Interpello(detail_url="https://mim/1", date=None,
                                   school="IC Test - MILANO",
                                   date_str="1 giugno 2026", subject="francese",
                                   confidence=1.0, grade=""),
                        {"classi": ["AA24"], "ore": "18", "scadenza": "2026-08-20"})
    s.set_profile({"nome": "Maria Rossi", "titoli": "Laurea in Lingue Straniere"})
    row = s.interpelli()[0]
    txt = build_text(row, s.get_profile())
    assert "Maria Rossi" in txt and "AA24" in txt and "Test" in txt
    html = build_html(row, s.get_profile())
    assert "candidatura" in html.lower() and "Test" in html


def test_ai_enabled_switch():
    from ingest.store import Store
    d = tempfile.mkdtemp()
    s = Store(os.path.join(d, "t.db"))
    s.set_settings({"AI_API_KEY": "sk-x", "AI_ENABLED": "1"})
    assert s.ai_effective()["AI_API_KEY"] == "sk-x"
    s.set_settings({"AI_ENABLED": "0"})
    assert s.ai_effective().get("AI_API_KEY", "") == ""