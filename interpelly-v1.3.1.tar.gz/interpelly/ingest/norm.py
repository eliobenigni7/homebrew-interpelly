"""
norm.py — Normalizzazione dei nomi scuola:
  canonical()  -> nome leggibile e coerente ("MIIC860003 - S.PELLICO-ARLUNO"
                  diventa "S. Pellico-Arluno")
  norm_key()   -> chiave per accorpare varianti dello stesso istituto.
"""

from __future__ import annotations

import re
import unicodedata

_CODICE_RE = re.compile(r"^[A-Z]{2}[A-Z0-9]{6,9}\s*[-–]\s*", re.I)
_QUOTES = re.compile(r'["“”«»]+')
_TITLE_STOP = {"di", "del", "della", "dei", "delle", "dal", "da", "d", "e", "l",
               "la", "le", "in", "su", "al", "all", "sull", "degli"}
_ABBR_PREFIX = re.compile(r"^(Ic|Is|Iis|It|Cpia2?|Ipsia|Ipseoa|Cts)\b")


def canonical(name: str) -> str:
    """Nome scuola normalizzato per la visualizzazione (senza codice, pulito)."""
    s = re.sub(_CODICE_RE, "", name or "").strip()
    s = _QUOTES.sub("", s)
    words = s.split()
    if not words:
        return s.strip()

    def cap(w: str) -> str:
        if w.lower() in _TITLE_STOP:
            return w.lower()
        # capitalizza i segmenti uniti da trattino e da punto
        def seg(s: str) -> str:
            if "." in s:
                return ".".join(p.capitalize() for p in s.split("."))
            return s.capitalize()
        if "-" in w:
            return "-".join(seg(s) for s in w.split("-"))
        return seg(w)

    return _ABBR_PREFIX.sub(lambda m: m.group(1).upper(),
                            " ".join(cap(w) for w in words).strip())


def norm_key(name: str) -> str:
    """Chiave invariante per il confronto (minuscolo, senza punteggiatura)."""
    n = unicodedata.normalize("NFKD", canonical(name or ""))
    n = "".join(c for c in n if not unicodedata.combining(c)).lower()
    return re.sub(r"[^a-z0-9]+", " ", n).strip()