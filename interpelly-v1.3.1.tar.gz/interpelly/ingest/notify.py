"""
notify.py — Notifiche: Telegram (HTML + pulsanti) ed email digest (SMTP opzionale).
"""

from __future__ import annotations

import os
import smtplib
from email.message import EmailMessage
from datetime import datetime, date

import requests

TG_TOKEN = os.environ.get("TG_TOKEN", "")
TG_CHAT = os.environ.get("TG_CHAT", "")


def _esc(s: str) -> str:
    return (s or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def telegram_send(text: str, buttons: list[tuple[str, str]] | None = None) -> int:
    if not (TG_TOKEN and TG_CHAT):
        return 0
    payload: dict = {"chat_id": TG_CHAT, "text": text, "parse_mode": "HTML",
                     "disable_web_page_preview": True}
    if buttons:
        payload["reply_markup"] = {
            "inline_keyboard": [[{"text": t, "url": u}] for t, u in buttons]}
    r = requests.post(f"https://api.telegram.org/bot{TG_TOKEN}/sendMessage",
                      json=payload, timeout=30)
    return r.status_code


def fmt_interpello(it: dict, watch: bool = False) -> str:
    d = (it.get("date_iso") or it.get("date_str") or "")[:10]
    star = "⭐ " if watch else ""
    head = f"{star}<b>{_esc(it.get('school', '—'))}</b>"
    bits = [head, f"· {_esc(it.get('subject'))} · {d}"]
    match = it.get("match") or {}
    if match.get("label") and match.get("score") is not None:
        bits.insert(0, f"🎯 {_esc(str(match['label']).upper())} · {match['score']}%")
    if it.get("classi_concorso"):
        bits.append(f"· classi: {', '.join(_esc(x) for x in it['classi_concorso'])}")
    if it.get("ore"):
        bits.append(f"· ore: {_esc(it['ore'])}")
    if it.get("scadenza_iso"):
        bits.append(f"· scade: {_esc(it['scadenza_iso'])}")
    if it.get("comune"):
        bits.append(f"· {_esc(it['comune'])}")
    return "\n".join(bits)


def notify_interpelli(items: list[dict]) -> int:
    """Invia un messaggio per i nuovi interpelli target, con pulsanti."""
    n = 0
    for it in items[:12]:
        is_watch = it.get("_watch", False)
        text = fmt_interpello(it, is_watch)
        buttons = []
        if it.get("link_candidatura"):
            buttons.append(("✍ Candidatura", it["link_candidatura"]))
        if it.get("detail_url"):
            buttons.append(("Albo UST", it["detail_url"]))
        if it.get("axios_url"):
            buttons.append(("Avviso", it["axios_url"]))
        code = telegram_send(text, buttons or None)
        if code == 200:
            n += 1
    return n


def email_digest(body: str, subject: str = "Interpelli — riepilogo") -> bool:
    host = os.environ.get("SMTP_HOST", "")
    if not host:
        return False
    user = os.environ.get("SMTP_USER", "")
    pwd = os.environ.get("SMTP_PASS", "")
    to = os.environ.get("SMTP_TO", user)
    port = int(os.environ.get("SMTP_PORT", "587"))
    msg = EmailMessage()
    msg["Subject"] = subject
    msg["From"] = user
    msg["To"] = to
    msg.set_content(body)
    try:
        with smtplib.SMTP(host, port, timeout=30) as s:
            s.starttls()
            if user:
                s.login(user, pwd)
            s.send_message(msg)
        return True
    except Exception:
        return False


def daily_digest(items: list[dict], expiring: list[dict]) -> str:
    today = date.today().isoformat()
    lines = [f"RIEPILOGO INTERPELLI — {today}", ""]
    lines.append(f"NOVITÀ ({len(items)}):")
    for it in items[:25]:
        lines.append(f"  - {it.get('subject')}: {it.get('school')} "
                     f"({it.get('comune') or '-'}) {it.get('date_iso', '')[:10]}")
    lines.append("")
    lines.append(f"IN SCADENZA (≤48h, {len(expiring)}):")
    for it in expiring[:20]:
        lines.append(f"  - {it.get('scadenza_iso')} | {it.get('school')}")
    return "\n".join(lines)


def notify_deadline_reminder(store, hours: int = 24) -> int:
    """Un promemoria Telegram al giorno con gli interpelli target in scadenza
    entro `hours` ore (dedup via meta.last_deadline_reminder)."""
    from datetime import datetime, timezone
    today = datetime.now(timezone.utc).date().isoformat()
    if store.get_meta("last_deadline_reminder") == today:
        return 0
    rows = store.interpelli(
        urgent_days=1 if hours <= 26 else 2, limit=200)  # ~24h/48h
    targets = [r for r in rows if r.get("subject") in ("francese", "sostegno")]
    if not targets:
        store.set_meta("last_deadline_reminder", today)
        return 0
    lines = ["⏳ *SCADENZE IN ARRIVO*", ""]
    for r in targets[:15]:
        lines.append(f"· {r.get('scadenza_iso')} · {r.get('subject')} · "
                     f"{r.get('school', '')[:45]}\n  {r.get('detail_url', '')}")
    text = "\n".join(lines)[:4000]
    code = telegram_send(text, None)
    store.set_meta("last_deadline_reminder", today)
    return code
