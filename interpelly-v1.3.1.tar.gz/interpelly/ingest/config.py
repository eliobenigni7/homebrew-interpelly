"""
config.py — Configurazione centrale del monitoraggio interpelli.

Modalità:
  * HOME (default su PC personale / IP residenziale): Axios è raggiungibile
    e fornisce il soggetto strutturato (classi di concorso, ore, scadenza,
    link candidatura) — la parte migliore.
  * VPS (datacenter): Axios dà 403 (Cloudflare). Resta l'indice MIM completo
    + albo online delle scuole + "da verificare" con link a 1 tocco.

Variabili d'ambiente (tutte opzionali):
  TG_TOKEN, TG_CHAT            -> notifiche Telegram
  SMTP_*                       -> digest email opzionale
  INTERPELLI_HOME=1            -> forza modalità home (Axios attivo)
  INTERPELLI_PROVINCES         -> "MILANO,BERGAMO" (default: solo MILANO)
  DASHBOARD_USER/PASS          -> basic auth opzionale per l'accesso remoto
"""

from __future__ import annotations

import os

# --- Province: UST -> URL lista interpelli (stessa struttura MIM) -----------
UST_LIST = {
    "MILANO": "https://www.mim.gov.it/web/milano/interpelli-ricerca-supplenti",
    "BERGAMO": "https://www.mim.gov.it/web/bergamo/interpelli-ricerca-supplenti",
    "BRESCIA": "https://www.mim.gov.it/web/brescia/interpelli-ricerca-supplenti",
    "COMO": "https://www.mim.gov.it/web/como/interpelli-ricerca-supplenti",
    "CREMONA": "https://www.mim.gov.it/web/cremona/interpelli-ricerca-supplenti",
    "LECCO": "https://www.mim.gov.it/web/lecco/interpelli-ricerca-supplenti",
    "LODI": "https://www.mim.gov.it/web/lodi/interpelli-ricerca-supplenti",
    "MANTOVA": "https://www.mim.gov.it/web/mantova/interpelli-ricerca-supplenti",
    "MONZA-BRIANZA": "https://www.mim.gov.it/web/monza-brianza/interpelli-ricerca-supplenti",
    "PAVIA": "https://www.mim.gov.it/web/pavia/interpelli-ricerca-supplenti",
    "SONDRIO": "https://www.mim.gov.it/web/sondrio/interpelli-ricerca-supplenti",
    "VARESE": "https://www.mim.gov.it/web/varese/interpelli-ricerca-supplenti",
}

DEFAULT_PROVINCES = ["MILANO"]


def provinces() -> list[str]:
    raw = os.environ.get("INTERPELLI_PROVINCES", "").strip()
    if raw:
        return [p.strip().upper() for p in raw.split(",") if p.strip()]
    return DEFAULT_PROVINCES


def home_mode() -> bool:
    """True se giriamo su IP residenziale (Axios raggiungibile)."""
    return os.environ.get("INTERPELLI_HOME", "1") == "1" or "INTERPELLI_HOME" not in os.environ


# --- Target di classificazione ----------------------------------------------
TARGETS = {"francese", "sostegno"}

# Classe di concorso -> soggetto (per l'etichetta esatta mostrata in UI)
CLASSE_MAP = {
    # francese
    "A24": "francese", "A25": "francese", "AA24": "francese", "AB24": "francese",
    "BD02": "francese", "BA02": "francese", "A024": "francese",
    # inglese (non target ma utile)
    "AB25": "inglese", "A25": "inglese",
    # sostegno
    "ADMM": "sostegno", "ADEE": "sostegno", "AD00": "sostegno", "ADSS": "sostegno",
    "AAAA": "sostegno", "EEEE": "sostegno",
    # altro
    "A22": "altro", "A26": "altro", "A27": "altro", "A28": "altro", "A29": "altro",
    "A30": "altro", "A31": "altro", "A34": "altro", "A36": "altro", "A41": "altro",
    "A42": "altro", "A46": "altro", "A47": "altro", "A48": "altro", "A50": "altro",
    "A54": "altro", "A61": "altro", "A65": "altro", "A66": "altro", "A67": "altro",
    "AB56": "altro", "AC24": "altro", "AC25": "altro", "AJ56": "altro",
    "AM48": "altro", "AB50": "altro",
}

TIPO_NORM = {
    "infanzia": "infanzia", "materna": "infanzia",
    "primaria": "primaria", "elementare": "primaria",
    "secondaria i": "secondaria_i", "i grado": "secondaria_i",
    "secondaria ii": "secondaria_ii", "ii grado": "secondaria_ii",
    "secondaria": "secondaria_ii",
}

# --- Watchlist (scuole da seguire con priorità) ------------------------------
WATCHLIST_FILE = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                              "data", "watchlist.txt")


def watchlist() -> set[str]:
    try:
        with open(WATCHLIST_FILE, encoding="utf-8") as f:
            return {l.strip().lower() for l in f if l.strip() and not l.startswith("#")}
    except OSError:
        return set()