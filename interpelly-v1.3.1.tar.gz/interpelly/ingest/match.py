"""Matching deterministico degli interpelli al profilo candidata."""

from __future__ import annotations

import json
import re
import unicodedata
from datetime import date


def normalize_comune(value: str) -> str:
    value = unicodedata.normalize("NFKD", str(value or ""))
    value = "".join(c for c in value if not unicodedata.combining(c))
    return re.sub(r"\s+", " ", value).strip().lower()


def _values(value) -> list[str]:
    if isinstance(value, str):
        value = value.strip()
        if value.startswith("["):
            try:
                value = json.loads(value)
            except json.JSONDecodeError:
                pass
        else:
            value = re.split(r"[,;]", value)
    if not isinstance(value, (list, tuple, set)):
        return [] if value in (None, "") else [str(value).strip()]
    return [str(v).strip() for v in value if str(v).strip()]


def _classi(row: dict) -> list[str]:
    return [c.upper() for c in _values(row.get("classi_concorso") or row.get("classi"))]


def _days_to(date_value: str) -> int | None:
    try:
        return (date.fromisoformat(str(date_value)[:10]) - date.today()).days
    except (TypeError, ValueError):
        return None


def match_score(row: dict, profile: dict) -> dict:
    profile = profile or {}
    subjects = {s.lower() for s in _values(profile.get("soggetti"))}
    wanted_classes = {c.upper() for c in _values(profile.get("classi"))}
    wanted_cities = [normalize_comune(c) for c in _values(profile.get("comuni"))]
    grado = str(profile.get("grado") or "").strip().lower()
    if not (subjects or wanted_classes or wanted_cities or grado):
        return {"score": 0, "label": "—", "reasons": []}
    row_subject = str(row.get("subject") or "").strip().lower()
    classes = _classi(row)
    score = 0
    reasons: list[str] = []

    if row_subject in subjects:
        score += 50
        reasons.append(f"Sei in cerca di {row_subject}")

    matching_class = next((c for c in classes if c in wanted_classes), "")
    if row_subject == "da_verificare":
        if matching_class:
            score += 25
            reasons.append(f"Classe {matching_class} richiesta nel tuo profilo")
        elif classes:
            score += 10
            reasons.append("Classe di concorso presente, soggetto da verificare")

    if matching_class and row_subject != "da_verificare":
        score += 20
        reasons.append(f"Classe {matching_class} richiesta nel tuo profilo")
        if row_subject in subjects:
            score += 10
            reasons.append("Soggetto e classe coincidono con il tuo profilo")

    row_city = normalize_comune(row.get("comune"))
    school = normalize_comune(row.get("school"))
    matching_city = ""
    for c in wanted_cities:
        if not c:
            continue
        if c == row_city:
            matching_city = c
            break
        # token delimitato nel nome scuola: "san donato" in "ic margherita hack san donato milanese"
        pattern = re.compile(rf"(?<![a-z0-9]){re.escape(c)}(?![a-z0-9])")
        if pattern.search(school):
            matching_city = c
            break
    if matching_city:
        score += 15
        reasons.append(f"Scuola a {matching_city.title()}")

    if grado and str(row.get("tipo_scuola") or "").strip().lower() == grado:
        score += 5
        reasons.append(f"Grado {grado} nel tuo profilo")

    days = _days_to(row.get("scadenza_iso") or row.get("scadenza"))
    if days is not None and 0 <= days <= 7:
        score += 5
        if days == 0:
            reasons.append("Scade oggi")
        elif days == 1:
            reasons.append("Scade domani")
        else:
            reasons.append(f"Scade tra {days} giorni")

    score = min(100, score)
    label = ("match perfetto" if score >= 80 else
             "probabile" if score >= 50 else
             "possibile" if score >= 25 else "—")
    return {"score": score, "label": label, "reasons": reasons}


def top_matches(rows: list[dict], profile: dict, limit: int = 8) -> list[dict]:
    today = date.today().isoformat()
    matched = []
    for row in rows:
        scad = str(row.get("scadenza_iso") or row.get("scadenza") or "")[:10]
        if scad and scad < today:
            continue  # avviso scaduto: fuori dal "Per te"
        match = match_score(row, profile)
        if match["score"] > 0:
            enriched = dict(row)
            enriched["match"] = match
            matched.append(enriched)
    matched.sort(key=lambda row: (
        row["match"]["score"], str(row.get("date_iso") or row.get("date") or "")
    ), reverse=True)
    return matched[:max(0, limit)]
