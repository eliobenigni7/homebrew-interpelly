"""
ai.py — Estrazione intelligente degli avvisi (opzionale).

Usa un'API compatibile OpenAI (OpenRouter, Gemini, Ollama locale…) per
estrarre da un testo di avviso: subject (francese/sostegno/altro), classi di
concorso, ore, periodo, scadenza (ISO), comune e tipo scuola.

Le impostazioni possono arrivare da più fonti, in questo ordine di priorità:
  settings dict passato dall'app (pagina Impostazioni della dashboard) >
  variabili d'ambiente (AI_API_KEY, AI_BASE_URL, AI_MODEL).

Se manca la chiave, tutto degrada silenziosamente a {}.

Env:
  AI_API_KEY        chiave API (es. OpenRouter)
  AI_BASE_URL       default https://openrouter.ai/api/v1
  AI_MODEL          default openrouter/auto (o gemini-2.0-flash, llama3.1…)
  TESSERACT_CMD     percorso di tesseract (per OCR scansioni) — opzionale
  PDFTOTPM_CMD      percorso di pdftoppm (poppler) — opzionale, serve all'OCR
"""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import tempfile
from pathlib import Path

import requests

PROMPT = """Sei un parser di avvisi di interpello scolastico italiani.
Dal testo sotto estrai e rispondi SOLO con JSON valido con queste chiavi:
- "subject": "francese" | "sostegno" | "altro" | null   (materia/ruolo cercato)
- "classi": [stringhe, es. "AA24, ADEE"]
- "ore": stringa ore settimanali o null
- "periodo": stringa periodo contratto o null
- "scadenza": data in formato ISO (YYYY-MM-DD) o null
- "comune": comune della scuola se indicato, altrimenti null
- "tipo_scuola": "infanzia" | "primaria" | "secondaria_i" | "secondaria_ii" | null
Non inventare campi che non ci sono: null se assenti.

TESTO AVVISO:
----
{text}
----"""


def _cfg(settings: dict | None) -> tuple[str, str, str]:
    s = settings or {}
    api_key = s.get("AI_API_KEY") or os.environ.get("AI_API_KEY", "")
    base_url = s.get("AI_BASE_URL") or os.environ.get("AI_BASE_URL", "") \
        or "https://openrouter.ai/api/v1"
    model = s.get("AI_MODEL") or os.environ.get("AI_MODEL", "") or "openrouter/auto"
    return api_key, base_url.rstrip("/"), model


def _configured(settings: dict | None = None) -> bool:
    api_key, base_url, _ = _cfg(settings)
    if api_key:
        return True
    # server locale (Ollama ecc.) senza chiave ma con base esplicita
    return bool(base_url and os.environ.get("AI_BASE_URL"))


def _call(text: str, settings: dict | None = None) -> dict:
    api_key, base_url, model = _cfg(settings)
    url = f"{base_url}/chat/completions"
    headers = {"Content-Type": "application/json"}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": "Sei un estrattore di dati. Rispondi solo JSON."},
            {"role": "user", "content": PROMPT.format(text=text[:8000])},
        ],
        "temperature": 0,
    }
    r = requests.post(url, json=payload, headers=headers, timeout=60)
    r.raise_for_status()
    content = r.json()["choices"][0]["message"]["content"]
    content = re.sub(r"^```(?:json)?|```$", "", content.strip(), flags=re.M)
    data = json.loads(content)
    return data if isinstance(data, dict) else {}


def ocr_pdf(pdf_bytes: bytes) -> str:
    """OCR di un PDF scansione via pdftoppm + tesseract (entrambi opzionali)."""
    tesseract = os.environ.get("TESSERACT_CMD") or shutil.which("tesseract")
    pdftoppm = os.environ.get("PDFTOTPM_CMD") or shutil.which("pdftoppm")
    if not (tesseract and pdftoppm):
        return ""
    with tempfile.TemporaryDirectory() as td:
        pdf = Path(td) / "avviso.pdf"
        pdf.write_bytes(pdf_bytes)
        try:
            subprocess.run([pdftoppm, "-png", "-r", "200", str(pdf), str(Path(td) / "pg")],
                           check=True, capture_output=True, timeout=90)
        except (subprocess.CalledProcessError, FileNotFoundError, subprocess.TimeoutExpired):
            return ""
        pages = sorted(Path(td).glob("pg-*.png"))[:10]
        out = []
        for p in pages:
            try:
                r = subprocess.run([tesseract, str(p), "-", "-l", "ita", "--psm", "6"],
                                   check=True, capture_output=True, timeout=60)
                out.append(r.stdout.decode("utf-8", "ignore"))
            except (subprocess.CalledProcessError, FileNotFoundError, subprocess.TimeoutExpired):
                continue
        return "\n".join(out)


def extract(text: str, pdf_bytes: bytes | None = None, settings: dict | None = None) -> dict:
    """Estrae i campi da testo (e PDF, con OCR se serve). {} se non configurato."""
    if not _configured(settings):
        return {}
    if pdf_bytes:
        plain = ""
        try:
            from pypdf import PdfReader
            import io as _io
            plain = "\n".join((p.extract_text() or "") for p in
                              PdfReader(_io.BytesIO(pdf_bytes)).pages[:10])
        except Exception:
            plain = ""
        if not plain.strip():
            plain = ocr_pdf(pdf_bytes)
        text = f"{text}\n---PDF---\n{plain[:6000]}"
    try:
        return _call(text, settings)
    except Exception:
        return {}