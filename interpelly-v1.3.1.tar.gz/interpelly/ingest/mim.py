"""
mim.py — Indice autoritativo degli interpelli pubblicati dall'UST Milano
(portale MIM). Server-rendered e raggiungibile da qualsiasi host (VPS incluso).

La lista: https://www.mim.gov.it/web/milano/interpelli-ricerca-supplenti
Dettaglio: https://www.mim.gov.it/web/milano/-/<slug>
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field, asdict
from datetime import datetime
from typing import Optional

import requests
from bs4 import BeautifulSoup

LIST_URL = "https://www.mim.gov.it/web/milano/interpelli-ricerca-supplenti"
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/124 Safari/537.36")

MONTHS_IT = {m: i + 1 for i, m in enumerate(
    ["gennaio", "febbraio", "marzo", "aprile", "maggio", "giugno", "luglio",
     "agosto", "settembre", "ottobre", "novembre", "dicembre"])}


@dataclass
class Interpello:
    date: Optional[datetime]
    date_str: str
    school: str
    grade: str = ""          # campo libero del dettaglio (tipo/grado/scadenza)
    detail_url: str = ""
    axios_url: str = ""
    raw_text: str = ""
    subject: str = "da_verificare"
    confidence: float = 0.0

    def key(self) -> str:
        return self.detail_url

    def to_dict(self) -> dict:
        d = asdict(self)
        d["date"] = d["date"].isoformat() if d["date"] else None
        return d


def _parse_date(s: str) -> Optional[datetime]:
    m = re.match(r"(\d{1,2})\s+([a-zàèìòù]+)\s+(\d{4})", (s or "").strip().lower())
    if not m:
        return None
    month = MONTHS_IT.get(m.group(2))
    if not month:
        return None
    try:
        return datetime(int(m.group(3)), month, int(m.group(1)))
    except ValueError:
        return None


class MIMSession:
    def __init__(self, timeout: int = 25, retries: int = 3):
        self.timeout, self.retries = timeout, retries
        self.s = requests.Session()
        self.s.headers.update({"User-Agent": UA, "Accept-Language": "it-IT,it;q=0.9"})

    def get(self, url: str) -> Optional[str]:
        last = None
        for _ in range(self.retries):
            try:
                r = self.s.get(url, timeout=self.timeout)
                if r.status_code == 200:
                    return r.text
                last = f"HTTP {r.status_code}"
            except requests.RequestException as e:
                last = str(e)
        raise RuntimeError(f"GET {url} fallita — {last}")

    def get_bytes(self, url: str) -> Optional[bytes]:
        for _ in range(self.retries):
            try:
                r = self.s.get(url, timeout=40)
                if r.status_code == 200:
                    return r.content
                last = f"HTTP {r.status_code}"
            except requests.RequestException as e:
                last = str(e)
        raise RuntimeError(f"GET {url} fallita — {last}")


def fetch_list(sess: MIMSession, url: str = LIST_URL) -> list[Interpello]:
    soup = BeautifulSoup(sess.get(url), "html.parser")
    out = []
    for art in soup.select("article.article"):
        h3 = art.select_one("h3 a")
        if h3 is None or not h3.get("href"):
            continue
        date_str = (art.select_one("span.article_data") or "")
        date_str = date_str.get_text(strip=True) if date_str else ""
        grade = ""
        p = h3.find_next("p")
        if p and p.get("class") is None:
            grade = p.get_text(strip=True)
        out.append(Interpello(
            date=_parse_date(date_str), date_str=date_str,
            school=h3.get_text(strip=True), grade=grade,
            detail_url=h3["href"].strip(),
        ))
    return out


def fetch_detail(sess: MIMSession, i: Interpello) -> None:
    try:
        html = sess.get(i.detail_url)
    except RuntimeError:
        return
    soup = BeautifulSoup(html, "html.parser")
    a = soup.select_one('div.journal-content-article a[href*="axios"]')
    a = a or soup.find("a", href=re.compile(r"axios", re.I))
    if a and a.get("href"):
        i.axios_url = a["href"].strip()
    art = soup.select_one("div.journal-content-article")
    body = art or soup.find("main")
    if body:
        # Niente troncamento qui: store.upsert_interpello tronca a 4000 a valle.
        # Il testo integrale serve a extract_fields() e all'estrattore AI.
        i.raw_text = re.sub(r"\s+", " ", body.get_text(" ", strip=True))

    post = soup.select_one(".post-content")
    if not i.grade and post:
        for title in post.select("p, h2, h3"):
            text = title.get_text(" ", strip=True)
            if text and re.search(r"interpello|supplenza|posto|avviso", text, re.I):
                i.grade = text
                break
