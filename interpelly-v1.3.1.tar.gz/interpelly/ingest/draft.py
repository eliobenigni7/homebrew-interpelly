"""
draft.py — Bozza di domanda di candidatura per un interpello.

Genera il testo della domanda (e una vista HTML stampabile → "Salva come PDF")
a partire dal profilo candidata salvato e dai dati dell'avviso.
"""

from __future__ import annotations

import html as _html
from datetime import date, datetime


def build_text(row: dict, profile: dict) -> str:
    nome = (profile.get("nome") or "").strip() or "NOME COGNOME"
    titoli = (profile.get("titoli") or "").strip()
    note = (profile.get("note") or "").strip()
    school = row.get("school_canonic") or row.get("school") or ""
    soggetto = row.get("subject") or ""
    classi = ", ".join(row.get("classi_concorso") or []) or "—"
    ore = row.get("ore") or "—"
    scad = row.get("scadenza_iso") or "—"
    pub = (row.get("date_iso") or "")[:10]
    cand_url = row.get("link_candidatura") or row.get("detail_url") or ""

    body = [
        "OGGETTO: Domanda di candidatura — interpello per supplenza "
        f"({soggetto}) pubblicato in data {pub}.",
        "",
        "Egregio Dirigente Scolastico,",
        "",
        f"con riferimento all'interpello pubblicato da {school} in data {pub} "
        f"per classi di concorso {classi} ({ore} ore, scadenza {scad}),",
        "",
        f"il/la sottoscritto/a {nome} dichiara la propria disponibilità a "
        "ricoprire l'incarico di supplenza e il possesso dei requisiti richiesti.",
    ]
    if titoli:
        body += ["", f"Titoli e requisiti: {titoli}."]
    if note:
        body += ["", f"Note: {note}."]
    body += [
        "",
        "Contestualmente alla presente si allegano: curriculum vitae, documento "
        "di identità in corso di validità e dichiarazione sostitutiva ai sensi "
        "del D.P.R. 445/2000.",
        "",
        "Disponibile a un eventuale colloquio di chiarimento, si porgono "
        "distinti saluti.",
        "",
        f"{nome} — {date.today().isoformat()}",
        "",
        f"Fonte avviso: {cand_url}",
    ]
    return "\n".join(body)


def build_html(row: dict, profile: dict) -> str:
    text = build_text(row, profile)
    school = _html.escape(row.get("school_canonic") or row.get("school") or "")
    lines = "".join(f"<p>{_html.escape(line) or '&nbsp;'}</p>"
                    for line in text.splitlines())
    return f"""<!DOCTYPE html>
<html lang="it"><head><meta charset="utf-8">
<title>Bozza domanda — {_html.escape(school[:40])}</title>
<style>
  body {{ font-family: Georgia, 'Times New Roman', serif; color: #241c12;
         margin: 0; padding: 48px 64px; background: #fbf6ea; }}
  .head {{ border-bottom: 2px solid #241c12; padding-bottom: 14px; margin-bottom: 26px; }}
  .head small {{ display: block; letter-spacing: .18em; text-transform: uppercase;
                 color: #8a8168; font-size: 11px; margin-bottom: 6px; }}
  .head h1 {{ font-size: 21px; margin: 0; font-weight: normal; }}
  p {{ font-size: 13.5px; line-height: 1.65; margin: 0 0 12px; }}
  .meta {{ color: #6b6350; font-size: 12px; }}
  @media print {{ body {{ background: #fff; }} }}
</style></head><body>
<div class="head"><small>Interpelly ✻ — bozza di domanda</small>
<h1>{_html.escape(school)}</h1></div>
{lines}
<p class="meta">Generata da Interpelly il {datetime.now():%d/%m/%Y %H:%M} —
usa Stampa → Salva come PDF per il file.</p>
</body></html>"""


def build_subject(row: dict) -> str:
    school = row.get("school") or ""
    return f"Candidatura interpello {row.get('subject') or ''} — {school[:60]}"