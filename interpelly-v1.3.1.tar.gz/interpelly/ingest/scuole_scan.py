"""
scuole_scan.py — Scan delle scuole secondarie di II grado di Milano:
crawl dei loro siti istituzionali alla ricerca di interpelli/supplenze.

Per ogni sito:
  1. probe delle sezioni canoniche (albo online, argomento/interpello, novità…)
  2. estrazione delle voci recenti (titolo, link, data)
  3. per le voci interpello/supplenza: classificazione soggetto dal titolo e
     dal testo del PDF allegato (francese/sostegno)
  4. salvataggio in SQLite con fonte='SCUOLA' (distingue dagli avvisi UST)

Il risultato è incrementale: i siti già scansionati vengono saltati
(--rescan per rifare), e ogni sito è registrato nella tabella scans.
"""

from __future__ import annotations

import json
import re
import unicodedata
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from urllib.parse import urljoin

import requests
from bs4 import BeautifulSoup

from .config import TARGETS
from .subjects import classify, fetch_pdf_text
from .axios import CLASSE_RE

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124 Safari/537.36"

# Sezioni canoniche dei siti scuola (tema WordPress PuntoScuola/Madisoft e simili)
SECTION_PATHS = [
    "albo-online/",
    "tipologia-documento/albo-online/",
    "argomento/interpello/",
    "interpelli/",
    "pubblicita-legale/",
    "novita/",
    "amministrazione-trasparente/",
]

INTERPELLO_RE = re.compile(r"interpell|supplenz|reclutament|selezion|incarich|docente", re.I)


@dataclass
class Entry:
    title: str
    url: str
    date: str = ""


@dataclass
class Found:
    """Interpello trovato sul sito di una scuola."""
    entry: Entry
    subject: str
    source: str          # 'titolo' | 'pdf' | 'pagina'
    classi: list[str] = field(default_factory=list)
    pdf_url: str = ""


@dataclass
class SchoolScan:
    site: str
    names: list[str] = field(default_factory=list)
    ok: bool = False
    status: str = "pending"          # pending|ok|unreachable|error
    sections: list[str] = field(default_factory=list)
    entries: int = 0
    pdfs_checked: int = 0
    found: list[Found] = field(default_factory=list)


def _date_from_html(soup: BeautifulSoup) -> str:
    t = soup.find("time")
    if t and t.get("datetime"):
        return t["datetime"][:10]
    if t and t.get_text(strip=True):
        m = re.search(r"(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{2,4})", t.get_text())
        if m:
            d, mo, y = m.group(1), m.group(2), m.group(3)
            if len(y) == 2:
                y = "20" + y
            return f"{y}-{int(mo):02d}-{int(d):02d}"
    return ""


NAV_STOP = {
    "vai ai contenuti", "vai al menu di navigazione", "vai al footer", "salta al contenuto",
    "presentazione", "i numeri della scuola", "le carte della scuola", "organizzazione",
    "progetti finanziati", "personale scolastico", "strumenti", "contatti", "chi siamo",
    "home", "privacy", "note legali", "mappa del sito", "accesso", "urp", "cerca",
    "amministrazione trasparente", "albo online", "novità", "area riservata", "login",
    "ministero dell'istruzione e del merito", "dirigente scolastico", "segretaria",
    "documentazione", "modulistica", "pof", "piano triennale", "riferimenti",
}
NAV_HREF_RE = re.compile(
    r"/(presentazione|organizzazione|contatti|chi-siamo|i-numeri-della-scuola|"
    r"le-carte-della-scuola|personale-scolastico|progetti|amministrazione-|"
    r"area-riservata|accesso|urp|home|mappa|privacy|note-legali|ricerca|modulistica|"
    r"pof|documenti|strumenti)(/|$|\?)", re.I)


def _page_entries(soup: BeautifulSoup, base: str) -> list[Entry]:
    """Titoli + link + date dalle card/articoli della pagina (nav esclusa)."""
    out: list[Entry] = []
    seen = set()

    # se esistono <article>/<li> con link, estrai da quelli (contenuti veri)
    containers = soup.find_all(["article", "li"])
    link_srcs = []
    for c in containers:
        a = c.find("a", href=True)
        if a:
            link_srcs.append((a, c))
    if not link_srcs:
        link_srcs = [(a, a) for a in soup.find_all("a", href=True)]

    for a, c in link_srcs:
        title = re.sub(r"\s+", " ", a.get_text(" ", strip=True)).strip()
        href = a["href"]
        low_href = href.lower()
        if not title or len(title) < 12:
            continue
        low_title = title.lower()
        if low_title in NAV_STOP or any(s in low_title for s in NAV_STOP if len(s) > 18):
            continue
        if NAV_HREF_RE.search(low_href) or re.search(r"\.(css|js|png|jpg|ico|svg)(\?|$)", low_href):
            continue
        if href.startswith(("#", "javascript:", "mailto:")):
            continue
        if low_href == base.rstrip("/").lower() or low_href.endswith("/"):
            continue
        u = urljoin(base, href)
        if u in seen:
            continue
        seen.add(u)
        date = _date_from_html(c)
        out.append(Entry(title=title, url=u, date=date))

    # ordina: chi ha data recente prima
    out.sort(key=lambda e: (e.date == "", e.date), reverse=True)
    return out[:80]


def _pdf_links(soup: BeautifulSoup, base: str) -> list[str]:
    out = []
    for a in soup.find_all("a", href=True):
        if re.search(r"\.pdf(?:$|\?)", a["href"], re.I):
            u = urljoin(base, a["href"])
            if u not in out:
                out.append(u)
    return out[:10]


def scan_site(sess: requests.Session, site: str, names: list[str],
              max_sections: int = 6, max_pdfs: int = 5,
              recent_days: int = 45) -> SchoolScan:
    """Scansiona un sito. Ritorna SchoolScan con gli interpelli trovati."""
    sc = SchoolScan(site=site, names=names)
    base = site if site.endswith("/") else site + "/"
    try:
        r = sess.get(base, timeout=12, headers={"User-Agent": UA})
    except requests.RequestException:
        sc.status = "unreachable"
        return sc
    if r.status_code != 200:
        sc.status = "unreachable"
        return sc
    # sezioni canoniche (alcune potrebbero non esistere -> 404, ok)
    urls: list[str] = []
    for p in SECTION_PATHS[:max_sections]:
        u = urljoin(base, p)
        if u not in urls:
            urls.append(u)
    # + sezioni esplicite linkate dal menu
    soup0 = BeautifulSoup(r.text, "html.parser")
    seen_sections = set()
    for a in soup0.find_all("a", href=True):
        lab = (a.get_text(" ", strip=True) or "").lower()
        if re.search(r"(albo|interpell|pubblicit|supplenz)", a["href"] + " " + lab, re.I):
            u = urljoin(base, a["href"])
            if u not in urls and u not in seen_sections:
                seen_sections.add(u)
                urls.append(u)

    cutoff = datetime.now() - timedelta(days=recent_days)
    entries: list[Entry] = []
    for u in urls[:max_sections + 4]:
        try:
            rr = sess.get(u, timeout=10, headers={"User-Agent": UA})
        except requests.RequestException:
            continue
        if rr.status_code != 200:
            continue
        sc.sections.append(u)
        soup = BeautifulSoup(rr.text, "html.parser")
        for e in _page_entries(soup, u):
            if e.url == base or e.url == u:
                continue
            # filtro temporale (se la data è leggibile)
            if e.date:
                try:
                    if datetime.fromisoformat(e.date) < cutoff:
                        continue
                except ValueError:
                    pass
            entries.append(e)

    # dedup per URL
    seen_e = set()
    uniq = []
    for e in entries:
        if e.url in seen_e:
            continue
        seen_e.add(e.url)
        uniq.append(e)
    sc.entries = len(uniq)

    # classifica le voci rilevanti (titolo interpello/supplenza o sezione albo)
    interesting = [e for e in uniq if INTERPELLO_RE.search(e.title)]
    if interesting:
        sc.pdfs_checked = 0
        seen_found: set[str] = set()
        for e in interesting[:max_pdfs]:
            subj, conf = classify(e.title)
            source = "titolo"
            classi = [m.group(1).upper() for m in CLASSE_RE.finditer(e.title)]
            pdf_url = ""
            if conf < 1.0:
                # prova il primo PDF della voce (se la voce è una pagina)
                try:
                    rr = sess.get(e.url, timeout=10, headers={"User-Agent": UA})
                except requests.RequestException:
                    continue
                if rr.status_code == 200:
                    soup = BeautifulSoup(rr.text, "html.parser")
                    pdfs = _pdf_links(soup, e.url)
                    if pdfs:
                        pdf_url = pdfs[0]
                        txt = fetch_pdf_text(pdf_url)
                        sc.pdfs_checked += 1
                        if txt:
                            s2, c2 = classify(txt)
                            if c2 >= 1.0:
                                subj, conf, source = s2, c2, "pdf"
                                classi = [m.group(1).upper() for m in CLASSE_RE.finditer(txt)]
            if conf >= 1.0 and subj in TARGETS and e.url not in seen_found:
                seen_found.add(e.url)
                sc.found.append(Found(entry=e, subject=subj, source=source,
                                      classi=classi, pdf_url=pdf_url))
    sc.ok = sc.status == "pending"
    sc.status = "ok" if sc.ok else sc.status
    return sc