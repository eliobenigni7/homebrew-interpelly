"""
subjects.py — Classificazione del soggetto dell'interpello.

Da VPS/datacenter la piattaforma Axios (dove sta il soggetto strutturato) è dietro
Cloudflare; quindi il soggetto è ricostruito con più segnali best-effort:

  - FRANCESE: classe di concorso A24/A25/AA24/AB24/BD02/BA02/AB24, "francese"
  - SOSTEGNO:  ADMM/ADEE/AD00/AEE, "sostegno", "posto di sostegno"
  - ALTRO / DA VERIFICARE: nessun segnale affidabile

Ogni segnale contribuisce a una CONFIDENZA; il soggetto finale è scelto tra
francese/sostegno/altro. Se nessun segnale dà certezza -> "da_verificare"
(mostrato in dashboard con link a 1 tocco).
"""

from __future__ import annotations

import io
import re

import requests
from bs4 import BeautifulSoup

FRANCESE = {
    "francese",
    "lingua francese",
    "a24", "a25", "aa24", "ab24", "a-24", "a-25",
    "bd02", "ba02", "bd 02", "ba 02", "a024",
}
SOSTEGNO = {
    "sostegno", "posto di sostegno",
    "admm", "adee", "ad00", "aee",
    "sostegno infanzia", "sostegno primaria",
}

# Struttura compatta: token -> (soggetto, peso)
_TOKEN_TABLE = []
for _t in FRANCESE:
    _TOKEN_TABLE.append((_t, "francese", 2))
for _t in SOSTEGNO:
    _TOKEN_TABLE.append((_t, "sostegno", 2))


def classify(text: str) -> tuple[str, float]:
    """Ritorna (soggetto, confidence). soggetto in francese/sostegno/altro."""
    t = re.sub(r"[^a-z0-9°éè]", " ", (text or "").lower())
    t = re.sub(r"\s+", " ", t)
    scores = {"francese": 0.0, "sostegno": 0.0}
    for token, subj, w in _TOKEN_TABLE:
        # token di classe concorso: match parola intera su formato 'a24'
        if re.search(rf"(?<![a-z0-9]){re.escape(token)}(?![a-z0-9])", t):
            scores[subj] += w
    best = max(scores, key=scores.get)
    if scores[best] > 0:
        # normalizza confidence: 1/best anche 1 token
        return best, min(1.0, scores[best] / 2.0)
    return "altro", 0.0


def classify_interpello(i) -> str:
    """Classifica un oggetto con campi school/grade/raw_text/axios."""
    blob = f"{i.school} {i.grade} {i.raw_text} {i.axios_url}"
    subj, conf = classify(blob)
    if conf >= 1.0:
        return subj
    return "da_verificare" if subj == "altro" else subj


# --- Estrazione testo da PDF avvisi (fallback per subject su albo scuola) ----
def pdf_text(data: bytes, max_len: int = 20000) -> str:
    """Estrae il testo di un PDF. Richiede pypdf. Graceful su errore."""
    try:
        from pypdf import PdfReader
        r = PdfReader(io.BytesIO(data))
        return "\n".join((p.extract_text() or "") for p in r.pages[:12])[:max_len]
    except Exception:
        return ""


def grep_pdf_for_subject(pdf_bytes: bytes, base_hint: str = "") -> str:
    """Scarica/usa un PDF ed estrae il soggetto. Ritorna 'da_verificare' se ignoto."""
    subj, conf = classify(pdf_text(pdf_bytes))
    if conf >= 1.0:
        return subj
    return "da_verificare"


def fetch_pdf_text(url: str, timeout: int = 30) -> str:
    r = requests.get(url, timeout=timeout,
                     headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/124"})
    if r.status_code != 200:
        return ""
    return pdf_text(r.content)