"""
schools.py — Risoluzione del sito ufficiale della scuola e lettura dell'albo.

La maggior parte dei siti delle scuole italiane usa un tema WordPress standard
(PuntoScuola/Madisoft) con sezioni prevedibili:
  /argomento/interpello/       -> notizie interpello
  /tipologia-documento/albo-online/ -> albo online (allegati PDF)
  /novita/, /albo-online/
Da VPS quest'albo è raggiungibile e contiene l'avviso PDF con la classe di
concorso -> è il segnale principale per il soggetto (francese/sostegno).

Strategia (best-effort, resiliente):
  1. domini candidati da Scuola in Chiaro (unica.istruzione.gov.it) o pattern
     <nome>.edu.it / <nome>.it derivati dal nome della scuola
  2. probe delle sezioni canoniche
  3. download dei PDF recenti delle sezioni interpello/albo -> classify()
  4. cache su SQLite: non si ripete il probe a ogni run
"""

from __future__ import annotations

import json
import re
import unicodedata
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urljoin

import requests
from bs4 import BeautifulSoup

from .subjects import classify, fetch_pdf_text

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/124"

# Directory autoritativa scuola -> sito (da Open Data MIM, provincia Milano).
DIR_FILE = Path(__file__).resolve().parent.parent / "data" / "mi_sites.json"

SECTION_PATHS = [
    "argomento/interpello/",
    "tipologia-documento/albo-online/",
    "pubblicita-legale/",
    "albo-online/",
    "novita/",
    "interpelli/",
]
_CITY_SUFFIX = re.compile(
    r"-(milano|segrate|melzo|settala|cinisello-?balsamo|trezzo-?sull-?adda|trezzano-?sul-?naviglio|"
    r"rho|rozzano|cornaredo|cassano-?d-?adda|paullo|tribiano|cernusco-?sul-?naviglio|novate-?milanese|"
    r"garbagnate-?milanese|abbiategrasso|magenta|corsico|pioltello|san-?donato-?milanese|san-?giuliano-?milanese|"
    r"vignate|noviglio|buccinasco|sesto-?san-?giovanni|bresso|gessate|gorgonzola|pessano-?con-?bornago|"
    r"vanzago|sedriano|villa-?cortese|rescaldina|magnago|lainate|cesano-?boscone|bollate|parabiago|"
    r"premenugo|rodano|masate|basiano|marcallo-?con-?casone|colturano|vermezzo|arzago|settimo-?milanese)\.?$"
)


def slugify(name: str) -> str:
    """'IC Schweitzer - SEGRATE' -> 'ic-schweitzer-segrate' (varianti utili)."""
    n = unicodedata.normalize("NFKD", name)
    n = "".join(c for c in n if not unicodedata.combining(c)).lower()
    n = re.sub(r"[^a-z0-9]+", "-", n).strip("-")
    return n


def norm(name: str) -> str:
    n = unicodedata.normalize("NFKD", str(name))
    n = "".join(c for c in n if not unicodedata.combining(c)).lower()
    return re.sub(r"[^a-z0-9]+", "", n)


_STOPWORDS = {"istituto", "comprensivo", "scuola", "statale", "comune", "via",
              "viale", "di", "d", "e", "l", "la", "le", "dei", "delle", "san",
              "santa", "santo", "don", "posto", "secondaria", "primaria",
              "infanzia", "milano", "istruzione", "superiore"}


def _significant_tokens(name: str) -> list[str]:
    """Token rilevanti del nome scuola (≥5 char, esclusi tipi/stopword)."""
    n = unicodedata.normalize("NFKD", str(name)).lower()
    words = re.findall(r"[a-zàèéìòù]+", n)
    return sorted({w for w in words if w not in _STOPWORDS and len(w) >= 5})


class SchoolDirectory:
    """Directory scuola->sito da Open Data MIM (provincia Milano)."""

    def __init__(self, path: str | Path = DIR_FILE):
        self.data: dict[str, list[str]] = {}
        p = Path(path)
        if p.exists():
            raw = json.loads(p.read_text(encoding="utf-8"))
            for k, urls in raw.items():
                self.data[k] = sorted({u for u in (self._norm_url(x) for x in urls) if u})

    @staticmethod
    def _norm_url(u: str) -> str | None:
        """Normalizza URL sporchi del dataset: fix schema, strip path/query,
        deriva .edu.it dai .gov.it morti, scarta junk."""
        u = (u or "").strip()
        if not u or "non disponibile" in u.lower():
            return None
        u = re.sub(r"^https(?=//)", "https:", u, flags=re.I)
        u = re.sub(r"^http(?=//)", "http:", u, flags=re.I)
        if not u.startswith(("http://", "https://")):
            u = "https://" + u
        parsed = re.match(r"(https?://[^/]+)", u)
        if not parsed:
            return None
        host = parsed.group(1).rstrip("/")
        out = {host}
        if host.lower().endswith(".gov.it"):
            out.add(re.sub(r"\.gov\.it$", ".edu.it", host, flags=re.I))
        # preferisci https
        return sorted(out, key=lambda h: (not h.startswith("https"), len(h)))[0]

    def lookup(self, name: str) -> list[str]:
        """Ritorna i domini migliori per il nome (scoring multi-segnale)."""
        n = norm(name)
        candidates: dict[str, int] = {}

        def add(key: str, score: int):
            for u in self.data.get(key, []):
                candidates[u] = max(candidates.get(u, 0), score)

        # 1) esatto
        add(n, 100)
        # 2) codice meccanografico: "MIIC860003 - S.PELLICO-ARLUNO", "miic8bf00g"
        m = re.match(r"([A-Z]{2}[A-Z0-9]{7,9})", str(name), re.I)
        if m:
            add(norm(m.group(1)), 90)
        # 3) famiglie prefix sul core (mantiene prefisso IC/IS/...)
        slug = slugify(str(name))
        core = _CITY_SUFFIX.sub("", slug)
        core = norm(core)
        # 4) token significativi del nome
        toks = _significant_tokens(str(name))

        for key in self.data:
            s = 0
            if len(core) >= 8 and (key.startswith(core) or core.startswith(key)):
                s += 40
            sh = sum(1 for t in toks if t in key)
            if sh:
                s += 5 + 6 * sh
            if re.match(r"^(ic|is|iis|ipsia|iss|liceo|istituto|cpia)", key):
                s += 6
            if re.match(r"^(infanzia|primaria|second|secigr|paritaria|nido|materna)", key):
                s -= 30  # scuole costituenti: non è l'istituto che pubblica
            if s:
                s -= abs(len(key) - len(core)) * 0.15
            if s >= 15:
                add(key, s)

        # ordina per qualità della corrispondenza, poi: .edu.it, https,
        # host che contiene il core del nome, specificità
        def rank(u: str) -> tuple:
            return (-candidates[u],
                    0 if ".edu.it" in u else 1,
                    not u.startswith("https"),
                    core not in u.lower(),
                    -len(u))
        return sorted(candidates, key=rank)


def candidate_domains(name: str) -> list[str]:
    slug = slugify(name)
    core = re.sub(r"^(ic|is|it|cpia|iis|ipsia|iss|liceo|istituto)[- ]?", "", slug)
    core = _CITY_SUFFIX.sub("", core)
    cands = set()
    for s in (slug, core):
        if len(s) >= 5:
            cands.add(f"https://www.{s}.edu.it/")
            cands.add(f"https://{s}.edu.it/")
    return sorted(cands)


def _probe_root(sess: requests.Session, base: str) -> str | None:
    try:
        r = sess.get(base, timeout=12, headers={"User-Agent": UA})
        if r.status_code == 200 and len(r.text) > 1500:
            return base
    except requests.RequestException:
        pass
    return None


def _section_urls(sess: requests.Session, base: str) -> list[tuple[str, str]]:
    """Ritorna [(label, url assoluta)] delle sezioni interpello/albo trovate."""
    found = []
    try:
        r = sess.get(base, timeout=12, headers={"User-Agent": UA})
    except requests.RequestException:
        return found
    if r.status_code != 200:
        return found
    soup = BeautifulSoup(r.text, "html.parser")
    seen = set()
    for a in soup.find_all("a", href=True):
        href, label = a["href"], re.sub(r"\s+", " ", a.get_text(" ", strip=True)).lower()
        if re.search(r"(albo|interpell|pubblicit)", href + " " + label, re.I):
            u = urljoin(base, href)
            if u not in seen:
                seen.add(u)
                found.append((label[:40] or "sezione", u))
    return found[:6]


def school_site(sess: requests.Session, name: str, domain_cache: dict | None = None,
                directory: SchoolDirectory | None = None) -> str | None:
    """Trova il dominio del sito ufficiale. Directory Open Data prima, probe dopo."""
    if domain_cache and name in domain_cache:
        return domain_cache[name]
    dir_ = directory or SchoolDirectory()
    for base in dir_.lookup(name):
        if _probe_root(sess, base):
            if domain_cache is not None:
                domain_cache[name] = base
            return base
    for base in candidate_domains(name):
        if _probe_root(sess, base):
            if domain_cache is not None:
                domain_cache[name] = base
            return base
    return None


def extract_subject_from_school(sess: requests.Session, base: str, days_back: int = 12) -> str:
    """Legge l'albo/sezioni interpello della scuola e classifica il soggetto."""
    candidates = [base] + [urljoin(base, p) for p in SECTION_PATHS]
    # prima le sezioni esplicite dal sito
    for label, u in _section_urls(sess, base):
        if u not in candidates:
            candidates.append(u)

    found_texts: list[str] = []
    for url in candidates:
        try:
            r = sess.get(url, timeout=15, headers={"User-Agent": UA})
            if r.status_code != 200:
                continue
            html = r.text
        except requests.RequestException:
            continue
        soup = BeautifulSoup(html, "html.parser")
        page_txt = re.sub(r"\s+", " ", soup.get_text(" ", strip=True))
        subj, conf = classify(page_txt)
        if conf >= 1.0:
            return subj
        found_texts.append(page_txt)
        # PDF allegati nelle carte/articoli recenti
        for pdf_url in _pdf_links(soup, url)[:6]:
            txt = fetch_pdf_text(pdf_url)
            if txt:
                subj, conf = classify(txt)
                if conf >= 1.0:
                    return subj
    blob = " ".join(found_texts)
    subj, conf = classify(blob)
    return subj if conf >= 1.0 else "da_verificare"


def _pdf_links(soup: BeautifulSoup, base: str) -> list[str]:
    out = []
    for a in soup.find_all("a", href=True):
        if re.search(r"\.pdf(?:$|\?)", a["href"], re.I):
            out.append(urljoin(base, a["href"]))
    return out[:12]


@dataclass
class SchoolProbe:
    school: str
    domain: str | None = None
    subject: str = "da_verificare"