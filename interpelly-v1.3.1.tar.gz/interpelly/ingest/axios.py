"""
axios.py — Lettura della piattaforma interpelli (serviziweb.axioscloud.it).

Da IP residenziale (PC di casa) la pagina è raggiungibile: contiene i dati
strutturati dell'avviso — classi di concorso, ore, periodo, scadenza, allegati
e il link di candidatura. Da datacenter risponde 403 (Cloudflare): il parser
lo rileva e degrada con grazia.

Nota: la pagina è una ASPX con campi di form generici; il parser è difensivo
(regole + testo libero) e salva un campione HTML in data/samples/ con
--capture-sample per rifinire i selettori su un caso reale.
"""

from __future__ import annotations

import re
from datetime import datetime
from pathlib import Path

from bs4 import BeautifulSoup

BLOCKED_MARKERS = ("Attention Required", "cf-chl", "cloudflare", "challenge-platform")

# Pattern classe di concorso (A24, A25, AA24, AB24, BA02, BD02, ADMM, ADEE, AD00, EEEE, AAAA…)
CLASSE_RE = re.compile(
    r"\b((?:AA?|AB|BA|BD|AD|BB|AC)\d{2}|ADMM|ADEE|ADSS|EEEE|AAAA|A\dB)\b", re.I)


def _norm_date(s: str) -> str | None:
    s = s.strip()
    for fmt in ("%d/%m/%Y", "%d-%m-%Y", "%d/%m/%y"):
        try:
            return datetime.strptime(s, fmt).date().isoformat()
        except ValueError:
            pass
    m = re.match(r"(\d{1,2})\s+([a-zàèéìòù]+)\s+(\d{4})", s.lower())
    if m:
        months = {mm: i + 1 for i, mm in enumerate(
            ["gennaio", "febbraio", "marzo", "aprile", "maggio", "giugno", "luglio",
             "agosto", "settembre", "ottobre", "novembre", "dicembre"])}
        if m.group(2) in months:
            try:
                return datetime(int(m.group(3)), months[m.group(2)], int(m.group(1))).date().isoformat()
            except ValueError:
                return None
    return None


class AxiosResult:
    def __init__(self):
        self.ok = False            # pagina letta con successo
        self.blocked = False       # Cloudflare/403
        self.classi: list[str] = []
        self.ore: str = ""
        self.periodo: str = ""
        self.scadenza: str = ""    # ISO date
        self.scadenza_text: str = ""
        self.comune: str = ""
        self.tipo_scuola: str = ""
        self.link_candidatura: str = ""
        self.allegati: list[str] = []
        self.raw_text: str = ""


def parse_axios_html(html: str, base_url: str = "") -> AxiosResult:
    res = AxiosResult()
    low = html.lower()
    if any(m in low for m in BLOCKED_MARKERS) and "Attention Required" in html:
        res.blocked = True
        return res
    soup = BeautifulSoup(html, "html.parser")
    text = re.sub(r"\s+", " ", soup.get_text(" ", strip=True))
    res.raw_text = text[:6000]
    res.ok = True

    # classi di concorso uniche (in ordine di comparsa)
    seen: list[str] = []
    for m in CLASSE_RE.finditer(text):
        c = m.group(1).upper()
        if c not in seen:
            seen.append(c)
    res.classi = seen

    # ore
    m = re.search(r"(\d{1,3}(?:[,.]\d)?)\s*ore", text, re.I)
    if m:
        res.ore = m.group(1).replace(",", ".")

    # periodo (dal … al …)
    m = re.search(r"(?:dal|dalle)\s+([\d/.\-]+)\s*(?:al|alle|fino al)?\s*([\d/.\-]+)?", text, re.I)
    if m:
        res.periodo = (m.group(0).strip())[:80]

    # scadenza: parola scadenza/entro seguita da data
    for m in re.finditer(r"(?:scadenza|entro|termine)\s*(?:candidatur[ae])?\s*[:.]?\s*([\d/.\-]+|\d{1,2}\s+[a-zàèéìòù]+\s+\d{4})", text, re.I):
        d = _norm_date(m.group(1))
        if d:
            res.scadenza = d
            res.scadenza_text = m.group(1)
            break

    # comune: "Comune di X" o riga indirizzo con città
    m = re.search(r"comune\s+(?:di\s+)?([A-ZÀ-Ü][A-Za-zÀ-ÿ'’ -]{3,30})", text, re.I)
    if m and not re.search(r"(scuola|istituto|docente)", m.group(1), re.I):
        res.comune = m.group(1).strip()

    # tipo scuola
    t = text.lower()
    for key, val in {"infanzia": "infanzia", "materna": "infanzia",
                     "primaria": "primaria", "elementare": "primaria",
                     "secondaria": "secondaria_ii", "i grado": "secondaria_i"}.items():
        if key in t:
            res.tipo_scuola = val
            break

    # link candidatura: anchor o form action verso candidat*
    for a in soup.find_all("a", href=True):
        if re.search(r"candidat|iscri|domand", a["href"] + " " + a.get_text(" ", strip=True), re.I):
            href = a["href"].strip()
            if href.startswith("javascript"):
                m2 = re.search(r"['\"]([^'\"]+?\.aspx[^'\"]*)['\"]", href)
                if m2:
                    href = m2.group(1)
            res.link_candidatura = href
            break
    if not res.link_candidatura:
        form = soup.find("form", action=True)
        if form:
            act = form["action"]
            if re.search(r"candidat|iscri", act, re.I):
                res.link_candidatura = act

    # allegati
    for a in soup.find_all("a", href=True):
        if re.search(r"\.(pdf|docx?|zip)(\?|$)", a["href"], re.I):
            res.allegati.append(a["href"])
            if len(res.allegati) >= 5:
                break
    return res


def save_sample(html: str, url: str, root: Path) -> Path:
    """Salva la pagina per il debug/refinamento dei selettori."""
    d = root / "data" / "samples"
    d.mkdir(parents=True, exist_ok=True)
    cid = re.search(r"cid=([A-Za-z0-9]+)", url)
    name = cid.group(1) if cid else "unknown"
    p = d / f"axios_{name}.html"
    p.write_text(html, encoding="utf-8")
    return p