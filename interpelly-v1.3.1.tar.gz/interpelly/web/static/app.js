/* app.js — La bacheca del supplente v2 */
"use strict";

const state = {
  subject: "",
  q: "",
  comune: "",
  tipo: "",
  fonte: "",
  dateFrom: "",
  dateTo: "",
  urgent: false,
  all: [],
  forMe: [],
  profile: {},
  comuni: [],
  visible: 40,   // righe mostrate (paginazione "carica altri")
  sig: "",
};

const PAGE = 40;

const $ = (s) => document.querySelector(s);
const esc = (s) =>
  String(s ?? "").replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

/* ---------- helpers ---------- */
function fmtDate(iso) {
  if (!iso) return "—";
  const d = new Date(iso);
  if (isNaN(d)) return iso.slice(0, 10);
  return d.toLocaleDateString("it-IT", { day: "2-digit", month: "short" }).replace(".", "");
}
function isUrgent(r) {
  if (!r.scadenza_iso) return false;
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const scad = new Date(r.scadenza_iso + "T00:00:00");
  const diff = (scad - today) / 86400000;
  return diff >= 0 && diff <= 2;
}
function subjectLabel(s) {
  return { sostegno: "sostegno", francese: "francese", da_verificare: "da verificare", altro: "altro" }[s] || "—";
}

async function api(path, opts) {
  const r = await fetch(path, opts);
  if (!r.ok) throw new Error(path);
  return await r.json();
}

/* ---------- render: ledger ---------- */
function renderLedger() {
  const total = state.all.length;
  const n = (s) => state.all.filter((r) => r.subject === s).length;
  const set = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = v; };
  set("led-total", total);
  set("led-sostegno", n("sostegno"));
  set("led-francese", n("francese"));
  set("cnt-all", total ? "(" + total + ")" : "");
  set("cnt-sostegno", n("sostegno") ? "(" + n("sostegno") + ")" : "");
  set("cnt-francese", n("francese") ? "(" + n("francese") + ")" : "");
  set("cnt-daverif", n("da_verificare") ? "(" + n("da_verificare") + ")" : "");
  const dates = state.all.map((r) => r.date_iso).filter(Boolean).sort().reverse();
  set("led-last", fmtDate(dates[0]) + " " + (dates[0] || "").slice(0, 4));
}

/* ---------- render: comuni chips ---------- */
function renderComuni() {
  const box = $("#comuni");
  box.innerHTML = "";
  state.comuni.slice(0, 10).forEach((c) => {
    const b = document.createElement("button");
    b.className = "chip" + (state.comune === c.comune ? " on" : "");
    b.textContent = `${c.comune} (${c.c})`;
    b.addEventListener("click", () => {
      state.comune = state.comune === c.comune ? "" : c.comune;
      renderComuni();
      render();
    });
    box.appendChild(b);
  });
}

/* ---------- render: trend ---------- */
function monthShort(ym) {
  if (!ym) return "";
  try {
    return new Date(ym + "-01").toLocaleDateString("it-IT", { month: "short" }).replace(".", "");
  } catch (_) { return ym.slice(5); }
}
function renderTrend() {
  const box = $("#trend-bars");
  box.innerHTML = "";
  const data = state.trend || [];
  const totals = data.map((d) => d.c);
  const max = Math.max(1, ...totals);
  data.forEach((d) => {
    const col = document.createElement("div");
    col.className = "trend-bar";
    const h = (d.c / max) * 100;
    const cls = { sostegno: "sostegno", francese: "francese", altro: "altro", da_verificare: "daverif" }[d.subject] || "altro";
    const seg = document.createElement("div");
    seg.className = `seg ${cls}`;
    seg.style.height = h + "%";
    seg.title = `${d.ym} · ${d.subject}: ${d.c}`;
    col.appendChild(seg);
    const lbl = document.createElement("span");
    lbl.className = "trend-lbl";
    lbl.textContent = monthShort(d.ym);
    col.appendChild(lbl);
    box.appendChild(col);
  });
}

/* ---------- render: entries ---------- */
function safeUrl(u) {
  const s = String(u || "").trim();
  if (!s) return "";
  // assoluti http(s) o relativi (con/senza slash iniziale) che NON contengono
  // uno schema pericoloso: "javascript:", "data:", "vbscript:" contengono ":"
  if (/^https?:\/\//i.test(s) || s.startsWith("/") || !/[:?#]/.test(s)) return s;
  return ""; // scarta javascript:, data:, vbscript: e altri schemi
}

function entryHtml(r, forMe = false) {
  const subj = r.subject;
  const tag =
    subj === "sostegno" ? `<span class="tag sostegno">sostegno</span>` :
    subj === "francese" ? `<span class="tag francese">francese</span>` :
    subj === "da_verificare" ? `<span class="tag check">da verificare</span>` :
    `<span class="tag">altro</span>`;
  const urg = isUrgent(r) ? `<span class="badge-urgent">scade ${fmtDate(r.scadenza_iso)}</span>` : "";
  const srcTag = r.fonte === "SCUOLA" ? `<span class="tag">sito scuola</span>` :
                 r.fonte === "Axios" ? `<span class="tag">interpello</span>` : "";
  const cls = (subj === "francese" || subj === "sostegno" ? "" : "other") + (forMe ? " fm" : "");
  const w = (r.watched ? "on" : "off");
  const schoolName = r.school_canonic || r.school || "—";
  const star = `<button class="star ${w}" data-school="${esc(r.school)}" title="segui la scuola" aria-label="${esc(r.school)}: ${w === "on" ? "togli dalla watchlist" : "aggiungi alla watchlist"}"></button>`;
  const match = r.match && Number.isFinite(Number(r.match.score)) ? r.match : null;
  const score = match ? Math.max(0, Math.min(100, Math.round(Number(match.score)))) : 0;
  const reasons = match && Array.isArray(match.reasons)
    ? match.reasons.map(String).filter(Boolean) : [];
  const matchBadge = match
    ? `<span class="match-badge ${score >= 80 ? "high" : score >= 50 ? "medium" : "low"}" title="${esc(reasons.join(" · "))}">MATCH ${score}%</span>`
    : "";
  const matchReasons = forMe && reasons.length
    ? `<p class="match-reasons">${esc(reasons.join(" · "))}</p>` : "";

  let details = "";
  const bits = [];
  if (r.classi_concorso && r.classi_concorso.length) bits.push(`<b>classi</b> ${esc(r.classi_concorso.join(", "))}`);
  if (r.ore) bits.push(`<b>ore</b> ${esc(r.ore)}`);
  if (r.periodo) bits.push(`<b>periodo</b> ${esc(r.periodo)}`);
  if (r.tipo_scuola) bits.push(`<b>grado</b> ${esc(r.tipo_scuola)}`);
  if (r.comune) bits.push(`<b>comune</b> ${esc(r.comune)}`);
  if (r.provincia && r.provincia !== "MILANO") bits.push(`<b>prov.</b> ${esc(r.provincia)}`);
  if (r.scadenza_iso) bits.push(`<b class="scad">scadenza</b> <span class="scad">${esc(r.scadenza_iso)}</span>`);
  if (bits.length) details = `<div class="entry-detail"><div class="detail-row">${bits.join("<span class=\"sep\">·</span>")}</div></div>`;

  const candBtn = `<button class="btn-cand ${r.candidato === "1" ? "done" : ""}" data-url="${esc(r.detail_url)}" data-on="${r.candidato === "1" ? "0" : "1"}">${r.candidato === "1" ? "✓ candidata" : "candidata"}</button>`;

  const links = [];
  const candUrl = safeUrl(r.link_candidatura);
  if (candUrl) links.push(`<a href="${esc(candUrl)}" target="_blank" rel="noopener">✍ candidatura ↗</a>`);
  const ustUrl = safeUrl(r.detail_url);
  if (ustUrl) links.push(`<a href="${esc(ustUrl)}" target="_blank" rel="noopener">albo UST ↗</a>`);
  const axUrl = safeUrl(r.axios_url);
  if (axUrl) links.push(`<a href="${esc(axUrl)}" target="_blank" rel="noopener">avviso interpello ↗</a>`);
  const sdUrl = safeUrl(r.school_domain);
  if (sdUrl) links.push(`<a href="${esc(sdUrl)}" target="_blank" rel="noopener">sito scuola ↗</a>`);
  const suUrl = safeUrl(r.scuola_url);
  if (suUrl) links.push(`<a href="${esc(suUrl)}" target="_blank" rel="noopener">pagina scuola ↗</a>`);
  if (!forMe && ustUrl) links.push(`<a href="/api/draft?detail_url=${encodeURIComponent(r.detail_url)}" target="_blank" rel="noopener">✍ bozza domanda</a>`);
  const linksHtml = `<div class="detail-links">${links.join("")}</div>`;
  const primary = forMe && ustUrl
    ? `<a class="primary" href="/api/draft?detail_url=${encodeURIComponent(r.detail_url)}" target="_blank" rel="noopener">✍ prepara domanda</a>`
    : "";

  const dateCell = forMe
    ? `<div class="entry-date fm-score"><b>${score}</b><span>% match</span></div>`
    : `<div class="entry-date">${fmtDate(r.date_iso)}${r.provincia && r.provincia !== "MILANO" ? `<br><span class="entry-count">${esc(r.provincia)}</span>` : ""}</div>`;

  return `<article class="entry ${cls}">
    ${dateCell}
    <div class="entry-body">
      <h2 class="entry-school">${star}<a href="${esc(ustUrl || r.detail_url)}" target="_blank" rel="noopener">${esc(schoolName)}</a></h2>
      ${matchReasons}
      <div class="entry-meta">${matchBadge}${tag}${srcTag}${urg}${r.candidato === "1" ? `<span class="tag candidato">candidata ✓</span>` : ""}${r.grade ? `<span class="entry-grade">${esc(r.grade.length > 42 ? r.grade.slice(0, 42) + "…" : r.grade)}</span>` : ""}</div>
      ${details}
      ${linksHtml}
    </div>
    <div class="entry-actions">${primary}${candBtn}</div>
  </article>`;
}

function render() {
  let rows = state.all;
  if (state.subject) rows = rows.filter((r) => r.subject === state.subject);
  if (state.tipo) rows = rows.filter((r) => r.tipo_scuola === state.tipo);
  if (state.fonte) rows = rows.filter((r) => r.fonte === state.fonte);
  if (state.comune) rows = rows.filter((r) => (r.comune || "").toLowerCase().includes(state.comune.toLowerCase()));
  if (state.urgent) rows = rows.filter(isUrgent);
  if (state.dateFrom || state.dateTo) {
    rows = rows.filter((r) => {
      const d = (r.date_iso || "").slice(0, 10);
      if (!d) return false;
      if (state.dateFrom && d < state.dateFrom) return false;
      if (state.dateTo && d > state.dateTo) return false;
      return true;
    });
  }
  if (state.q) {
    const q = state.q.toLowerCase();
    rows = rows.filter((r) =>
      (r.school || "").toLowerCase().includes(q) ||
      (r.grade || "").toLowerCase().includes(q) ||
      (r.comune || "").toLowerCase().includes(q));
  }

  /* se cambiano i filtri, torna alla prima pagina */
  const sig = JSON.stringify([state.subject, state.tipo, state.fonte, state.comune,
    state.urgent, state.dateFrom, state.dateTo, state.q]);
  if (sig !== state.sig) { state.visible = PAGE; state.sig = sig; }

  const list = $("#list");

  if (!rows.length) {
    list.innerHTML = `<p class="list-meta">0 risultati per questi filtri — <b>azzera qualcosa</b></p>` +
      `<div class="empty">Nessun avviso per questi filtri.</div>`;
    return;
  }

  const shown = rows.slice(0, state.visible);
  const more = rows.length - shown.length;
  list.innerHTML = `<p class="list-meta">mostrando <b>${shown.length}</b> di <b>${rows.length}</b> avvisi · più recenti prima</p>` +
    shown.map((r) => entryHtml(r)).join("") +
    (more > 0 ? `<button class="load-more" id="load-more">carica altri avvisi (${more})</button>` : "");

  bindEntryEvents(list);
  const lm = document.getElementById("load-more");
  if (lm) lm.addEventListener("click", () => {
    state.visible += PAGE;
    render();
    const next = document.getElementById("load-more");
    if (next) next.scrollIntoView({ block: "nearest" });
  });
}

function bindEntryEvents(root = document) {
  /* expand/collapse detail */
  root.querySelectorAll(".entry .entry-body").forEach((b) => {
    b.addEventListener("click", (e) => {
      if (e.target.closest("a") || e.target.closest(".star")) return;
      b.closest(".entry").classList.toggle("open");
    });
  });
  /* watch star */
  root.querySelectorAll(".star").forEach((s) => {
    s.addEventListener("click", async (e) => {
      e.stopPropagation();
      const school = s.dataset.school;
      const on = s.classList.contains("off");
      await api("/api/watchlist", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ school, on }),
      });
      state.all.forEach((r) => { if (r.school === school) r.watched = on; });
      state.forMe.forEach((r) => { if (r.school === school) r.watched = on; });
      render();
      renderForMe(state.forMe, state.profile);
    });
  });
  /* candidata ✓ */
  root.querySelectorAll(".btn-cand").forEach((b) => {
    b.addEventListener("click", async (e) => {
      e.stopPropagation();
      const url = b.dataset.url;
      const on = b.dataset.on === "1";
      try {
        await api("/api/interpelli/candidato", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ detail_url: url, on }),
        });
        state.all.forEach((r) => { if (r.detail_url === url) r.candidato = on ? "1" : "0"; });
        state.forMe.forEach((r) => { if (r.detail_url === url) r.candidato = on ? "1" : "0"; });
        render();
        renderForMe(state.forMe, state.profile);
      } catch (_) { /* ignora */ }
    });
  });
}

function renderForMe(rows, profile) {
  const section = $("#for-me");
  const callout = $("#for-me-callout");
  const configured = ["soggetti", "classi", "comuni", "grado"]
    .some((key) => String(profile?.[key] || "").trim());
  state.forMe = Array.isArray(rows) ? rows.slice(0, 5) : [];

  if (!configured || !state.forMe.length) {
    section.hidden = true;
    callout.hidden = false;
    $("#for-me-callout-text").textContent = configured
      ? "Nessun avviso su misura per ora — ricontrolla domani."
      : "Completa il profilo → Interpelly ti porta in cima gli avvisi su misura.";
    return;
  }

  callout.hidden = true;
  section.hidden = false;
  $("#for-me-list").innerHTML = state.forMe.map((r) => entryHtml(r, true)).join("");
  bindEntryEvents($("#for-me-list"));
}

async function loadForMe() {
  try {
    const [rows, profile] = await Promise.all([
      api("/api/interpelli?for_me=1&days=120"),
      api("/api/profile"),
    ]);
    state.profile = profile || {};
    renderForMe(rows, state.profile);
  } catch (_) {
    state.forMe = [];
    $("#for-me").hidden = true;
    $("#for-me-callout").hidden = true;
  }
}

/* ---------- data ---------- */
async function load(full = false) {
  try {
    const [rows, stats, com, trend, scan] = await Promise.all([
      api("/api/interpelli?days=120"),
      api("/api/stats"),
      api("/api/comuni"),
      api("/api/trend"),
      api("/api/scan"),
    ]);
    if (scan && scan.scanned) {
          $("#scan-status").textContent =
            `scansione scuole II grado: ${scan.ok}/${scan.scanned} siti · ${scan.interpelli_trovati} trovati`;
        }
    const schools = await api("/api/schools");
    const map = new Map(schools.map((s) => [s.name, s.domain]));
    rows.forEach((r) => { r.school_domain = map.get(r.school) || ""; });
    state.all = rows;
    state.comuni = com;
    state.trend = trend;
    renderLedger();
    renderComuni();
    renderTrend();
    render();
    await loadForMe();
  } catch (e) {
    $("#list").innerHTML = `<div class="empty">Albo non raggiungibile — <strong>riprova tra poco</strong>.</div>`;
  }
}

/* ---------- events ---------- */
document.querySelectorAll(".f-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".f-btn").forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    state.subject = btn.dataset.subject;
    render();
  });
});
$("#urgent").addEventListener("change", (e) => { state.urgent = e.target.checked; render(); });
$("#tipo").addEventListener("change", (e) => { state.tipo = e.target.value; render(); });
$("#fonte").addEventListener("change", (e) => { state.fonte = e.target.value; render(); });
$("#date-from").addEventListener("change", (e) => { state.dateFrom = e.target.value || ""; render(); });
$("#date-to").addEventListener("change", (e) => { state.dateTo = e.target.value || ""; render(); });
$("#date-clear").addEventListener("click", () => {
  state.dateFrom = state.dateTo = "";
  $("#date-from").value = $("#date-to").value = "";
  render();
});
$("#export-btn").addEventListener("click", () => {
  const p = new URLSearchParams();
  if (state.subject) p.set("subject", state.subject);
  if (state.comune) p.set("comune", state.comune);
  if (state.tipo) p.set("tipo", state.tipo);
  if (state.fonte) p.set("fonte", state.fonte);
  if (state.dateFrom) p.set("date_from", state.dateFrom);
  if (state.dateTo) p.set("date_to", state.dateTo);
  if (state.urgent) p.set("urgent_days", "2");
  if (state.q) p.set("q", state.q);
  window.location.href = "/api/export.csv?" + p.toString();
});
/* ---------- settings ---------- */
const $settings = $("#settings-modal");
const settingsState = { hasKey: false };

async function openSettings() {
  try {
    const s = await api("/api/settings");
    const ai = s.ai || {};
    settingsState.hasKey = !!ai.has_key;
    $("#s-base").value = ai.base_url || "";
    $("#s-model").value = ai.model || "";
    $("#s-key").value = "";
    $("#s-ai-enabled").checked = ai.enabled !== false;
    $("#s-test").textContent = "";
    $("#s-test").className = "test-status";
    $("#s-key-status").textContent = settingsState.hasKey
      ? `chiave salvata: …${ai.key_tail} — lascia vuoto per mantenerla`
      : "nessuna chiave salvata";
  } catch (_) {
    $("#s-key-status").textContent = "impostazioni non raggiungibili";
  }
  $settings.hidden = false;
  setTimeout(() => { try { $("#s-key").focus(); } catch (_) {} }, 30);
}

function closeSettings() { $settings.hidden = true; }

$("#settings-btn").addEventListener("click", openSettings);
$("#s-close").addEventListener("click", closeSettings);
$("#settings-modal").addEventListener("click", (e) => {
  if (e.target === $settings) closeSettings();
});
function trapModal(overlay, e) {
  if (e.key !== "Tab") return;
  const f = overlay.querySelectorAll('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])');
  if (!f.length) return;
  const first = f[0], last = f[f.length - 1];
  if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
  else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
}
$settings.addEventListener("keydown", (e) => trapModal($settings, e));
$("#s-save").addEventListener("click", async () => {
  const key = $("#s-key").value.trim();
  const ai = {
    AI_BASE_URL: $("#s-base").value.trim(),
    AI_MODEL: $("#s-model").value.trim(),
    AI_ENABLED: $("#s-ai-enabled").checked ? "1" : "0",
  };
  if (key || !settingsState.hasKey) ai.AI_API_KEY = key;   // vuoto senza chiave → niente
  const t = $("#s-test");
  try {
    await api("/api/settings", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ai }),
    });
    settingsState.hasKey = !!key;
    t.textContent = "salvato ✓ — le impostazioni valgono dal prossimo ciclo di ingest";
    t.className = "test-status ok";
    $("#s-key-status").textContent = key
      ? `chiave salvata: …${key.slice(-4)}`
      : settingsState.hasKey ? "chiave mantenuta" : "nessuna chiave salvata";
    $("#s-key").value = "";
  } catch (e) {
    t.textContent = "errore nel salvataggio";
    t.className = "test-status err";
  }
});

$("#s-test-btn").addEventListener("click", async () => {
  const btn = $("#s-test-btn");
  const t = $("#s-test");
  btn.disabled = true;
  t.textContent = "provo la connessione…";
  t.className = "test-status";
  try {
    const res = await api("/api/settings/test", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ai: {
        AI_API_KEY: $("#s-key").value.trim(),   // vuoto -> usa la chiave salvata
        AI_BASE_URL: $("#s-base").value.trim(),
        AI_MODEL: $("#s-model").value.trim(),
      } }),
    });
    if (res.ok) {
      const r = res.result || {};
      t.textContent = `connessione ok — estratto: subject=${r.subject || "—"} ` +
        `· classi=${(r.classi || []).join(",") || "—"} · scadenza=${r.scadenza || "—"}`;
      t.className = "test-status ok";
    } else {
      t.textContent = `connessione fallita: ${(res.error || "errore sconosciuto").slice(0, 140)}`;
      t.className = "test-status err";
    }
  } catch (e) {
    t.textContent = "connessione fallita (server)";
    t.className = "test-status err";
  }
  btn.disabled = false;
});

/* ---------- profilo candidata ---------- */
const $profile = $("#profile-modal");

async function openProfile() {
  try {
    const p = await api("/api/profile");
    $("#p-nome").value = p.nome || "";
    $("#p-email").value = p.email || "";
    $("#p-telefono").value = p.telefono || "";
    $("#p-titoli").value = p.titoli || "";
    $("#p-soggetti").value = p.soggetti || "";
    $("#p-classi").value = p.classi || "";
    $("#p-comuni").value = p.comuni || "";
    $("#p-grado").value = p.grado || "";
    $("#p-note").value = p.note || "";
    $("#p-status").textContent = "";
    $("#p-status").className = "test-status";
  } catch (_) { /* ignora */ }
  $profile.hidden = false;
  setTimeout(() => { try { $("#p-nome").focus(); } catch (_) {} }, 30);
}

$("#profile-btn").addEventListener("click", openProfile);
$("#for-me-profile").addEventListener("click", openProfile);
$("#p-close").addEventListener("click", () => { $profile.hidden = true; });
$("#profile-modal").addEventListener("click", (e) => { if (e.target === $profile) $profile.hidden = true; });
$profile.addEventListener("keydown", (e) => trapModal($profile, e));
document.addEventListener("keydown", (e) => {
  if (e.key !== "Escape") return;
  if (!$settings.hidden) closeSettings();
  else if (!$profile.hidden) $profile.hidden = true;
});

$("#p-save").addEventListener("click", async () => {
  const st = $("#p-status");
  try {
    await api("/api/profile", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        nome: $("#p-nome").value, email: $("#p-email").value,
        telefono: $("#p-telefono").value, titoli: $("#p-titoli").value,
        soggetti: $("#p-soggetti").value, classi: $("#p-classi").value,
        comuni: $("#p-comuni").value, grado: $("#p-grado").value,
        note: $("#p-note").value,
      }),
    });
    await loadForMe();
    st.textContent = "profilo salvato ✓ — usalo sulla bozza di domanda di ogni avviso";
    st.className = "test-status ok";
  } catch (_) {
    st.textContent = "errore nel salvataggio";
    st.className = "test-status err";
  }
});

let debounce;
$("#q").addEventListener("input", (e) => {
  clearTimeout(debounce);
  debounce = setTimeout(() => { state.q = e.target.value.trim(); render(); }, 180);
});

load();
setInterval(() => load(true), 5 * 60 * 1000);  /* auto-aggiornamento silenzioso */

/* installabilità PWA (solo se serve worker e siamo su localhost/https) */
if ("serviceWorker" in navigator && (location.protocol === "https:" || location.hostname === "localhost" || location.hostname === "127.0.0.1")) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("/static/sw.js").catch(() => {});
  });
}
