"""
app.py — Web app "La bacheca del supplente" — Milano (e provincia).

API:
  GET  /                          -> dashboard
  GET  /api/stats                 -> statistiche
  GET  /api/interpelli            -> filtri: subject, q, comune, tipo,
                                     urgent_days, watch, days, for_me, match_min
  GET/POST /api/profile            -> profilo candidata e criteri di match
  GET  /api/comuni                -> top comuni
  GET  /api/trend                 -> andamento mensile per soggetto
  GET  /api/export.csv            -> esportazione CSV (tutti i filtri)
  GET  /api/watchlist             -> scuole in watchlist
  POST /api/watchlist             -> {school, on} toggla la watch
"""

from __future__ import annotations

import csv
import io
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from fastapi import FastAPI, Query, Request, Response  # noqa: E402
from fastapi.responses import FileResponse, JSONResponse, PlainTextResponse  # noqa: E402
from fastapi.staticfiles import StaticFiles  # noqa: E402

from ingest.store import Store  # noqa: E402
from ingest.match import top_matches  # noqa: E402

DB = Path(os.environ.get("INTERPELLY_DB", str(ROOT / "data" / "interpelli.db")))
STATIC = Path(__file__).resolve().parent / "static"

app = FastAPI(title="Interpelly — La bacheca del supplente", version="1.3.1")

_store: Store | None = None


def store() -> Store:
    global _store
    if _store is None:
        _store = Store(DB)
    return _store


# --- basic auth opzionale (accesso remoto da telefono) -----------------------
_USER = os.environ.get("DASHBOARD_USER", "")
_PASS = os.environ.get("DASHBOARD_PASS", "")


@app.middleware("http")
async def auth(request: Request, call_next):
    if _USER and _PASS and request.url.path not in ("/static/style.css", "/static/app.js"):
        import base64
        h = request.headers.get("authorization", "")
        ok = False
        if h.startswith("Basic "):
            try:
                u, p = base64.b64decode(h[6:]).decode().split(":", 1)
                ok = (u == _USER and p == _PASS)
            except Exception:
                pass
        if not ok:
            return Response("auth required", status_code=401,
                            headers={"WWW-Authenticate": 'Basic realm="bacheca"'})
    return await call_next(request)


@app.get("/")
def index() -> FileResponse:
    return FileResponse(STATIC / "index.html")


@app.get("/api/stats")
def stats():
    return JSONResponse(store().stats())


@app.get("/api/interpelli")
def interpelli(subject: str | None = Query(default=None),
               q: str | None = Query(default=None),
               comune: str | None = Query(default=None),
               tipo: str | None = Query(default=None),
               urgent_days: int | None = Query(default=None),
               watch: bool = Query(default=False),
               fonte: str | None = Query(default=None),
               date_from: str | None = Query(default=None),
               date_to: str | None = Query(default=None),
               days: int = Query(default=120),
               for_me: bool = Query(default=False),
               match_min: int | None = Query(default=None)):
    rows = store().interpelli(subject=subject, school=q, comune=comune, tipo=tipo,
                              urgent_days=urgent_days, watch=watch, fonte=fonte,
                              date_from=date_from, date_to=date_to,
                              since_days=days, limit=3000)
    if for_me:
        rows = top_matches(rows, store().get_profile(), limit=100)
        if match_min is not None:
            rows = [r for r in rows if r["match"]["score"] >= match_min]
    return JSONResponse(rows)


@app.get("/api/settings")
def get_settings():
    """Impostazioni AI (chiave mascherata)."""
    st = store()
    s = st.get_settings()
    key = s.get("AI_API_KEY", "") or ""
    return JSONResponse({"ai": {
        "has_key": bool(key),
        "key_tail": key[-4:] if key else "",
        "base_url": s.get("AI_BASE_URL") or "https://openrouter.ai/api/v1",
        "model": s.get("AI_MODEL") or "openrouter/auto",
        "active": bool(st.ai_effective().get("AI_API_KEY")),
        "enabled": st.get_meta("AI_ENABLED", "1") != "0",
    }})


@app.post("/api/settings")
async def save_settings(request: Request):
    body = await request.json()
    ai = (body.get("ai") or {}) if isinstance(body, dict) else {}
    st = store()
    st.set_settings({k: ai.get(k) for k in ("AI_API_KEY", "AI_BASE_URL", "AI_MODEL")})
    return JSONResponse({"ok": True})


@app.post("/api/settings/test")
async def test_settings(request: Request):
    """Prova la connessione AI con i valori indicati (senza salvarli).
    Se la chiave è vuota usa quella salvata."""
    body = await request.json()
    ai = (body.get("ai") or {}) if isinstance(body, dict) else {}
    settings = {k: (ai.get(k) or "") for k in ("AI_API_KEY", "AI_BASE_URL", "AI_MODEL")}
    if not settings["AI_API_KEY"]:
        settings["AI_API_KEY"] = store().ai_effective().get("AI_API_KEY", "")
    from ingest.ai import _call
    try:
        data = _call("Classe di concorso AA24 Francese, ore settimanali 18, "
                     "scadenza 20/08/2026", settings)
        ok = bool(data) and "subject" in data
        return JSONResponse({"ok": ok, "result": data})
    except Exception as e:
        return JSONResponse({"ok": False, "error": f"{type(e).__name__}: {e}"})


@app.get("/api/profile")
def get_profile():
    return JSONResponse(store().get_profile())


@app.post("/api/profile")
async def save_profile(request: Request):
    body = await request.json()
    data = body if isinstance(body, dict) else {}
    store().set_profile(data)
    return JSONResponse({"ok": True})


@app.post("/api/interpelli/candidato")
async def set_candidato(request: Request):
    body = await request.json()
    url = (body.get("detail_url") or "").strip()
    if not url:
        return JSONResponse({"error": "detail_url mancante"}, status_code=400)
    store().set_candidato(url, bool(body.get("on")))
    return JSONResponse({"ok": True})


@app.get("/api/draft")
def draft(detail_url: str = Query(default=None), fmt: str = Query(default="html")):
    """Bozza di domanda per un interpello (html stampabile o testo)."""
    if not detail_url:
        return JSONResponse({"error": "detail_url mancante"}, status_code=400)
    row = store().conn.execute("SELECT * FROM interpelli WHERE detail_url=?",
                               (detail_url,)).fetchone()
    if not row:
        return JSONResponse({"error": "avviso non trovato"}, status_code=404)
    r = dict(row)
    profile = store().get_profile()
    if fmt == "txt":
        from ingest.draft import build_text
        return PlainTextResponse(build_text(r, profile), media_type="text/plain; charset=utf-8")
    from ingest.draft import build_html
    return Response(content=build_html(r, profile),
                    media_type="text/html; charset=utf-8")


@app.get("/api/health")
def health():
    return JSONResponse(store().health())


@app.get("/api/schools")
def schools():
    conn = store().conn
    rows = [dict(r) for r in conn.execute(
        "SELECT name, domain, subject, updated_ts FROM schools "
        "WHERE domain IS NOT NULL ORDER BY name LIMIT 2000")]
    return JSONResponse(rows)


@app.get("/api/scan")
def scan_status():
    """Stato della scansione delle scuole secondarie II di Milano."""
    return JSONResponse(store().scan_stats())


@app.get("/api/comuni")
def comuni():
    return JSONResponse(store().comuni())


@app.get("/api/trend")
def trend():
    return JSONResponse(store().trend())


@app.get("/api/export.csv")
def export_csv(subject: str | None = None, q: str | None = None,
               comune: str | None = None, tipo: str | None = None,
               urgent_days: int | None = None, watch: bool = False,
               fonte: str | None = None, date_from: str | None = None,
               date_to: str | None = None):
    rows = store().interpelli(subject=subject, school=q, comune=comune, tipo=tipo,
                              urgent_days=urgent_days, watch=watch, fonte=fonte,
                              date_from=date_from, date_to=date_to,
                              since_days=400, limit=5000)
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["data", "provincia", "comune", "scuola", "soggetto", "classi",
                "ore", "tipo_scuola", "scadenza", "fonte", "link_dettaglio",
                "link_candidatura", "sito_scuola"])
    for r in rows:
        w.writerow([r.get("date_iso", "")[:10], r.get("provincia", ""),
                    r.get("comune", ""), r.get("school", ""), r.get("subject", ""),
                    ", ".join(r.get("classi_concorso") or []), r.get("ore", ""),
                    r.get("tipo_scuola", ""), r.get("scadenza_iso", ""),
                    r.get("fonte", ""), r.get("detail_url", ""),
                    r.get("link_candidatura", ""),
                    _school_domain(r.get("school", ""))])
    return Response(content=buf.getvalue(), media_type="text/csv; charset=utf-8",
                    headers={"Content-Disposition": "attachment; filename=interpelli.csv"})


def _school_domain(name: str) -> str:
    r = store().conn.execute("SELECT domain FROM schools WHERE name=?", (name,)).fetchone()
    return r["domain"] if r else ""


@app.get("/api/watchlist")
def watchlist():
    conn = store().conn
    rows = [dict(r) for r in conn.execute(
        "SELECT name, domain, subject FROM schools WHERE watch=1 ORDER BY name")]
    return JSONResponse(rows)


@app.post("/api/watchlist")
async def watchlist_toggle(request: Request):
    body = await request.json()
    school = (body.get("school") or "").strip()
    on = bool(body.get("on"))
    if not school:
        return JSONResponse({"error": "school mancante"}, status_code=400)
    st = store()
    st.upsert_school(school)
    st.set_watch(school, on)
    return JSONResponse({"school": school, "watch": on})


app.mount("/static", StaticFiles(directory=str(STATIC)), name="static")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
