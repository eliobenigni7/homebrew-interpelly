@echo off
REM contrib/avvio_bacheca_windows.bat — autostart del monitor interpelli (Windows).
REM Usa il loop headless (ingest + scan + notifiche) nel venv del progetto.
REM
REM Installazione:
REM   1. crea un collegamento (scorciatoia) a questo file
REM   2. Win+R -> shell:startup -> Incolla la scorciatoia
REM
REM Alternativa con GUI: usa l'app Electron (bacheca-supplente-desktop.exe,
REM via "npm run dist:win") e metti la scorciatoia dell'exe in shell:startup:
REM l'app parte in tray, avvia da sola il backend e resta sempre accesa.

setlocal
cd /d "%~dp0.."
if exist ".venv\Scripts\python.exe" (
    set "PY=.venv\Scripts\python.exe"
) else (
    set "PY=python"
)

REM Notifiche Telegram: scommenta e valorizza
REM set "TG_TOKEN=123456:ABC..."
REM set "TG_CHAT=123456789"

"%PY%" run_loop.py --interval 1 --scan --notify >> data\ingest.log 2>&1
endlocal