"""
scripts/build_school_directory.py — Rigenera data/mi_sites.json
(directory autoritativa scuola -> sito per la provincia Milano).

Fonte: Open Data MIM "Anagrafe Scuole Statali" (proiezione per anno scolastico).
URL attuale: https://dati.istruzione.it/opendata/opendata/catalogo/elements1/SCUANAGRAFESTAT_yyddaamm.csv
Vi si arriva dal catalogo: https://dati.istruzione.it/opendata/opendata/catalogo/elements1/?area=Scuole

Uso: python3 scripts/build_school_directory.py [--year 202627] [--province MILANO]
"""
from __future__ import annotations

import argparse
import collections
import csv
import json
import re
import sys
import unicodedata
import urllib.request
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

def norm(s: str) -> str:
    s = unicodedata.normalize("NFKD", str(s))
    s = "".join(c for c in s if not unicodedata.combining(c)).lower()
    return re.sub(r"[^a-z0-9]+", "", s)

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--year", default="202627")
    ap.add_argument("--province", default="MILANO")
    ap.add_argument("--out", default="data/mi_sites.json")
    args = ap.parse_args()

    # il nome del dataset non è prevedibile a priori; qui si presuppone il
    # pattern osservato. Adatta l'anno se il file non esiste più.
    urls = [
        f"https://dati.istruzione.it/opendata/opendata/catalog/SCUANAGRAFESTAT{args.year}20260901.csv",
    ]
    buf = None
    for u in urls:
        print("download", u)
        try:
            with urllib.request.urlopen(u, timeout=60) as r:
                buf = r.read()
            break
        except Exception as e:
            print("  !", e)
    if buf is None:
        print("Impossibile scaricare il CSV. Controlla il nome sul catalogo Open Data.")
        return 1

    text = buf.decode("utf-8", "ignore")
    io = __import__("io")
    rows = list(csv.DictReader(io.StringIO(text)))

    by_norm = collections.defaultdict(set)
    for r in rows:
        if r.get("PROVINCIA") != args.province:
            continue
        u = (r.get("SITOWEBSCUOLA") or "").strip()
        if not u:
            continue
        if u.lower().startswith("http://www.pubblica"):  # segnaposto MIM
            continue
        by_norm[norm(r["DENOMINAZIONESCUOLA"])].add(u)
        by_norm[norm(r["CODICESCUOLA"])].add(u)
        by_norm[norm(r["DENOMINAZIONEISTITUTORIFERIMENTO"])].add(u)

    # il risolutore (ingest/schools.py) normalizza ancora gli URL (fix schema,
    # strip path, deriva .edu.it): qui salviamo i valori grezzi puliti.
    out = {k: sorted(v) for k, v in by_norm.items()}
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    Path(args.out).write_text(json.dumps(out, ensure_ascii=False), encoding="utf-8")
    print(f"OK: {len(out)} chiavi -> {args.out}")

    # --- elenco secondarie di II grado (per lo scan dei siti) --------------
    SECONDARIA_II_MARK = ("LICEO", "ISTITUTO SUPERIORE", "ISTITUTO TECNICO",
                          "IST PROF", "ISTITUTO MAGISTRALE", "EDUCANDATO", "CONVITTO")

    def is_ii(r):
        g = (r.get("DESCRIZIONETIPOLOGIAGRADOISTRUZIONESCUOLA") or "").upper()
        return any(m in g for m in SECONDARIA_II_MARK)

    def clean(u):
        u = (u or "").strip()
        if not u or "NON DISPONIBILE" in u.upper() or u.lower().startswith("http://www.pubblica"):
            return None
        u = re.sub(r"^https(?=//)", "https:", u, flags=re.I)
        u = re.sub(r"^http(?=//)", "http:", u, flags=re.I)
        if not u.startswith(("http://", "https://")):
            u = "https://" + u
        m = re.match(r"(https?://[^/]+)", u)
        return m.group(1).rstrip("/").lower() if m else None

    sites = collections.defaultdict(set)
    scodes = collections.defaultdict(set)
    for r in rows:
        if not is_ii(r) or r.get("PROVINCIA") != args.province:
            continue
        h = clean(r.get("SITOWEBSCUOLA"))
        if not h:
            continue
        sites[h].add(r["DENOMINAZIONESCUOLA"].strip())
        scodes[h].add(r["CODICESCUOLA"])
        ref = (r.get("DENOMINAZIONEISTITUTORIFERIMENTO") or "").strip()
        if ref and ref != r["DENOMINAZIONESCUOLA"].strip():
            sites[h].add(ref)
        if r.get("CODICEISTITUTORIFERIMENTO"):
            scodes[h].add(r["CODICEISTITUTORIFERIMENTO"])
    sec = [{"site": h, "names": sorted(sites[h]), "codes": sorted(scodes[h])}
           for h in sites]
    sec.sort(key=lambda x: (0 if ".edu.it" in x["site"] else 1, x["site"]))
    sec_path = Path("data/secondaria_milano.json")
    sec_path.write_text(json.dumps(sec, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"OK: {len(sec)} siti secondaria II -> {sec_path}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())