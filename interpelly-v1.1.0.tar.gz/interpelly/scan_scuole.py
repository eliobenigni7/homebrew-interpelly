"""
scan_scuole.py — Scan delle scuole secondarie di II grado di Milano:
crawl dei siti istituzionali alla ricerca di interpelli (francese/sostegno).

Elenco scuole: data/secondaria_milano.json (generato da Open Data MIM v2).
Incrementale: i siti già scansionati vengono saltati (--rescan per rifarli).

Uso:
  python3 scan_scuole.py [--limit N] [--workers 4] [--rescan]
                         [--max-pdfs 5] [--recent-days 45] [--verbose]
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from pathlib import Path

import requests

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from ingest.store import Store  # noqa: E402
from ingest.scuole_scan import scan_site  # noqa: E402
from ingest.config import TARGETS  # noqa: E402

DB = ROOT / "data" / "interpelli.db"
SCHOOLS_FILE = ROOT / "data" / "secondaria_milano.json"
PROV = "MILANO"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--limit", type=int, default=0, help="max siti in questo run (0=tutti)")
    ap.add_argument("--workers", type=int, default=4)
    ap.add_argument("--rescan", action="store_true")
    ap.add_argument("--max-pdfs", type=int, default=5)
    ap.add_argument("--recent-days", type=int, default=45)
    ap.add_argument("--verbose", action="store_true")
    args = ap.parse_args()

    schools = json.loads(SCHOOLS_FILE.read_text(encoding="utf-8"))
    store = Store(DB)
    if not args.rescan:
        done = store.scanned_sites()
        todo = [s for s in schools if s["site"] not in done]
    else:
        todo = list(schools)
    if args.limit:
        todo = todo[: args.limit]

    print(f"[{datetime.now():%H:%M}] Scan secondaria II Milano — "
          f"{len(todo)} siti da processare ({args.workers} worker)")

    def run_one(sitemap: dict):
        return scan_site(requests.Session(), sitemap["site"], sitemap["names"],
                         max_pdfs=args.max_pdfs, recent_days=args.recent_days)

    counts = {"ok": 0, "unreachable": 0, "error": 0, "found": 0}
    all_found = []
    t0 = time.time()
    done_idx = 0

    with ThreadPoolExecutor(max_workers=args.workers) as ex:
        futs = {ex.submit(run_one, s): s for s in todo}
        for fut in as_completed(futs):
            sitemap = futs[fut]
            done_idx += 1
            try:
                sc = fut.result()
            except Exception as e:
                counts["error"] += 1
                sc = None
                if args.verbose:
                    print(f"  ! {sitemap['site']}: {e}")
            if sc is not None:
                store.upsert_scan(sc)
                counts[sc.status if sc.status in counts else "error"] += 1
                if sc.found:
                    counts["found"] += len(sc.found)
                    for f in sc.found:
                        all_found.append((sc, f))
                        _persist_found(store, sc, f)
                        print(f"  ★ {f.subject:<9} {sc.site.split('//')[1][:36]:<38} "
                              f"| {f.entry.title[:52]}")
                elif args.verbose:
                    print(f"  · {sc.status}: {sc.site.split('//')[1][:50]}")
            if done_idx % 25 == 0:
                print(f"  … {done_idx}/{len(todo)} siti "
                      f"({time.time()-t0:.0f}s) | trovati: {counts['found']}")

    hm = store.merge_duplicates()
    if hm:
        print(f"  duplicati unificati: {hm}")
    store.close()
    print(f"\n==== REPORT SCAN secondaria II {PROV} ====")
    print(f"  siti processati: {len(todo)} | tempo: {time.time()-t0:.0f}s")
    print(f"  raggiungibili: {counts['ok']} | non raggiungibili: {counts['unreachable']}"
          f" | errori: {counts['error']}")
    print(f"  interpelli target trovati: {counts['found']}")
    from collections import Counter
    for s, c in Counter(f.subject for _, f in all_found).most_common():
        print(f"    - {s}: {c}")
    return 0


def _persist_found(store: Store, sc, f) -> None:
    """Inserisce l'interpello trovato sul sito scuola (fonte=SCUOLA)."""
    school = sc.names[0] if sc.names else sc.site
    detail_url = f.entry.url
    date_iso = f.entry.date or datetime.now().date().isoformat()
    store.conn.execute("""
        INSERT INTO interpelli(detail_url, date_iso, date_str, school, grade,
                               subject, confidence, axios_url, raw_text, created_ts,
                               comune, tipo_scuola, classi_concorso, ore, periodo,
                               scadenza_iso, link_candidatura, fonte, provincia)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        ON CONFLICT(detail_url) DO UPDATE SET
          date_iso=excluded.date_iso, subject=excluded.subject,
          school=excluded.school, classi_concorso=excluded.classi_concorso,
          link_candidatura=excluded.link_candidatura, fonte=excluded.fonte
    """, (detail_url, date_iso, date_iso, school, "",
          f.subject, 1.0, f.pdf_url, f.entry.title,
          datetime.now().isoformat(), "", "secondaria_ii",
          json.dumps(f.classi, ensure_ascii=False), "", "", "",
          f.pdf_url, "SCUOLA", PROV))
    store.conn.commit()


if __name__ == "__main__":
    raise SystemExit(main())