<div align="center">

# ✻ Interpelly

### La bacheca del supplente — interpelli di **Francese** e **Sostegno** nella provincia di Milano (e tutta la Lombardia)

> Uno scanner sempre acceso che raccoglie, classifica e ti avvisa in tempo reale
> quando una scuola pubblica un interpello per supplenze — senza cercare tra
> 700 siti scolastici.

**Python + FastAPI + SQLite · Electron desktop · Telegram · Docker**

![dashboard](anteprima-bacheca-v2.png)

[![Python](https://img.shields.io/badge/Python-3.11+-1a1611?style=flat&logo=python&logoColor=verde&labelColor=1a1611&color=c0391b)](requirements.txt)
[![Electron](https://img.shields.io/badge/Electron-33-1a1611?style=flat&logo=electron&labelColor=1a1611&color=c0391b)](desktop/package.json)
[![FastAPI](https://img.shields.io/badge/FastAPI-API-1a1611?style=flat&logo=fastapi&labelColor=1a1611&color=c0391b)](web/app.py)
[![License](https://img.shields.io/badge/Licence-CC--BY--NC--4.0-1a1611?style=flat&labelColor=1a1611&color=c0391b)](LICENSE)

*Carta crema, inchiostro carbone, un punto di vermiglio.*

</div>

---

## Indice

- [Cos'è Interpelly](#cosè-interpelly)
- [Funzionalità](#funzionalità)
- [Come funziona](#come-funziona)
- [Le fonti, con i loro limiti](#le-fonti-con-i-loro-limiti)
- [Installazione](#installazione)
- [Avvio rapido](#avvio-rapido)
- [App desktop (Electron)](#app-desktop-electron)
- [Docker / VPS](#docker--vps)
- [Guida per piattaforme](#guida-per-piattaforme)
- [Configurazione](#configurazione)
- [CLI](#cli)
- [API](#api)
- [Scan delle scuole secondarie di II grado](#scan-delle-scuole-secondarie-di-ii-grado)
- [Notifiche](#notifiche)
- [Struttura del progetto](#struttura-del-progetto)
- [Persistenza](#persistenza)
- [Estendere](#estendere)
- [Limiti noti e onestà tecnica](#limiti-noti-e-onestà-tecnica)
- [Etica e legalità](#etica-e-legalità)
- [FAQ](#faq)
- [Roadmap](#roadmap)
- [Licenza](#licenza)

---

## Cos'è Interpelly

In Italia gli **interpelli** sono gli avvisi con cui le scuole pubblicano i posti
di supplenza non coperti da graduatorie (docenti, sostegno, ATA). Vengono
pubblicati sul sito di ogni scuola e sull'**Ufficio Scolastico Territoriale**:
devono essere cercati a mano, sito per sito, e scadono in fretta.

**Interpelly le cerca per te**: scansiona le fonti autoritative, classifica ogni
avviso per soggetto (francese, sostegno…), estrae i dettagli utili (classi di
concorso, ore, scadenza, link di candidatura) e ti **avvisa su Telegram** quando
esce qualcosa di rilevante — con una **dashboard** all'insegna della semplicità
per rivedere tutto.

Pensato per chi inizia a lavorare nella scuola (supplenze di **Francese** e
**Sostegno**) e vuole arrivare per primo alla candidatura.

## Funzionalità

| Area | Cosa fa |
|---|---|
| **Indice autoritativo** | crawler dell'albo **UST Milano** (portale MIM): tutti gli interpelli, con data, scuola, grado e link. Server-rendered, raggiungibile da qualsiasi host |
| **Soggetto strutturato** | in modalità **home** legge la **piattaforma Axios** di ogni avviso: **classi di concorso** (A24, AA24, ADEE…), **ore**, **periodo**, **scadenza**, **comune** e **link di candidatura** |
| **Multi-provincia** | 12 province lombarde configurate (`INTERPELLI_PROVINCES=MILANO,BERGAMO,…`); l'architettura accetta qualunque UST |
| **Scan scuole secondarie II** | crawl dei **138 siti istituzionali** delle secondarie di II grado di Milano, alla ricerca di interpelli pubblicati direttamente dalle scuole (spesso prima dell'UST) |
| **Resolver albo scuole** | directory autoritativa scuola→sito (Open Data MIM) + probe delle sezioni albo/interpello → soggetto anche da VPS |
| **Watchlist ⭐** | segui le scuole preferite: avvisi prioritari, filtro dedicato e **fast-poll ogni 15 min** sui loro siti (`run_watch.py`) |
| **Scadenze** | filtro *scade ≤ 48h*, badge di urgenza, **promemoria Telegram 24h** una volta al giorno |
| **Profilo candidata + bozza domanda** | nome, titoli, disponibilità salvati → **bozza di domanda** pronta in un clic per ogni avviso (testo o HTML stampabile "Salva come PDF"), con stato **candidata ✓** tenuto in dashboard |
| **Filtri** | soggetto, comune (chip), grado (infanzia/primaria/secondaria I-II), fonte, **range di date**, ricerca libera, urgenza |
| **Export CSV** | foglio di calcolo pronto per gestire le candidature (classi, ore, scadenza, link) |
| **Nomi scuola canonici** | "MIIC860003 - S.PELLICO-ARLUNO" → "S.Pellico-Arluno"; **duplicati scuola+data tra fonti unificati** automaticamente |
| **PWA** | installabile su telefono (manifest + service worker, stessa estetica) |
| **Statistiche & trend** | conteggi per soggetto, andamento mensile (SVG minimale, zero librerie) |
| **Notifiche** | **Telegram** (HTML, pulsanti Candidatura/Albo/Avviso) + **digest email** opzionale |
| **Heartbeat** | `check_health.py`: esce 0/1 se l'ingest è in ritardo o fallisce N volte, alert Telegram opzionale |
| **Dashboard editoriale** | interfaccia web "carta e inchiostro": carbone caldo, crema, vermiglio, Fraunces — niente template generico |
| **App desktop** | wrapper **Electron** (macOS/Windows/Linux): un'icona avvia il backend, resta in tray come monitor sempre acceso |
| **Ops** | ingest incrementale, backoff sui siti irraggiungibili, run loop orario, systemd/launchd/startup per l'avvio al login, basic auth opzionale per l'accesso remoto |

## Come funziona

```
┌─────────────────────────── INGEST (ogni ora) ───────────────────────────┐
│                                                                          │
│  lista UST Milano ──► dettaglio MIM ──► soggetto dal titolo (veloce)     │
│  (PROVINCIA per    │            │                                        │
│   provincia)       │            ├──► Axios (home): classi, ore, scad.,   │
│                    │            │     comune, link candidatura           │
│                    │            └──► albo online scuola (VPS): soggetto  │
│                    │                 dal PDF dell'avviso                 │
│                    ▼                                                     │
│              SQLite (dedup su URL) ──► nuovi target ──► Telegram/email   │
│                                                                          │
│  SCAN scuole II grado (ogni ora, 138 siti)                               │
│   sezioni albo/interpello ─► voci recenti ─► PDF allegati ─► soggetto    │
│   ──► DB con fonte="SCUOLA"                                              │
└──────────────────────────────────────────────────────────────────────────┘
```

L'ingest è **incrementale**: gli avvisi già noti non vengono riscaricati; il
probe delle scuole gira a rate-limit (40/run) così il ciclo orario resta
leggero e la copertura si costruisce run dopo run.

## Le fonti, con i loro limiti

| Fonte | Fornisce | Affidabilità | Da VPS | Da casa |
|---|---|---|---|---|
| **Albo UST** (`mim.gov.it/web/milano/interpelli…`) | indice ufficiale completo: data, scuola, grado, link | ⭐⭐⭐ | ✅ | ✅ |
| **Titolo del dettaglio MIM** | soggetto per ~40% degli avvisi ("Interpello Infanzia Sostegno", "ADEE") | ⭐⭐⭐ | ✅ | ✅ |
| **Piattaforma Axios** (per avviso) | soggetto strutturato: classi, ore, periodo, scadenza, **candidatura** | ⭐⭐⭐ | ⚠️ Cloudflare 403 su IP datacenter | ✅ |
| **Albo online della scuola** | avviso PDF → soggetto per gli avvisi non dichiarati a livello MIM | ⭐⭐ | ✅ | ✅ |
| **Siti delle secondarie II** (scan) | interpelli pubblicati direttamente dalle scuole | ⭐⭐ | ✅ (dal datacenter ~60% di siti raggiungibili) | ✅ (più completa) |

> **Onestà tecnica**: il soggetto strutturato (classi di concorso, ore,
> scadenza, candidatura) richiede la piattaforma **Axios**, che dietro
> Cloudflare blocca gli IP datacenter ma **funziona da IP residenziale**.
> Da VPS il sistema resta completo come indice ma con soggetto *best-effort*:
> gli avvisi senza soggetto affidabile sono marcati **"da verificare"** con
> link a 1 tocco (10 secondi di controllo visivo). Il consiglio è di farla
> girare a casa.

## Installazione

### 🍺 Homebrew (macOS) — installer ufficiale

```bash
brew tap eliobenigni7/interpelly
brew install interpelly          # venv + dipendenze + comandi interpelly*

# monitor continuo come servizio launchd (avvio al login, sempre attivo):
brew services start interpelly

interpelly                       # dashboard su http://localhost:8000
interpelly-ingest                # ingest single-shot
interpelly-scan                  # scan delle secondarie II di Milano
```

Notifiche: crea `~/.interpelly.env` con `TG_TOKEN`/`TG_CHAT` (caricato
automaticamente da comandi e servizio). I dati stanno in
`$(brew --prefix)/var/lib/interpelly` (persistono agli aggiornamenti).

### ⚡ One-liner (macOS / Linux, senza brew)

```bash
curl -fsSL https://raw.githubusercontent.com/eliobenigni7/homebrew-interpelly/main/install.sh | bash
```

Scarica il tarball pubblico in `~/interpelly`, crea il venv con le dipendenze e
stampa i comandi per dashboard e monitor.

### 🥟 Bun (opzionale — più veloce per build/install del desktop)

```bash
cd desktop
bun install                      # ~4x più veloce di npm
bun run dist:mac                 # o dist:win / dist:linux
```

### Da sorgente (sviluppo)

```bash
git clone https://github.com/eliobenigni7/interpelly.git
cd interpelly
python3 -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

Requisiti: **Python 3.11+** e (solo per l'app desktop) **Node.js 18+** o **Bun**.

## Avvio rapido

```bash
# 1. (consigliato) imposta le notifiche Telegram
export TG_TOKEN="123456:ABC..." TG_CHAT="123456789"

# 2. primo ingest completo (in modalità home legge anche Axios):
python3 run_ingest.py --capture-sample

# 3. dashboard web:
python3 -m uvicorn web.app:app --host 0.0.0.0 --port 8000
#    → http://localhost:8000

# 4. monitoraggio continuo (ingest + scan + notifiche, ogni ora):
python3 run_loop.py --interval 1 --scan --notify
```

Alla porta 8000, `INTERPELLI_PROVINCES` e le credenziali notifiche si possono
passare anche con un file `.env` (vedi [Configurazione](#configurazione)).

## App desktop (Electron)

Un'icona → tutto acceso. Il desktop wrapper avvia da solo il backend FastAPI
come processo figlio, apre la dashboard in una finestra nativa e resta in
**tray** come monitor sempre acceso (chiudere la finestra non esce: si esce
dal menu di tray).

```bash
cd desktop
npm install
npm start                     # avvia l'app (backend incluso)
npm run dist:win              # .exe (NSIS + portable)
npm run dist:mac              # .dmg + .zip
npm run dist:linux            # AppImage
```

- `INTERPELLI_LOOP=1` avvia anche il loop orario (ingest+scan+notifiche) con l'app.
- Menu tray: *Apri la bacheca* / *Esegui ingest ora* / *Esci*.
- Quando l'app è **impacchettata** (`.app`/`.exe`), usa il checkout reale del
  progetto con il venv accanto (`~/interpelly` o la cartella del repo) —
  vedi `desktop/backend.js`.

## Docker / VPS

```bash
docker compose up -d --build
```

Il container `ingest` fa primo ingest + loop orario in **modalità VPS**
(`INTERPELLI_HOME=0`, Axios degradato); il container `web` serve la dashboard
su :8000 (basic auth opzionale con `DASHBOARD_USER`/`DASHBOARD_PASS`).
Volume condiviso `interpelly_data` per il DB. Su Coolify/Dokploy: importa la
repo, porta 8000, env come da compose.

## Guida per piattaforme

### macOS

```bash
brew install python@3.11 node
cd interpelly
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python3 run_ingest.py --capture-sample
cd desktop && npm install && npm start        # oppure npm run dist:mac
```

- **Avvio al login (GUI)**: Impostazioni di sistema → Utenti e gruppi →
  Elementi di login → aggiungi *Interpelly.app* (resta in tray).
- **Avvio al login (headless)**: `contrib/com.bacheca.interpelli.plist`
  (launchd — sostituisci `UTENTE`).
- **Gatekeeper** (app non firmata): tasto destro sull'app → *Apri*; oppure
  `codesign --deep --force --sign - dist/*.app`.

### Windows

```bash
# Python 3.11+ (python.org, "Add to PATH") e Node.js
cd interpelly
python -m venv .venv && .venv\Scripts\activate
pip install -r requirements.txt
python run_ingest.py --capture-sample
cd desktop && npm install && npm start        # oppure npm run dist:win
```

- **Avvio al login**: Win+R → `shell:startup` → scorciatoia dell'exe (tray)
  oppure di `contrib/avvio_bacheca_windows.bat` (loop headless).

### Linux (systemd)

```bash
mkdir -p ~/.config/systemd/user && cp contrib/interpelli.service ~/.config/systemd/user/
systemctl --user daemon-reload && systemctl --user enable --now interpelli.service
loginctl enable-linger $USER   # avvio al boot senza login
```

## Configurazione

Tutte le variabili sono opzionali; si possono passare come env o in un file `.env` (copia di esempio in `.env.example`).

| Variabile | Default | Descrizione |
|---|---|---|
| `INTERPELLI_HOME` | `1` | `1` = IP residenziale (Axios attivo) · `0` = VPS (Axios degradato) |
| `INTERPELLI_PROVINCES` | `MILANO` | province da monitorare: `MILANO,BERGAMO,BRESCIA,…` |
| `TG_TOKEN` / `TG_CHAT` | — | notifiche Telegram (bot token / chat id) |
| `SMTP_HOST` `SMTP_USER` `SMTP_PASS` `SMTP_TO` `SMTP_PORT` | — | digest email giornaliero |
| `DASHBOARD_USER` / `DASHBOARD_PASS` | — | basic auth per la dashboard (accesso remoto) |
| `AI_API_KEY` `AI_BASE_URL` `AI_MODEL` | — | estrazione AI/LLM degli avvisi — gestita anche dalla **pagina Impostazioni** dell'app (DB > env), con switch on/off e pulsante di test |
| `TESSERACT_CMD` `PDFTOTPM_CMD` | — | OCR per avvisi scansione (richiede poppler + tesseract) |
| `INTERPELLI_PORT` | `8000` | porta del backend (usata dall'app desktop) |
| `INTERPELLI_PYTHON` | auto | percorso esplicito del python per il desktop |
| `INTERPELLI_LOOP` | — | `1` = l'app desktop avvia anche il loop orario |

## CLI

| Comando | Cosa fa |
|---|---|
| `python3 run_ingest.py [--since-days 21] [--school-probe] [--probe-limit 40] [--refresh] [--notify] [--digest-email] [--capture-sample] [--provinces …]` | ingest single-shot (incrementale di default) |
| `python3 scan_scuole.py [--workers 6] [--limit N] [--rescan]` | scan dei siti delle secondarie II |
| `python3 run_watch.py [--interval 15] [--notify]` | fast-poll delle scuole in watchlist (⭐) |
| `python3 run_loop.py --interval 1 --scan --watch --notify` | ciclo orario continuo + fast-poll watchlist (PC casa) |
| `python3 check_health.py [--notify]` | heartbeat: esce 0 se sano, 1 se l'ingest è in affanno |
| `python3 -m uvicorn web.app:app --host 0.0.0.0 --port 8000` | dashboard web |
| `python3 scripts/build_school_directory.py` | rigenera `data/mi_sites.json` + `secondaria_milano.json` da Open Data MIM (a settembre, auto) |

## API

| Endpoint | Descrizione |
|---|---|
| `GET /` | dashboard |
| `GET /api/stats` | conteggi (soggetto, scadenze, comuni, axios) |
| `GET /api/interpelli?subject=&q=&comune=&tipo=&fonte=&urgent_days=&watch=&date_from=&date_to=&days=` | lista filtrata |
| `GET /api/draft?detail_url=&fmt=html\|txt` | **bozza di domanda** per un avviso (stampabile → "Salva come PDF") |
| `POST /api/interpelli/candidato` | marca un avviso come *candidata ✓* |
| `GET/POST /api/profile` | profilo candidata (per la bozza) |
| `GET /api/health` | heartbeat dell'ingest |
| `GET/POST /api/settings` · `POST /api/settings/test` | impostazioni AI (chiave mascherata, test connessione, on/off) |
| `GET /api/comuni` | top comuni |
| `GET /api/trend` | andamento mensile per soggetto |
| `GET /api/export.csv` | export con gli stessi filtri |
| `GET /api/scan` | stato dello scan delle secondarie II |
| `GET /api/schools` | scuole con sito risolto |
| `GET /api/watchlist` · `POST /api/watchlist` | scuole seguite / toggle ⭐ |

## Scan delle scuole secondarie di II grado

Oltre all'indice UST, Interpelly **scansiona i siti istituzionali di tutte le
scuole secondarie di II grado di Milano** (250 scuole → 138 siti unici, elenco
da Open Data MIM) alla ricerca di interpelli pubblicati direttamente dalle
scuole — spesso prima o oltre l'albo UST. Le voci trovate entrano nel DB con
`fonte=SCUOLA` e sono distinguibili in dashboard/export.

Meccanica (`ingest/scuole_scan.py`): probe delle sezioni canoniche
(albo online, `argomento/interpello/`, novità…) + sezioni esplicite dal menu →
estrazione voci recenti con filtri anti-navigazione → classificazione dal
titolo e dal **PDF allegato** → registro per sito nella tabella `scans` con
**backoff 24h** sui siti irraggiungibili.

## Notifiche

**Telegram** — un messaggio per ogni nuovo interpello target, con pulsanti:

```
⭐ IC Schweitzer - SEGRATE
· sostegno · 2026-06-17
· classi: ADEE · ore: 24
· scade: 2026-08-20 · SEGRATE
[ ✍ Candidatura ] [ Albo UST ] [ Avviso ]
```

**Digest email** (opzionale, `--digest-email`): ogni notte riepilogo delle
novità del giorno + interpelli in scadenza entro 48h.

## Struttura del progetto

```
interpelly/
├── ingest/
│   ├── mim.py            # crawler indice + dettaglio UST MIM
│   ├── axios.py          # parser piattaforma Axios (classi, ore, scadenza, candidatura)
│   ├── subjects.py       # classificatore soggetto (francese/sostegno) + testo PDF
│   ├── schools.py        # directory scuola→sito (Open Data) + probe albo
│   ├── scuole_scan.py    # scan delle secondarie II (siti istituzionali)
│   ├── enrich.py         # comune/tipo/classi derivati dai dati
│   ├── store.py          # SQLite (migrazione automatica, dedup)
│   ├── notify.py         # Telegram HTML + digest email
│   └── config.py         # province, target, modalità home/vps, watchlist
├── web/
│   ├── app.py            # FastAPI: API + dashboard + export + watchlist + scan status
│   └── static/           # frontend editoriale (carbone/crema/vermiglio)
├── desktop/              # wrapper Electron (main.js, backend.js, icone, package.json)
├── scripts/build_school_directory.py
├── contrib/              # systemd unit · launchd plist · autostart Windows
├── data/                 # mi_sites.json · secondaria_milano.json · interpelli.db (generato)
├── run_ingest.py · run_loop.py · scan_scuole.py
├── Dockerfile · docker-compose.yml
└── README.md
```

## Persistenza

SQLite (`data/interpelli.db`), dedup su URL del dettaglio:

- `interpelli` — ogni avviso: data, provincia, comune, scuola, grado, soggetto,
  classi di concorso, ore, periodo, scadenza, link candidatura, fonte (MIM /
  Axios / SCUOLA), watch
- `schools` — risoluzione sito + watchlist ⭐
- `scans` — stato per sito dello scan secondarie II

## Studio miglioramenti e roadmap

`docs/IMPROVEMENTS.md` contiene l'analisi basata su evidenze reali (dati del
sistema in funzione) e la roadmap con priorità: estrattore **AI/LLM** e OCR,
**test+CI**, reminder scadenze, watchlist fast-poll, merge duplicati, profilo
candidata, PWA…

## Estendere

- **Altre province**: `INTERPELLI_PROVINCES="MILANO,BRESCIA"`; per regioni fuori
  Lombardia aggiungi l'URL in `ingest/config.py::UST_LIST`.
- **Nuove classi di concorso**: aggiungi voci in `ingest/config.py::CLASSE_MAP`
  e token in `ingest/subjects.py`.
- **Calibrazione Axios**: `run_ingest.py --capture-sample` salva l'HTML in
  `data/samples/`; se qualche campo non si estrae sulla tua provincia, apri una
  issue con il sample e i selettori vengono rifiniti in `ingest/axios.py`.
- **Canali aggiuntivi**: `ingest/notify.py` è modulare (webhook, Matrix…).

## Limiti noti e onestà tecnica

- **Calendario**: gli interpelli si fermano a giugno e ripartono a
  settembre/ottobre; a giugno–agosto il DB resta quasi fermo (normale).
- **Axios da VPS**: Cloudflare 403 su IP datacenter → il soggetto strutturato
  richiede la modalità home. Da VPS aumenta la quota "da verificare".
- **Classificazione inclusiva**: se l'avviso cita "sostegno" viene marcato
  sostegno; verifica sempre l'avviso prima di candidarti. Con Axios la
  classificazione usa le classi di concorso (più precisa).
- **Siti irraggiungibili**: dal datacenter ~40% dei siti delle secondarie II
  risultano irraggiungibili; da IP residenziale la copertura è migliore
  (backoff 24h li ritenta).
- **Directory scuole**: deriva da Open Data MIM; alcuni domini sono obsoleti
  o malformati — il resolver li normalizza e deriva `.edu.it` dai `.gov.it`.

## Etica e legalità

Interpelly legge **pagine pubbliche di una PA** (albi online, portali ufficiali)
per uso personale di ricerca lavoro, con **rate-limit** e senza aggirare
protezioni: se Cloudflare blocca l'accesso, l'avviso resta raggiungibile
dall'albo della scuola e dal link UST. Non vengono bypassate misure di
sicurezza né raccolti dati personali oltre gli avvisi pubblici.

## FAQ

- **Serve essere in graduatoria?** Interpelly trova gli avvisi e ti porta al
  link di candidatura: i requisiti di ammissione (GPS/GI, specializzazione,
  requisiti della classe di concorso) sono dichiarati in ogni avviso.
- **Perché non vedo nulla ad agosto?** Gli interpelli seguono l'anno
  scolastico: il volume riparte a settembre.
- **Posso aggiungere il liceo di un'altra città?** Sì: mettilo in watchlist ⭐
  oppure estendi la provincia (vedi [Estendere](#estendere)).
- **Funziona anche per ATA?** Lo scan dei siti e l'indice UST includono anche
  gli avvisi per personale ATA: i filtri soggetto li classificano come "altro"
  (o "da verificare"); la classi di concorso ATA si aggiungono in `CLASSE_MAP`.

## Roadmap

- [x] Indice UST + soggetto da titolo MIM
- [x] Axios strutturato (classi, ore, scadenza, candidatura) — modalità home
- [x] Multi-provincia lombarda · scan secondarie II · watchlist · scadenze
- [x] Filtri avanzati (date, comune, grado, fonte) · export CSV · trend
- [x] Telegram + digest email · desktop Electron (mac/win/linux) · Docker
- [ ] Calibrazione finale parser Axios sui campioni reali delle province
- [ ] Firma/notarizzazione app desktop (macOS notarization, Windows signing)
- [ ] Interpelli ATA dedicati · push web · dashboard multilingua

## Licenza

Uso personale e non commerciale — vedi [LICENSE](LICENSE).

---

<div align="center">

*Fatto con carta, inchiostro e un punto di vermiglio — per chi entra in classe.*

</div>