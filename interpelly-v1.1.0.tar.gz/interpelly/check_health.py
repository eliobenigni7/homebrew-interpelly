"""
check_health.py — Heartbeat di Interpelly.

Esce 0 se l'ingest è sano, 1 se è in ritardo o ha troppi fallimenti consecutivi.
Da schedulare (cron/UptimeRobot/ping esterno). Con --notify invia un alert
Telegram (una volta al giorno al massimo, dedup su meta).

Uso:
  python3 check_health.py [--max-age-hours 26] [--max-failures 3] [--notify]
"""

from __future__ import annotations

import argparse
import sys
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from ingest.store import Store  # noqa: E402
from ingest import notify  # noqa: E402

DB = ROOT / "data" / "interpelli.db"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--max-age-hours", type=int, default=26)
    ap.add_argument("--max-failures", type=int, default=3)
    ap.add_argument("--notify", action="store_true")
    args = ap.parse_args()

    store = Store(DB)
    st = store.health(max_age_hours=args.max_age_hours,
                      max_failures=args.max_failures)
    print(f"ok={st['ok']} | last_ingest={st['last_ingest'] or '—'} "
          f"| age_hours={st['age_hours']} | failures={st['failures']}")

    if not st["ok"] and args.notify:
        today = date.today().isoformat()
        if store.get_meta("health_alert_date") != today:
            text = ("⚠️ *Interpelly — ingest in affanno*\n"
                    f"· ultimo riuscito: {st['last_ingest'] or 'mai'}\n"
                    f"· età: {st['age_hours']}h\n· fallimenti consecutivi: {st['failures']}")
            code = notify.telegram_send(text, None)
            if code == 200:
                store.set_meta("health_alert_date", today)
                print("  → alert Telegram inviato")
    store.close()
    return 0 if st["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())