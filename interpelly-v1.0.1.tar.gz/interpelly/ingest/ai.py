"""
ai.py — Estrazione intelligente degli avvisi (opzionale).

Usa un'API compatibile OpenAI (OpenRouter, Gemini, Ollama locale…) per
estrarre da un testo di avviso: subject (francese/sostegno/altro), classi di
concorso, ore, periodo, scadenza (ISO), comune e tipo scuola.

Attivo SOLO se AI_API_KEY è presente (o AI_BASE_URL punta a un server locale
senza chiave). Ogni errore degrada silenziosamente a {}.

Env:
  AI_API_KEY        chiave API (es. OpenRouter)
  AI_BASE_URL       default https://openrouter.ai/api/v1
  AI_MODEL          default openrouter/auto (o gemini-2.0-flash, llama3.1…)
  TESSERACT_CMD     percorso di tesseract (per OCR scansioni) — opzionale
  PDFTOTPM_CMD      percorso di pdftoppm (poppler) — opzionale, serve all'OCR
"""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import tempfile
from pathlib import Path

import requests

PROMPT = """Sei un parser di avvisi di interpello scolastico italiani.
Dal testo sotto estrai e rispondi SOLO con JSON valido con queste chiavi:
- "subject": "francese" | "sostegno" | "altro" | null   (materia/ruolo cercato)
- "classi": [stringhe, es. "A24, AA24, ADEE"]
- "ore": stringa ore settimanali o null
- "periodo": stringa periodo contratto o null
- "scadenza": data in formato ISO (YYYY-MM-DD) o null
- "comune": comune della scuola se indicato, altrimenti null
- "tipo_scuola": "infanzia" | "primaria" | "secondaria_i" | "secondaria_ii" | null
Non inventare campi che non ci sono: null se assenti.

TESTO AVVISO:
----
{text}
----"""


def _model() -> str:
    return os.environ.get("AI_MODEL", "openrouter/auto")


def _base_url() -> str:
    return os.environ.get("AI_BASE_URL", "https://openrouter.ai/api/v1").rstrip("/")


def _configured() -> bool:
    if os.environ.get("AI_BASE_URL") and not os.environ.get("AI_API_KEY"):
        return True  # server locale (Ollama ecc.) senza chiave
    return bool(os.environ.get("AI_API_KEY"))


def _call(text: str) -> dict:
    url = f"{_base_url()}/chat/completions"
    headers = {"Content-Type": "application/json"}
    if os.environ.get("AI_API_KEY"):
        headers["Authorization"] = f"Bearer {os.environ['AI_API_KEY']}"
    payload = {
        "model": _model(),
        "messages": [
            {"role": "system", "content": "Sei un estrattore di dati. Rispondi solo JSON."},
            {"role": "user", "content": PROMPT.format(text=text[:8000])},
        ],
        "temperature": 0,
    }
    r = requests.post(url, json=payload, headers=headers, timeout=60)
    r.raise_for_status()
    content = r.json()["choices"][0]["message"]["content"]
    content = re.sub(r"^```(?:json)?|```$", "", content.strip(), flags=re.M)
    data = json.loads(content)
    return data if isinstance(data, dict) else {}


def ocr_pdf(pdf_bytes: bytes) -> str:
    """OCR di un PDF scansione via pdftoppm + tesseract (entrambi opzionali)."""
    tesseract = os.environ.get("TESSERACT_CMD") or shutil.which("tesseract")
    pdftoppm = os.environ.get("PDFTOTPM_CMD") or shutil.which("pdftoppm")
    if not (tesseract and pdftoppm):
        return ""
    with tempfile.TemporaryDirectory() as td:
        pdf = Path(td) / "avviso.pdf"
        pdf.write_bytes(pdf_bytes)
        try:
            subprocess.run([pdftoppm, "-png", "-r", "200", str(pdf), str(Path(td) / "pg")],
                           check=True, capture_output=True, timeout=90)
        except (subprocess.CalledProcessError, FileNotFoundError, subprocess.TimeoutExpired):
            return ""
        pages = sorted(Path(td).glob("pg-*.png"))[:10]
        out = []
        for p in pages:
            try:
                r = subprocess.run([tesseract, str(p), "-", "-l", "ita", "--psm", "6"],
                                   check=True, capture_output=True, timeout=60)
                out.append(r.stdout.decode("utf-8", "ignore"))
            except (subprocess.CalledProcessError, FileNotFoundError, subprocess.TimeoutExpired):
                continue
        return "\n".join(out)


def extract(text: str, pdf_bytes: bytes | None = None) -> dict:
    """Estrae i campi da testo (e PDF, con OCR se serve). {} se non configurato."""
    if not _configured():
        return {}
    if pdf_bytes:
        plain = pdf_text_placeholder = ""
        # tenta prima il testo nativo del PDF, poi OCR (non blocca mai)
        try:
            from pypdf import PdfReader
            import io as _io
            plain = "\n".join((p.extract_text() or "") for p in
                              PdfReader(_io.BytesIO(pdf_bytes)).pages[:10])
        except Exception:
            plain = ""
        if not plain.strip():
            plain = ocr_pdf(pdf_bytes)
        text = f"{text}\n---PDF---\n{plain[:6000]}"
    try:
        return _call(text)
    except Exception:
        return {}