"""
enrich.py — Arricchimento derivato dai dati MIM/Axios:
comune, tipo scuola e classi di concorso a partire da nome/grado/testo.
"""

from __future__ import annotations

import re

from .config import TIPO_NORM
from .axios import CLASSE_RE

_CITY_TOKENS = {"IC", "IS", "IIS", "IT", "ISTITUTO", "COMPRENSIVO", "SCUOLA",
                "STATALE", "SUPERIORE", "IPSIA", "IPSEOA", "CPIA", "MI",
                "LICEO", "TECNICO", "PROFESSIONALE", "DI", "VIA", "DEI", "DELLE",
                "S.PELLICO", "MIIC", "MIIS", "MIMM", "E", "DON", "PADRE",
                "AI", "NOSTRI", "CADUTI"}


def comune_from_name(school: str) -> str:
    """Estrae il comune dal nome MIM: '- SEGRATE', '- MILANO', '- SAN DONATO
    MILANESE', oppure da codici 'MIIC860003 - S.PELLICO-ARLUNO' etc."""
    s = school.strip()
    m = re.search(r"\s-\s+([^\-]+)$", s)
    if m:
        tok = m.group(1).strip()
        # parti in maiuscolo iniziali (evita "IC Schweitzer - SEGRATE" ok,
        # ma anche "CPIA2 Nord Est Milano - CINISELLO BALSAMO")
        words = [w for w in tok.split() if w.isupper() or w[0].isupper()]
        if words:
            # codice meccanografico: "MIIC860003 - S.PELLICO-ARLUNO" -> ARLUNO
            if "." in tok:
                return re.split(r"[-\s]+", tok)[-1]
            return " ".join(words).strip()
    # pattern "ISTITUTO COMPRENSIVO DI VILLA CORTESE" (no dash)
    m = re.search(r"\bVILLA\s+CORTESE\b", s, re.I) or re.search(r"\bTRUCCAZZANO\b", s, re.I)
    if m:
        return m.group(0).upper()
    # ultimo token dopo il codice
    m = re.match(r"^[A-Z]{2}[A-Z0-9]{6,8}\s*[-–]\s*(.+)$", s.strip())
    if m:
        tail = m.group(1).strip()
        words = re.split(r"[-\s]+", tail)
        if words and words[-1].isupper():
            return words[-1]
    return ""


def tipo_from_grade(grade: str, extras: str = "") -> str:
    """Normalizza il tipo scuola da grado MIM / testo Axios."""
    blob = f"{grade} {extras}".lower()
    for key, val in TIPO_NORM.items():
        if key in blob:
            return val
    # euristiche
    if re.search(r"\bprimaria\b|\belementare\b", blob):
        return "primaria"
    if re.search(r"\bsecondaria di [i1]|i grado|secondaria i", blob):
        return "secondaria_i"
    if re.search(r"\bsecondaria di [i2]|ii grado|secondaria [i2]", blob):
        return "secondaria_ii"
    return ""


def classi_from_text(text: str) -> list[str]:
    seen: list[str] = []
    for m in CLASSE_RE.finditer(text):
        c = m.group(1).upper()
        if c not in seen:
            seen.append(c)
    return seen


def subject_from_classi(classi: list[str]) -> str | None:
    """Se le classi di concorso dichiarano il soggetto, usalo (più preciso
    del testo libero)."""
    from .config import CLASSE_MAP
    for c in classi:
        subj = CLASSE_MAP.get(c)
        if subj in ("francese", "sostegno"):
            return subj
    return None


# --- Estrazione struttura da qualunque testo avviso (regex, locali) ----------

def _norm_date(s: str) -> str:
    from datetime import datetime
    s = s.strip()
    for fmt in ("%d/%m/%Y", "%d-%m-%Y", "%d/%m/%y", "%Y-%m-%d"):
        try:
            return datetime.strptime(s, fmt).date().isoformat()
        except ValueError:
            continue
    m = re.search(r"(\d{1,2})\s+([a-zàèéìòù]+)\s+(\d{4})", s.lower())
    if m:
        months = {mm: i + 1 for i, mm in enumerate(
            ["gennaio", "febbraio", "marzo", "aprile", "maggio", "giugno", "luglio",
             "agosto", "settembre", "ottobre", "novembre", "dicembre"])}
        if m.group(2) in months:
            try:
                return datetime(int(m.group(3)), months[m.group(2)], int(m.group(1))).date().isoformat()
            except ValueError:
                pass
    return ""


def extract_fields(text: str) -> dict:
    """Estrae {classi, ore, periodo, scadenza, comune, tipo_scuola} da un testo
    avviso generico (riusa le stesse euristiche del parser Axios)."""
    out = {"classi": classi_from_text(text), "ore": "", "periodo": "",
           "scadenza": "", "comune": "", "tipo_scuola": ""}
    m = re.search(r"(?:(\d{1,3}(?:[,.]\d)?)\s*ore|ore\s+(?:settimanali\s+)?(\d{1,3}(?:[,.]\d)?))",
                  text, re.I)
    if m:
        out["ore"] = (m.group(1) or m.group(2)).replace(",", ".")
    m = re.search(r"(?:dal|dalle)\s+([\d/.\-]+)\s*(?:al|alle|fino al)\s*([\d/.\-]+)",
                  text, re.I)
    if m:
        out["periodo"] = m.group(0).strip()[:80]
    for m in re.finditer(
            r"(?:scadenza|entro|termine)\s*(?:candidatur[ae])?\s*[:.]?\s*"
            r"([\d/.\-]+|\d{1,2}\s+[a-zàèéìòù]+\s+\d{4})", text, re.I):
        d = _norm_date(m.group(1))
        if d:
            out["scadenza"] = d
            break
    m = re.search(r"comune\s+(?:di\s+)?([A-ZÀ-Ü][A-Za-zÀ-ÿ'’ -]{3,30})", text, re.I)
    if m and not re.search(r"(scuola|istituto|docente)", m.group(1), re.I):
        out["comune"] = m.group(1).strip()
    for key, val in TIPO_NORM.items():
        if key in text.lower():
            out["tipo_scuola"] = val
            break
    return out