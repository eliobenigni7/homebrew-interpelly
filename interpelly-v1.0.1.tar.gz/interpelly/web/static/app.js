/* app.js — La bacheca del supplente v2 */
"use strict";

const state = {
  subject: "",
  q: "",
  comune: "",
  tipo: "",
  fonte: "",
  dateFrom: "",
  dateTo: "",
  urgent: false,
  all: [],
  comuni: [],
};

const $ = (s) => document.querySelector(s);
const esc = (s) =>
  String(s ?? "").replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

/* ---------- helpers ---------- */
function fmtDate(iso) {
  if (!iso) return "—";
  const d = new Date(iso);
  if (isNaN(d)) return iso.slice(0, 10);
  return d.toLocaleDateString("it-IT", { day: "2-digit", month: "short" }).replace(".", "");
}
function isUrgent(r) {
  if (!r.scadenza_iso) return false;
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const scad = new Date(r.scadenza_iso + "T00:00:00");
  const diff = (scad - today) / 86400000;
  return diff >= 0 && diff <= 2;
}
function subjectLabel(s) {
  return { sostegno: "sostegno", francese: "francese", da_verificare: "da verificare", altro: "altro" }[s] || "—";
}

async function api(path, opts) {
  const r = await fetch(path, opts);
  if (!r.ok) throw new Error(path);
  return await r.json();
}

/* ---------- render: ledger ---------- */
function renderLedger() {
  const total = state.all.length;
  const n = (s) => state.all.filter((r) => r.subject === s).length;
  $("#led-total").textContent = total;
  $("#led-sostegno").textContent = n("sostegno");
  $("#led-francese").textContent = n("francese");
  const dates = state.all.map((r) => r.date_iso).filter(Boolean).sort().reverse();
  $("#led-last").textContent = fmtDate(dates[0]) + " " + (dates[0] || "").slice(0, 4);
}

/* ---------- render: comuni chips ---------- */
function renderComuni() {
  const box = $("#comuni");
  box.innerHTML = "";
  state.comuni.slice(0, 10).forEach((c) => {
    const b = document.createElement("button");
    b.className = "chip" + (state.comune === c.comune ? " on" : "");
    b.textContent = `${c.comune} (${c.c})`;
    b.addEventListener("click", () => {
      state.comune = state.comune === c.comune ? "" : c.comune;
      renderComuni();
      render();
    });
    box.appendChild(b);
  });
}

/* ---------- render: trend ---------- */
function renderTrend() {
  const box = $("#trend-bars");
  box.innerHTML = "";
  const data = state.trend || [];
  const totals = data.map((d) => d.c);
  const max = Math.max(1, ...totals);
  data.forEach((d) => {
    const col = document.createElement("div");
    col.className = "trend-bar";
    const h = (d.c / max) * 100;
    const cls = { sostegno: "sostegno", francese: "francese", altro: "altro", da_verificare: "daverif" }[d.subject] || "altro";
    const seg = document.createElement("div");
    seg.className = `seg ${cls}`;
    seg.style.height = h + "%";
    seg.title = `${d.ym} · ${d.subject}: ${d.c}`;
    col.appendChild(seg);
    box.appendChild(col);
  });
}

/* ---------- render: entries ---------- */
function render() {
  let rows = state.all;
  if (state.subject) rows = rows.filter((r) => r.subject === state.subject);
  if (state.tipo) rows = rows.filter((r) => r.tipo_scuola === state.tipo);
  if (state.fonte) rows = rows.filter((r) => r.fonte === state.fonte);
  if (state.comune) rows = rows.filter((r) => (r.comune || "").toLowerCase().includes(state.comune.toLowerCase()));
  if (state.urgent) rows = rows.filter(isUrgent);
  if (state.dateFrom || state.dateTo) {
    rows = rows.filter((r) => {
      const d = (r.date_iso || "").slice(0, 10);
      if (!d) return false;
      if (state.dateFrom && d < state.dateFrom) return false;
      if (state.dateTo && d > state.dateTo) return false;
      return true;
    });
  }
  if (state.q) {
    const q = state.q.toLowerCase();
    rows = rows.filter((r) =>
      (r.school || "").toLowerCase().includes(q) ||
      (r.grade || "").toLowerCase().includes(q) ||
      (r.comune || "").toLowerCase().includes(q));
  }

  const list = $("#list");
  if (!rows.length) {
    list.innerHTML = `<div class="empty">Nessun avviso per questi filtri.</div>`;
    return;
  }

  list.innerHTML = rows.map((r) => {
    const subj = r.subject;
    const tag =
      subj === "sostegno" ? `<span class="tag sostegno">sostegno</span>` :
      subj === "francese" ? `<span class="tag francese">francese</span>` :
      subj === "da_verificare" ? `<span class="tag check">da verificare</span>` :
      `<span class="tag">altro</span>`;
    const urg = isUrgent(r) ? `<span class="badge-urgent">scade ${fmtDate(r.scadenza_iso)}</span>` : "";
    const srcTag = r.fonte === "SCUOLA" ? `<span class="tag">sito scuola</span>` :
                   r.fonte === "Axios" ? `<span class="tag">interpello</span>` : "";
    const cls = subj === "francese" || subj === "sostegno" ? "" : "other";
    const w = (r.watched ? "on" : "off");
    const star = `<button class="star ${w}" data-school="${esc(r.school)}" title="segui la scuola">☆</button>`;

    let details = "";
    const bits = [];
    if (r.classi_concorso && r.classi_concorso.length) bits.push(`<b>classi</b> ${esc(r.classi_concorso.join(", "))}`);
    if (r.ore) bits.push(`<b>ore</b> ${esc(r.ore)}`);
    if (r.periodo) bits.push(`<b>periodo</b> ${esc(r.periodo)}`);
    if (r.tipo_scuola) bits.push(`<b>grado</b> ${esc(r.tipo_scuola)}`);
    if (r.comune) bits.push(`<b>comune</b> ${esc(r.comune)}`);
    if (r.provincia && r.provincia !== "MILANO") bits.push(`<b>prov.</b> ${esc(r.provincia)}`);
    if (r.scadenza_iso) bits.push(`<b class="scad">scadenza</b> <span class="scad">${esc(r.scadenza_iso)}</span>`);
    if (bits.length) details = `<div class="entry-detail"><div class="detail-row">${bits.join("<span class=\"sep\">·</span>")}</div></div>`;

    const links = [];
    if (r.link_candidatura) links.push(`<a href="${esc(r.link_candidatura)}" target="_blank" rel="noopener">✍ candidatura ↗</a>`);
    links.push(`<a href="${esc(r.detail_url)}" target="_blank" rel="noopener">albo UST ↗</a>`);
    if (r.axios_url) links.push(`<a href="${esc(r.axios_url)}" target="_blank" rel="noopener">avviso interpello ↗</a>`);
    if (r.school_domain) links.push(`<a href="${esc(r.school_domain)}" target="_blank" rel="noopener">sito scuola ↗</a>`);
    const linksHtml = `<div class="detail-links">${links.join("")}</div>`;

    return `<article class="entry ${cls}">
      <div class="entry-date">${fmtDate(r.date_iso)}${r.provincia && r.provincia !== "MILANO" ? `<br><span class="entry-count">${esc(r.provincia)}</span>` : ""}</div>
      <div class="entry-body">
        <h2 class="entry-school">${star}<a href="${esc(r.detail_url)}" target="_blank" rel="noopener">${esc(r.school)}</a></h2>
        <div class="entry-meta">${tag}${srcTag}${urg}${r.grade ? `<span class="entry-grade">${esc(r.grade.length > 42 ? r.grade.slice(0, 42) + "…" : r.grade)}</span>` : ""}</div>
        ${details}
        ${linksHtml}
      </div>
      <div class="entry-actions"></div>
    </article>`;
  }).join("");

  bindEntryEvents();
}

function bindEntryEvents() {
  /* expand/collapse detail */
  document.querySelectorAll(".entry .entry-body").forEach((b) => {
    b.addEventListener("click", (e) => {
      if (e.target.closest("a") || e.target.closest(".star")) return;
      b.closest(".entry").classList.toggle("open");
    });
  });
  /* watch star */
  document.querySelectorAll(".star").forEach((s) => {
    s.addEventListener("click", async (e) => {
      e.stopPropagation();
      const school = s.dataset.school;
      const on = s.classList.contains("off");
      await api("/api/watchlist", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ school, on }),
      });
      state.all.forEach((r) => { if (r.school === school) r.watched = on; });
      render();
    });
  });
}

/* ---------- data ---------- */
async function load(full = false) {
  try {
    const [rows, stats, com, trend, scan] = await Promise.all([
      api("/api/interpelli?days=120"),
      api("/api/stats"),
      api("/api/comuni"),
      api("/api/trend"),
      api("/api/scan"),
    ]);
    if (scan && scan.scanned) {
      $("#led-scan").textContent =
        `scan scuole II gdo: ${scan.ok}/${scan.scanned} siti · ${scan.interpelli_trovati} trovati`;
    }
    const schools = await api("/api/schools");
    const map = new Map(schools.map((s) => [s.name, s.domain]));
    rows.forEach((r) => { r.school_domain = map.get(r.school) || ""; });
    state.all = rows;
    state.comuni = com;
    state.trend = trend;
    renderLedger();
    renderComuni();
    renderTrend();
    render();
  } catch (e) {
    $("#list").innerHTML = `<div class="empty">Albo non raggiungibile — <strong>riprova tra poco</strong>.</div>`;
  }
}

/* ---------- events ---------- */
document.querySelectorAll(".f-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".f-btn").forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    state.subject = btn.dataset.subject;
    render();
  });
});
$("#urgent").addEventListener("change", (e) => { state.urgent = e.target.checked; render(); });
$("#tipo").addEventListener("change", (e) => { state.tipo = e.target.value; render(); });
$("#fonte").addEventListener("change", (e) => { state.fonte = e.target.value; render(); });
$("#date-from").addEventListener("change", (e) => { state.dateFrom = e.target.value || ""; render(); });
$("#date-to").addEventListener("change", (e) => { state.dateTo = e.target.value || ""; render(); });
$("#date-clear").addEventListener("click", () => {
  state.dateFrom = state.dateTo = "";
  $("#date-from").value = $("#date-to").value = "";
  render();
});
$("#export-btn").addEventListener("click", () => {
  const p = new URLSearchParams();
  if (state.subject) p.set("subject", state.subject);
  if (state.comune) p.set("comune", state.comune);
  if (state.tipo) p.set("tipo", state.tipo);
  if (state.fonte) p.set("fonte", state.fonte);
  if (state.dateFrom) p.set("date_from", state.dateFrom);
  if (state.dateTo) p.set("date_to", state.dateTo);
  if (state.urgent) p.set("urgent_days", "2");
  if (state.q) p.set("q", state.q);
  window.location.href = "/api/export.csv?" + p.toString();
});
let debounce;
$("#q").addEventListener("input", (e) => {
  clearTimeout(debounce);
  debounce = setTimeout(() => { state.q = e.target.value.trim(); render(); }, 180);
});

load();
setInterval(() => load(true), 5 * 60 * 1000);  /* auto-aggiornamento silenzioso */