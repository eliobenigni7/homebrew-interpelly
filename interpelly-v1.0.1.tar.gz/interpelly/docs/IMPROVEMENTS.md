# Migliorare Interpelly — studio

Analisi basata su **evidenze reali** raccolte dal sistema in funzione
(402 avvisi in DB, scan di 138 siti eseguito, parser testati).

## 1. Evidenze dal campo

| Metrica | Valore attuale | Lettura |
|---|---|---|
| Avvisi totali | 402 | indice UST + scan scuole |
| **Soggetto "da verificare"** | **374 (93%)** | il classificatore da solo titolo MIM non basta → l'estrattore AI/OCR è la priorità n.1 |
| Soggetto affidabile | 28 (26 sostegno + 2 francese) | sotto-stima: molti dei 374 sono realmente di sostegno ma non dichiarati nel titolo |
| Con scadenza / link candidatura | **0 / 0** (in questo ambiente VPS) | Axios bloccato da Cloudflare: i dati strutturati compaiono solo in modalità **home** (Mac) |
| Con classi di concorso | 19 | solo dai titoli MIM |
| Con comune | 194 (48%) | buono: deriva dal nome scuola |
| Duplicati scuola+data tra fonti | presenti | stesso avviso via UST e via sito scuola → va normalizzato |
| Scan secondarie II | 138 siti, 81 raggiungibili, 2 trovati | d'estate il segnale è scarso; da IP residenziale la copertura sale |

**Problema centrale**: la qualità del soggetto dipende da Axios (home) e dal
titolo MIM (VPS). Gli avvisi veri (PDF delle scuole) spesso non vengono letti
perché sono **scansioni** (niente testo estraibile) o perché classificarli
richiede capire la lingua burocratica.

## 2. Priorità (impatto × sforzo)

### P0 — subito (implementati in questo studio)

1. **Estrattore AI/LLM degli avvisi** (opzionale, API OpenAI-compatible):
   dato il testo dell'avviso (PDF/sito), estrae `subject`, `classi`, `ore`,
   `periodo`, `scadenza`, `comune`, `tipo` in JSON. Attivo solo se
   `AI_API_KEY` è presente; degrada silenziosamente. Può usare OpenRouter,
   Gemini, un'istanza Ollama locale (nessun dato va nel cloud se non vuoi).
   - Impatto: il 93% "da verificare" scende drasticamente (in home).
   - OCR opzionale (pdftoppm + tesseract) per le scansioni: `TESSERACT_CMD`.

2. **Regole locali più ricche**: riuso delle regex Axios (scadenza, ore,
   periodo, classi) su qualunque testo disponibile, non solo sulla pagina
   Axios → anche su VPS si recupera più struttura.

### P1 — molto utili

3. **Test automatici + CI** (pytest + GitHub Actions): il progetto ha zero
   test; i regressi sono costosi perché silenziosi.
4. **Reminder scadenza 24h** via Telegram (una volta al giorno, dedup su meta).
5. **Watchlist fast-poll**: le scuole ⭐ vengono interrogate ogni 15 minuti
   (non ogni ora) — per i posti che scadono in 24–48h la velocità è tutto.
6. **Merge dei duplicati** scuola+data tra fonti UST e sito scuola (un solo
   record con entrambi i link).

### P2 — più avanti

7. **Mobile/PWA**: la dashboard è già responsive; un manifest +
   installabilità rende il telefono di lei il primo posto dove guardare.
8. **Profilo candidata**: nome, titoli, requisiti salvati → bozza automatica
   della domanda (testo + PDF) per ogni interpello target. È il prossimo
   salto di valore ("candidati in 1 minuto").
9. **Normalizzazione nomi scuola** (MIIC860003 - S.PELLICO-ARLUNO ↔
   I.C. Pellico Arluno) per dedup e leggibilità.
10. **Altre regioni**: l'architettura è multi-UST; basta aggiungere le pagine
    USR delle altre regioni in `config.py`.
11. **Heartbeat/monitor**: alert se l'ingest fallisce N volte di fila o se,
    in anno scolastico, non arriva nulla da X giorni (webhook/ping esterno).
12. **Refresh annuale dei dataset** (directory scuole, elenco secondarie II):
    script già esistente, da schedulare a settembre.

## 3. Cosa è stato implementato qui

- [x] `ingest/ai.py` — estrattore LLM opzionale (OpenRouter/Gemini/Ollama) + OCR opzionale
- [x] `ingest/enrich.py::extract_fields` — regex scadenza/ore/periodo su qualsiasi testo
- [x] `tests/` — pytest: classificatore, parser Axios, enrich, store
- [x] `.github/workflows/ci.yml` — pytest (python) + node --check (desktop)
- [x] Reminder scadenza 24h in `notify.py` (degradato: screening via meta)

Il resto (5–12) è pronto per essere preso in ordine: dillo e lo faccio.