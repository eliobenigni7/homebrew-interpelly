"""
run_loop.py — Runner locale del monitoraggio interpelli.

Pensato per il PC personale: esegue l'ingest ogni N ore (default 1h) in loop
fino a Ctrl+C, loggando su data/ingest.log. Cross-platform (Windows/macOS/Linux).

Uso:
  python3 run_loop.py --interval 1 --school-probe --probe-limit 40
  python3 run_loop.py --interval 24 --digest-email --notify   (digest serale)

Avvio automatico:
  * Linux: systemd user unit (vedi contrib/interpelli.service)
  * macOS: launchd plist
  * Windows: "pythonw run_loop.py" nella cartella Avvio
"""

from __future__ import annotations

import argparse
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def log(msg: str) -> None:
    line = f"[{datetime.now():%Y-%m-%d %H:%M:%S}] {msg}"
    print(line, flush=True)
    try:
        with open(ROOT / "data" / "ingest.log", "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except OSError:
        pass


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--interval", type=float, default=1.0,
                    help="ore tra un ciclo e l'altro (default 1)")
    ap.add_argument("--school-probe", action="store_true")
    ap.add_argument("--probe-limit", type=int, default=40)
    ap.add_argument("--notify", action="store_true")
    ap.add_argument("--digest-email", action="store_true")
    ap.add_argument("--provinces", default="")
    ap.add_argument("--scan", action="store_true",
                    help="esegue anche lo scan delle scuole secondarie II (siti)")
    ap.add_argument("--once", action="store_true", help="un solo ciclo e stop")
    args = ap.parse_args()

    cycle = 0
    log(f"Avvio loop (intervallo {args.interval}h, provinces={args.provinces or 'default'})")
    while True:
        cycle += 1
        t0 = time.time()
        log(f"— Ciclo {cycle} —")
        cmd = [sys.executable, str(ROOT / "run_ingest.py"),
               "--since-days", "21"]
        if args.school_probe:
            cmd += ["--school-probe", "--probe-limit", str(args.probe_limit)]
        if args.notify:
            cmd += ["--notify"]
        if args.digest_email:
            cmd += ["--digest-email"]
        if args.provinces:
            cmd += ["--provinces", args.provinces]
        try:
            r = subprocess.run(cmd, cwd=ROOT)
            log(f"  ingest uscito con codice {r.returncode} "
                f"({time.time() - t0:.0f}s)")
        except KeyboardInterrupt:
            log("Interrotto.")
            return 0
        if args.scan:
            t1 = time.time()
            log("  scan scuole secondarie II (siti istituzionali)…")
            try:
                r2 = subprocess.run(
                    [sys.executable, str(ROOT / "scan_scuole.py"), "--workers", "4"],
                    cwd=ROOT)
                log(f"  scan uscito con codice {r2.returncode} ({time.time()-t1:.0f}s)")
            except KeyboardInterrupt:
                log("Interrotto.")
                return 0
        if args.once:
            return 0
        time.sleep(args.interval * 3600)


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        log("Interrotto.")
        raise SystemExit(0)