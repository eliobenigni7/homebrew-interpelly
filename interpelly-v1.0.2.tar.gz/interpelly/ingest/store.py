"""
store.py — Persistenza SQLite.

Tabelle:
  schools(id PK, name UNIQUE, domain, subject, url, watch INT, updated_ts)
  interpelli(detail_url PK, date_iso, date_str, school, grade, subject,
             confidence, axios_url, raw_text, province, comune, tipo_scuola,
             classi_concorso, ore, periodo, scadenza_iso, link_candidatura,
             fonte, created_ts)
  meta(k, v)

Il dedup è su detail_url (URL MIM del dettaglio), stabile nel tempo.
"""

from __future__ import annotations

import json
import os
import sqlite3
from datetime import datetime, timedelta, timezone
from pathlib import Path

INTERPELLI_COLS = [
    "comune", "tipo_scuola", "classi_concorso", "ore", "periodo",
    "scadenza_iso", "link_candidatura", "fonte", "provincia",
]


class Store:
    def __init__(self, db_path: str | Path):
        self.db = Path(db_path)
        self.db.parent.mkdir(parents=True, exist_ok=True)
        # check_same_thread=False: FastAPI usa thread diversi per request.
        self.conn = sqlite3.connect(str(self.db), check_same_thread=False)
        self.conn.execute("PRAGMA busy_timeout=8000")
        self.conn.row_factory = sqlite3.Row
        self._init_schema()
        self._migrate()

    def _init_schema(self) -> None:
        self.conn.executescript("""
        CREATE TABLE IF NOT EXISTS schools (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL,
            domain TEXT,
            subject TEXT DEFAULT 'da_verificare',
            url TEXT,
            watch INTEGER DEFAULT 0,
            updated_ts TEXT
        );
        CREATE TABLE IF NOT EXISTS interpelli (
            detail_url TEXT PRIMARY KEY,
            date_iso TEXT,
            date_str TEXT,
            school TEXT NOT NULL,
            grade TEXT DEFAULT '',
            subject TEXT DEFAULT 'da_verificare',
            confidence REAL DEFAULT 0,
            axios_url TEXT DEFAULT '',
            raw_text TEXT DEFAULT '',
            created_ts TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_interpelli_subject ON interpelli(subject);
        CREATE INDEX IF NOT EXISTS idx_interpelli_date ON interpelli(date_iso);
        CREATE TABLE IF NOT EXISTS scans (
            site TEXT PRIMARY KEY,
            names TEXT DEFAULT '[]',
            status TEXT DEFAULT 'pending',
            sections TEXT DEFAULT '[]',
            entries INTEGER DEFAULT 0,
            found INTEGER DEFAULT 0,
            scanned_ts TEXT
        );
        CREATE TABLE IF NOT EXISTS meta (
            k TEXT PRIMARY KEY,
            v TEXT
        );
        """)
        self.conn.commit()

    def _migrate(self) -> None:
        cols = {r["name"] for r in self.conn.execute("PRAGMA table_info(interpelli)")}
        for c in INTERPELLI_COLS:
            if c not in cols:
                self.conn.execute(f"ALTER TABLE interpelli ADD COLUMN {c} TEXT DEFAULT ''")
        scol = {r["name"] for r in self.conn.execute("PRAGMA table_info(schools)")}
        if "watch" not in scol:
            self.conn.execute("ALTER TABLE schools ADD COLUMN watch INTEGER DEFAULT 0")
        self.conn.commit()

    # ---- schools ----
    def upsert_school(self, name: str, domain: str | None = None,
                      subject: str | None = None, url: str | None = None) -> None:
        row = self.conn.execute("SELECT * FROM schools WHERE name=?", (name,)).fetchone()
        ts = datetime.now(timezone.utc).isoformat()
        if row is None:
            self.conn.execute(
                "INSERT INTO schools(name, domain, subject, url, updated_ts) VALUES(?,?,?,?,?)",
                (name, domain, subject or "da_verificare", url, ts))
        else:
            self.conn.execute(
                "UPDATE schools SET domain=COALESCE(?,domain), subject=COALESCE(?,subject),"
                " url=COALESCE(?,url), updated_ts=? WHERE name=?",
                (domain, subject, url, ts, name))
        self.conn.commit()

    def school_domain(self, name: str) -> str | None:
        r = self.conn.execute("SELECT domain FROM schools WHERE name=?", (name,)).fetchone()
        return r["domain"] if r else None

    def set_watch(self, name: str, on: bool) -> None:
        self.conn.execute("UPDATE schools SET watch=? WHERE name=?",
                          (1 if on else 0, name))
        self.conn.commit()

    def watched_schools(self) -> set[str]:
        return {r["name"] for r in self.conn.execute(
            "SELECT name FROM schools WHERE watch=1")}

    # ---- interpelli ----
    def upsert_interpello(self, i, extra: dict | None = None) -> None:
        ts = datetime.now(timezone.utc).isoformat()
        e = extra or {}
        d = {
            "comune": e.get("comune", ""), "tipo_scuola": e.get("tipo_scuola", ""),
            "classi_concorso": json.dumps(e.get("classi", []), ensure_ascii=False),
            "ore": e.get("ore", ""), "periodo": e.get("periodo", ""),
            "scadenza_iso": e.get("scadenza", ""),
            "link_candidatura": e.get("link_candidatura", ""),
            "fonte": e.get("fonte", "MIM"), "provincia": e.get("provincia", "MILANO"),
        }
        self.conn.execute("""
            INSERT INTO interpelli(detail_url, date_iso, date_str, school, grade,
                                   subject, confidence, axios_url, raw_text, created_ts,
                                   comune, tipo_scuola, classi_concorso, ore, periodo,
                                   scadenza_iso, link_candidatura, fonte, provincia)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT(detail_url) DO UPDATE SET
              date_iso=excluded.date_iso, date_str=excluded.date_str,
              school=excluded.school, grade=excluded.grade,
              subject=excluded.subject, confidence=excluded.confidence,
              axios_url=excluded.axios_url, raw_text=excluded.raw_text,
              comune=excluded.comune, tipo_scuola=excluded.tipo_scuola,
              classi_concorso=excluded.classi_concorso, ore=excluded.ore,
              periodo=excluded.periodo, scadenza_iso=excluded.scadenza_iso,
              link_candidatura=excluded.link_candidatura,
              fonte=excluded.fonte, provincia=excluded.provincia
        """, (i.key(), i.date.isoformat() if i.date else None, i.date_str,
              i.school, i.grade, i.subject, i.confidence, i.axios_url,
              i.raw_text[:4000], ts, d["comune"], d["tipo_scuola"], d["classi_concorso"],
              d["ore"], d["periodo"], d["scadenza_iso"], d["link_candidatura"],
              d["fonte"], d["provincia"]))
        self.conn.commit()

    def mark_subject(self, detail_url: str, subject: str, confidence: float) -> None:
        self.conn.execute("UPDATE interpelli SET subject=?, confidence=? WHERE detail_url=?",
                          (subject, confidence, detail_url))
        self.conn.commit()

    def interpelli(self, subject: str | None = None, school: str | None = None,
                   since_days: int | None = None, comune: str | None = None,
                   tipo: str | None = None, urgent_days: int | None = None,
                   watch: bool = False, fonte: str | None = None,
                   date_from: str | None = None, date_to: str | None = None,
                   limit: int = 2000) -> list[dict]:
        q, args = "SELECT * FROM interpelli WHERE 1=1", []
        if subject:
            q += " AND subject=?"
            args.append(subject)
        if school:
            q += " AND school LIKE ?"
            args.append(f"%{school}%")
        if comune:
            q += " AND (comune LIKE ? OR school LIKE ?)"
            args += [f"%{comune}%", f"%{comune.upper()}%"]
        if tipo:
            q += " AND tipo_scuola=?"
            args.append(tipo)
        if fonte:
            q += " AND fonte=?"
            args.append(fonte)
        if date_from:
            q += " AND date_iso >= ?"
            args.append(date_from + "T00:00:00")
        if date_to:
            q += " AND date_iso <= ?"
            args.append(date_to + "T23:59:59")
        if urgent_days:
            q += (" AND scadenza_iso != '' AND scadenza_iso <= ? "
                  "AND scadenza_iso >= ?")
            now = datetime.now(timezone.utc).date()
            args += [(now + timedelta(days=urgent_days)).isoformat(), now.isoformat()]
        if since_days:
            q += " AND date_iso >= ?"
            args.append((datetime.now(timezone.utc) - timedelta(days=since_days)).isoformat())
        if watch:
            q += (" AND school IN (SELECT name FROM schools WHERE watch=1)")
        q += " ORDER BY date_iso DESC, school LIMIT ?"
        args.append(limit)
        rows = [dict(r) for r in self.conn.execute(q, args).fetchall()]
        watched = self.watched_schools()
        for r in rows:
            try:
                r["classi_concorso"] = json.loads(r.get("classi_concorso") or "[]")
            except (json.JSONDecodeError, TypeError):
                r["classi_concorso"] = []
            r["watched"] = r["school"] in watched
        return rows

    def stats(self) -> dict:
        total = self.conn.execute("SELECT COUNT(*) c FROM interpelli").fetchone()["c"]
        by_subj = {r["subject"]: r["c"] for r in self.conn.execute(
            "SELECT subject, COUNT(*) c FROM interpelli GROUP BY subject")}
        last = self.conn.execute("SELECT MAX(date_iso) m FROM interpelli").fetchone()["m"]
        n_scadenza = self.conn.execute(
            "SELECT COUNT(*) c FROM interpelli WHERE scadenza_iso != ''").fetchone()["c"]
        n_comune = self.conn.execute(
            "SELECT COUNT(*) c FROM interpelli WHERE comune != ''").fetchone()["c"]
        n_ax = self.conn.execute(
            "SELECT COUNT(*) c FROM interpelli WHERE axios_url != ''").fetchone()["c"]
        return {"total": total, "by_subject": by_subj, "last_publication": last,
                "with_scadenza": n_scadenza, "with_comune": n_comune,
                "with_axios": n_ax}

    def trend(self, months: int = 6) -> list[dict]:
        rows = self.conn.execute("""
            SELECT substr(date_iso,1,7) ym, subject, COUNT(*) c
            FROM interpelli WHERE date_iso != ''
            GROUP BY ym, subject ORDER BY ym
        """).fetchall()
        return [dict(r) for r in rows]

    def comuni(self) -> list[dict]:
        rows = self.conn.execute("""
            SELECT COALESCE(NULLIF(comune,''),'—') comune, COUNT(*) c
            FROM interpelli GROUP BY 1 ORDER BY c DESC LIMIT 60
        """).fetchall()
        return [dict(r) for r in rows]

    def scanned_sites(self, retry_unreachable_hours: int = 24) -> set[str]:
        """Siti già scansionati: 'ok' sempre saltati; gli 'unreachable' vengono
        ritentati solo dopo che è passato l'intervallo (backoff)."""
        ts_ok = self.conn.execute(
            "SELECT site FROM scans WHERE status='ok'").fetchall()
        out = {r["site"] for r in ts_ok}
        cutoff = (datetime.now(timezone.utc) - timedelta(hours=retry_unreachable_hours)).isoformat()
        older = self.conn.execute(
            "SELECT site FROM scans WHERE status='unreachable' AND scanned_ts < ?",
            (cutoff,)).fetchall()
        return out | {r["site"] for r in older}

    def upsert_scan(self, sc) -> None:
        import json as _j
        ts = datetime.now(timezone.utc).isoformat()
        self.conn.execute("""
            INSERT INTO scans(site, names, status, sections, entries, found, scanned_ts)
            VALUES(?,?,?,?,?,?,?)
            ON CONFLICT(site) DO UPDATE SET
              names=excluded.names, status=excluded.status,
              sections=excluded.sections, entries=excluded.entries,
              found=excluded.found, scanned_ts=excluded.scanned_ts
        """, (sc.site, _j.dumps(sc.names, ensure_ascii=False), sc.status,
              _j.dumps(sc.sections), sc.entries, len(sc.found), ts))
        self.conn.commit()

    def scan_stats(self) -> dict:
        total = self.conn.execute("SELECT COUNT(*) c FROM scans").fetchone()["c"]
        ok = self.conn.execute("SELECT COUNT(*) c FROM scans WHERE status='ok'").fetchone()["c"]
        un = self.conn.execute("SELECT COUNT(*) c FROM scans WHERE status='unreachable'").fetchone()["c"]
        found = self.conn.execute(
            "SELECT COUNT(*) c FROM interpelli WHERE fonte='SCUOLA'").fetchone()["c"]
        return {"scanned": total, "ok": ok, "unreachable": un,
                "interpelli_trovati": found}

    def get_meta(self, k: str, default: str = "") -> str:
        r = self.conn.execute("SELECT v FROM meta WHERE k=?", (k,)).fetchone()
        return r["v"] if r else default

    def set_meta(self, k: str, v: str) -> None:
        self.conn.execute(
            "INSERT INTO meta(k,v) VALUES(?,?) "
            "ON CONFLICT(k) DO UPDATE SET v=excluded.v", (k, v))
        self.conn.commit()

    def get_settings(self) -> dict:
        """Impostazioni AI salvate nella dashboard (env restano fallback)."""
        return {
            "AI_API_KEY": self.get_meta("AI_API_KEY"),
            "AI_BASE_URL": self.get_meta("AI_BASE_URL"),
            "AI_MODEL": self.get_meta("AI_MODEL"),
        }

    def set_settings(self, data: dict) -> None:
        """data: {AI_API_KEY?, AI_BASE_URL?, AI_MODEL?} — valore vuoto la cancella."""
        for k in ("AI_API_KEY", "AI_BASE_URL", "AI_MODEL"):
            if k in data:
                v = (data[k] or "").strip()
                self.set_meta(k, v)

    def ai_effective(self) -> dict:
        """Impostazioni effettive AI: tabella meta > env > default."""
        out = {}
        for k in ("AI_API_KEY", "AI_BASE_URL", "AI_MODEL"):
            out[k] = self.get_meta(k) or os.environ.get(k, "")
        if not out["AI_BASE_URL"]:
            out["AI_BASE_URL"] = "https://openrouter.ai/api/v1"
        if not out["AI_MODEL"]:
            out["AI_MODEL"] = "openrouter/auto"
        return out

    def close(self) -> None:
        self.conn.close()